# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.5.5-10.1.30-MariaDB-1~jessie)
# Database: eeconf
# Generation Time: 2018-10-23 16:42:03 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table exp_actions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_actions`;

CREATE TABLE `exp_actions` (
  `action_id` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `csrf_exempt` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`action_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_actions` WRITE;
/*!40000 ALTER TABLE `exp_actions` DISABLE KEYS */;

INSERT INTO `exp_actions` (`action_id`, `class`, `method`, `csrf_exempt`)
VALUES
	(1,'Channel','submit_entry',0),
	(2,'Channel','filemanager_endpoint',0),
	(3,'Channel','smiley_pop',0),
	(4,'Channel','combo_loader',0),
	(5,'Comment','insert_new_comment',0),
	(6,'Comment_mcp','delete_comment_notification',0),
	(7,'Comment','comment_subscribe',0),
	(8,'Comment','edit_comment',0),
	(9,'Consent','grantConsent',0),
	(10,'Consent','submitConsent',0),
	(11,'Consent','withdrawConsent',0),
	(12,'Rte','get_js',0),
	(13,'Relationship','entryList',0),
	(14,'Search','do_search',1),
	(15,'Formgrab','submit_form',0);

/*!40000 ALTER TABLE `exp_actions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_captcha
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_captcha`;

CREATE TABLE `exp_captcha` (
  `captcha_id` bigint(13) unsigned NOT NULL AUTO_INCREMENT,
  `date` int(10) unsigned NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `word` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`captcha_id`),
  KEY `word` (`word`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_categories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_categories`;

CREATE TABLE `exp_categories` (
  `cat_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `group_id` int(6) unsigned NOT NULL,
  `parent_id` int(4) unsigned NOT NULL,
  `cat_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cat_url_title` varchar(75) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cat_description` text COLLATE utf8mb4_unicode_ci,
  `cat_image` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cat_order` int(4) unsigned NOT NULL,
  PRIMARY KEY (`cat_id`),
  KEY `group_id` (`group_id`),
  KEY `cat_name` (`cat_name`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_category_field_data
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_category_field_data`;

CREATE TABLE `exp_category_field_data` (
  `cat_id` int(4) unsigned NOT NULL,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `group_id` int(4) unsigned NOT NULL,
  PRIMARY KEY (`cat_id`),
  KEY `site_id` (`site_id`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_category_fields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_category_fields`;

CREATE TABLE `exp_category_fields` (
  `field_id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `group_id` int(4) unsigned NOT NULL,
  `field_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `field_label` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `field_type` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `field_list_items` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_maxl` smallint(3) NOT NULL DEFAULT '128',
  `field_ta_rows` tinyint(2) NOT NULL DEFAULT '8',
  `field_default_fmt` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `field_show_fmt` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `field_text_direction` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ltr',
  `field_required` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `field_order` int(3) unsigned NOT NULL,
  `field_settings` text COLLATE utf8mb4_unicode_ci,
  `legacy_field_data` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  PRIMARY KEY (`field_id`),
  KEY `site_id` (`site_id`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_category_groups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_category_groups`;

CREATE TABLE `exp_category_groups` (
  `group_id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `group_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'a',
  `exclude_group` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `field_html_formatting` char(4) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'all',
  `can_edit_categories` text COLLATE utf8mb4_unicode_ci,
  `can_delete_categories` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`group_id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_category_posts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_category_posts`;

CREATE TABLE `exp_category_posts` (
  `entry_id` int(10) unsigned NOT NULL,
  `cat_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`entry_id`,`cat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_channel_data
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_channel_data`;

CREATE TABLE `exp_channel_data` (
  `entry_id` int(10) unsigned NOT NULL,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `channel_id` int(4) unsigned NOT NULL,
  PRIMARY KEY (`entry_id`),
  KEY `channel_id` (`channel_id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_channel_data` WRITE;
/*!40000 ALTER TABLE `exp_channel_data` DISABLE KEYS */;

INSERT INTO `exp_channel_data` (`entry_id`, `site_id`, `channel_id`)
VALUES
	(1,1,1),
	(2,1,1),
	(3,1,1),
	(4,1,1);

/*!40000 ALTER TABLE `exp_channel_data` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_channel_data_field_1
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_channel_data_field_1`;

CREATE TABLE `exp_channel_data_field_1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_id` int(10) unsigned NOT NULL,
  `field_id_1` text COLLATE utf8mb4_unicode_ci,
  `field_ft_1` tinytext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `entry_id` (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_channel_data_field_1` WRITE;
/*!40000 ALTER TABLE `exp_channel_data_field_1` DISABLE KEYS */;

INSERT INTO `exp_channel_data_field_1` (`id`, `entry_id`, `field_id_1`, `field_ft_1`)
VALUES
	(1,1,'<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.</p>\n\n <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?</p>\n\n <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio.</p>\n\n <p>Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.</p>\n\n <p> </p>\n\n <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur? At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias</p>','xhtml'),
	(2,2,'<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium.</p>\n\n <p>Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus.</p>\n\n <p>Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna.</p>\n\n <p>Sed consequat, leo eget bibendum sodales, augue velit cursus nunc, quis gravida magna mi a libero. Fusce vulputate eleifend sapien. Vestibulum purus quam, scelerisque ut, mollis sed, nonummy id, metus. Nullam accumsan lorem in dui. Cras ultricies mi eu turpis hendrerit fringilla. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; In ac dui quis mi consectetuer lacinia. Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum.</p>\n\n <p> </p>\n\n <p>Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Praesent adipiscing. Phasellus ullamcorper ipsum rutrum nunc. Nunc nonummy metus. Vestibulum volutpat pretium libero. Cras id dui. Aenean ut eros et nisl sagittis vestibulum. Nullam nulla eros, ultricies sit amet, nonummy id, imperdiet feugiat, pede. Sed lectus. Donec mollis hendrerit risus. Phasellus nec sem in justo pellentesque facilisis. Etiam imperdiet imperdiet orci. Nunc nec neque. Phasellus leo dolor, tempus non, auctor et, hendrerit quis, nisi. Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa. Sed cursus turpis vitae tortor. Donec posuere vulputate arcu. Phasellus accumsan cursus velit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac</p>','xhtml'),
	(3,3,'Praesent vulputate ullamcorper nisl, quis feugiat diam rutrum at. Nullam faucibus nunc at tellus dignissim, in euismod ipsum tempor. Phasellus consectetur iaculis velit, sed vehicula odio ultricies id. Sed vitae lectus quis nisl blandit elementum quis egestas leo. Donec et neque arcu. Morbi tincidunt imperdiet nunc, eget ullamcorper quam rutrum ut. Duis odio lacus, tristique hendrerit leo consequat, pretium hendrerit tellus. Donec dictum leo at facilisis fermentum. Mauris risus sem, convallis et nunc quis, convallis bibendum nisl.<p>Phasellus purus urna, molestie commodo quam sit amet, vestibulum venenatis libero. Sed laoreet mauris in viverra porttitor. Donec vulputate pharetra mauris, nec mollis metus maximus nec. In congue, felis in fermentum pulvinar, diam risus interdum lectus, at iaculis odio mi quis nisi. Nam elementum egestas sem. Sed finibus sodales diam at feugiat. Curabitur vel magna tincidunt, varius tortor quis, porttitor dolor. Cras accumsan venenatis orci et tempus. Nunc placerat tortor rhoncus enim porttitor aliquet. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse euismod purus interdum, bibendum nisl id, faucibus mauris.</p>\n\n <p>Phasellus sit amet viverra nisi. Nunc ac odio sapien. Donec magna diam, elementum vel tincidunt vel, mattis a massa. Nam sodales sagittis commodo. Vestibulum sed ex non erat aliquet tristique. Sed sed venenatis lectus. Cras eu porttitor nunc. Proin risus dolor, lobortis non pretium sed, finibus et elit. Aenean at justo scelerisque, porta ligula nec, fermentum nunc. Curabitur luctus sed erat ut egestas. Quisque mattis porttitor massa nec dapibus. Nunc congue tincidunt dui, id iaculis lacus pulvinar nec. Nunc sagittis ex a leo hendrerit, et vehicula lorem viverra.</p>\n\n <p>Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vestibulum auctor dapibus fermentum. Nam lacinia imperdiet sagittis. Sed iaculis efficitur urna, ut pharetra diam venenatis et. Morbi eu convallis ante. Nullam sed mauris eget nibh dictum elementum. Suspendisse posuere orci vel sem commodo elementum. Sed lacinia viverra diam. Etiam interdum odio at quam eleifend efficitur.</p>\n\n <p>Cras aliquet sagittis tellus. Praesent lacinia dignissim tellus. Vivamus nisl tellus, ultrices quis lobortis ultrices, ullamcorper et neque. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus dapibus neque at arcu semper, sit amet condimentum nunc tincidunt. Duis dictum dui in lectus condimentum sodales. Proin id porttitor ipsum. Fusce sagittis mauris purus, vehicula convallis sem egestas et. Donec sit amet orci et dolor pharetra consequat.</p>','xhtml'),
	(4,4,'<p>Etiam rhoncus non felis sit amet sodales. Suspendisse faucibus interdum nibh, sed bibendum ligula accumsan at. Integer semper consequat libero, vel aliquet mauris iaculis non. In placerat neque accumsan enim finibus, a faucibus ligula pretium. Nam ut mollis diam. Nullam in sapien vitae nisi commodo placerat sed a sem. Duis consequat bibendum tristique. Aliquam blandit tellus vel lacus interdum gravida. Nunc lacinia eget diam a auctor. Aenean quis orci in urna vulputate porta. Nam nec mauris nisi. Phasellus feugiat rutrum felis aliquam sagittis. Vestibulum ut justo ut lectus convallis luctus. Vestibulum sed viverra libero. Nunc lobortis sapien nunc, in interdum mi condimentum quis.</p>\n\n <p>Ut erat urna, tincidunt in dapibus sit amet, scelerisque vel turpis. Duis ac lacinia diam, et convallis sem. Morbi commodo neque at sem varius fringilla. Sed eu mauris a felis feugiat tempor. Nulla hendrerit convallis feugiat. Nunc dapibus lacinia justo, vel posuere lacus convallis a. Nunc posuere ex in dolor vulputate egestas vitae sit amet sem. Aliquam eget ligula et neque aliquet fermentum. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aliquam egestas lectus metus, eu aliquet justo ultricies nec. In interdum id enim eget accumsan. Phasellus vitae scelerisque felis. Donec gravida libero arcu, et vestibulum nisl eleifend eget.</p>\n\n <p>In mollis consequat ex, ac rhoncus nisl tincidunt ut. Pellentesque eget dictum sapien. Phasellus sollicitudin metus ipsum, vel eleifend justo sagittis ut. Vivamus non lorem eu sapien fermentum maximus vitae sit amet justo. Aenean finibus at odio in ornare. Ut finibus risus commodo, pretium velit at, sollicitudin justo. Duis facilisis quam vitae dolor bibendum, malesuada sagittis tortor ullamcorper. Nullam eget fermentum erat. Donec id dignissim ipsum. Donec eget urna placerat, fringilla augue sit amet, ullamcorper augue. Nullam molestie mattis nunc euismod condimentum. Fusce dictum iaculis malesuada. Sed semper justo eu ante hendrerit dapibus nec eu enim. Praesent sagittis lacinia erat, sed elementum felis ultricies a. Phasellus ultrices sem in eros pretium pulvinar. Proin varius urna odio, et semper mi accumsan et.</p>\n\n <p>Nam vehicula pellentesque ultrices. Mauris posuere lectus lobortis justo tristique, at posuere elit pretium. Quisque ut odio vitae lacus efficitur auctor. Integer malesuada dui in diam lobortis aliquet. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Donec eros eros, suscipit id sollicitudin vitae, tincidunt in nulla. Integer vel sagittis sem. Aliquam gravida euismod dolor lacinia ornare. Proin consectetur elit in dapibus pretium. Donec volutpat placerat accumsan. Sed non massa iaculis, fringilla lacus id, pulvinar nulla. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae;</p>\n\n <p> </p>\n\n <p>Nunc malesuada nibh eu dolor placerat pretium. Vivamus a lectus malesuada, cursus arcu vitae, dictum nisl. Aenean eget magna dapibus, imperdiet mauris non, lobortis magna. Vivamus sed urna et sem ultricies porttitor. Suspendisse mollis turpis id mattis ultricies. Nulla ut erat venenatis, feugiat magna vel, aliquam diam. Integer ac risus eu leo facilisis venenatis non sit amet lacus. Donec vehicula sit amet diam sed mattis. Maecenas non leo et nunc consectetur tempus. Quisque quis risus accumsan, iaculis dolor vehicula, dapibus tortor. Donec orci massa, iaculis quis magna sed, luctus sollicitudin felis. Quisque vel lacinia diam. Phasellus mattis quam eu nunc tincidunt scelerisque. Phasellus aliquet tellus vitae odio pharetra imperdiet dapibus ac felis. Integer vulputate sapien vel rhoncus pharetra. Sed aliquam fermentum rutrum.</p>','xhtml');

/*!40000 ALTER TABLE `exp_channel_data_field_1` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_channel_data_field_2
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_channel_data_field_2`;

CREATE TABLE `exp_channel_data_field_2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_id` int(10) unsigned NOT NULL,
  `field_id_2` text COLLATE utf8mb4_unicode_ci,
  `field_ft_2` tinytext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `entry_id` (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_channel_data_field_2` WRITE;
/*!40000 ALTER TABLE `exp_channel_data_field_2` DISABLE KEYS */;

INSERT INTO `exp_channel_data_field_2` (`id`, `entry_id`, `field_id_2`, `field_ft_2`)
VALUES
	(1,3,'{filedir_6}1.jpg','none'),
	(2,2,'{filedir_6}2.jpg','none'),
	(3,1,'{filedir_6}3.jpg','none'),
	(4,4,'{filedir_6}4.jpg','none');

/*!40000 ALTER TABLE `exp_channel_data_field_2` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_channel_entries_autosave
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_channel_entries_autosave`;

CREATE TABLE `exp_channel_entries_autosave` (
  `entry_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `original_entry_id` int(10) unsigned NOT NULL,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `channel_id` int(4) unsigned NOT NULL,
  `author_id` int(10) unsigned NOT NULL DEFAULT '0',
  `forum_topic_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url_title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `versioning_enabled` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `view_count_one` int(10) unsigned NOT NULL DEFAULT '0',
  `view_count_two` int(10) unsigned NOT NULL DEFAULT '0',
  `view_count_three` int(10) unsigned NOT NULL DEFAULT '0',
  `view_count_four` int(10) unsigned NOT NULL DEFAULT '0',
  `allow_comments` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `sticky` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `entry_date` int(10) NOT NULL,
  `year` char(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  `month` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `day` char(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration_date` int(10) NOT NULL DEFAULT '0',
  `comment_expiration_date` int(10) NOT NULL DEFAULT '0',
  `edit_date` bigint(14) DEFAULT NULL,
  `recent_comment_date` int(10) DEFAULT NULL,
  `comment_total` int(4) unsigned NOT NULL DEFAULT '0',
  `entry_data` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`entry_id`),
  KEY `channel_id` (`channel_id`),
  KEY `author_id` (`author_id`),
  KEY `url_title` (`url_title`(191)),
  KEY `status` (`status`),
  KEY `entry_date` (`entry_date`),
  KEY `expiration_date` (`expiration_date`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_channel_field_groups_fields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_channel_field_groups_fields`;

CREATE TABLE `exp_channel_field_groups_fields` (
  `field_id` int(6) unsigned NOT NULL,
  `group_id` int(4) unsigned NOT NULL,
  PRIMARY KEY (`field_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_channel_field_groups_fields` WRITE;
/*!40000 ALTER TABLE `exp_channel_field_groups_fields` DISABLE KEYS */;

INSERT INTO `exp_channel_field_groups_fields` (`field_id`, `group_id`)
VALUES
	(1,1),
	(2,1);

/*!40000 ALTER TABLE `exp_channel_field_groups_fields` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_channel_fields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_channel_fields`;

CREATE TABLE `exp_channel_fields` (
  `field_id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned DEFAULT '1',
  `field_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_label` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_instructions` text COLLATE utf8mb4_unicode_ci,
  `field_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `field_list_items` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_pre_populate` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `field_pre_channel_id` int(6) unsigned DEFAULT NULL,
  `field_pre_field_id` int(6) unsigned DEFAULT NULL,
  `field_ta_rows` tinyint(2) DEFAULT '8',
  `field_maxl` smallint(3) DEFAULT NULL,
  `field_required` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `field_text_direction` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ltr',
  `field_search` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `field_is_hidden` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `field_fmt` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'xhtml',
  `field_show_fmt` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `field_order` int(3) unsigned NOT NULL,
  `field_content_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'any',
  `field_settings` text COLLATE utf8mb4_unicode_ci,
  `legacy_field_data` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  PRIMARY KEY (`field_id`),
  KEY `field_type` (`field_type`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_channel_fields` WRITE;
/*!40000 ALTER TABLE `exp_channel_fields` DISABLE KEYS */;

INSERT INTO `exp_channel_fields` (`field_id`, `site_id`, `field_name`, `field_label`, `field_instructions`, `field_type`, `field_list_items`, `field_pre_populate`, `field_pre_channel_id`, `field_pre_field_id`, `field_ta_rows`, `field_maxl`, `field_required`, `field_text_direction`, `field_search`, `field_is_hidden`, `field_fmt`, `field_show_fmt`, `field_order`, `field_content_type`, `field_settings`, `legacy_field_data`)
VALUES
	(1,0,'body','Body','','rte','','n',NULL,NULL,6,NULL,'y','ltr','n','n','xhtml','n',1,'any','YToyOntzOjE0OiJmaWVsZF9zaG93X2ZtdCI7czoxOiJuIjtzOjEzOiJmaWVsZF90YV9yb3dzIjtzOjE6IjYiO30=','n'),
	(2,0,'image','Image','','file','','n',NULL,NULL,8,NULL,'n','ltr','n','n','none','y',2,'all','YTo1OntzOjE4OiJmaWVsZF9jb250ZW50X3R5cGUiO3M6MzoiYWxsIjtzOjE5OiJhbGxvd2VkX2RpcmVjdG9yaWVzIjtzOjM6ImFsbCI7czoxMzoic2hvd19leGlzdGluZyI7czoxOiJ5IjtzOjEyOiJudW1fZXhpc3RpbmciO3M6MjoiNTAiO3M6OToiZmllbGRfZm10IjtzOjQ6Im5vbmUiO30=','n');

/*!40000 ALTER TABLE `exp_channel_fields` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_channel_form_settings
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_channel_form_settings`;

CREATE TABLE `exp_channel_form_settings` (
  `channel_form_settings_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '0',
  `channel_id` int(6) unsigned NOT NULL DEFAULT '0',
  `default_status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `allow_guest_posts` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `default_author` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`channel_form_settings_id`),
  KEY `site_id` (`site_id`),
  KEY `channel_id` (`channel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_channel_form_settings` WRITE;
/*!40000 ALTER TABLE `exp_channel_form_settings` DISABLE KEYS */;

INSERT INTO `exp_channel_form_settings` (`channel_form_settings_id`, `site_id`, `channel_id`, `default_status`, `allow_guest_posts`, `default_author`)
VALUES
	(1,1,1,'','n',1);

/*!40000 ALTER TABLE `exp_channel_form_settings` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_channel_member_groups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_channel_member_groups`;

CREATE TABLE `exp_channel_member_groups` (
  `group_id` smallint(4) unsigned NOT NULL,
  `channel_id` int(6) unsigned NOT NULL,
  PRIMARY KEY (`group_id`,`channel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_channel_titles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_channel_titles`;

CREATE TABLE `exp_channel_titles` (
  `entry_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `channel_id` int(4) unsigned NOT NULL,
  `author_id` int(10) unsigned NOT NULL DEFAULT '0',
  `forum_topic_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url_title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_id` int(4) unsigned NOT NULL,
  `versioning_enabled` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `view_count_one` int(10) unsigned NOT NULL DEFAULT '0',
  `view_count_two` int(10) unsigned NOT NULL DEFAULT '0',
  `view_count_three` int(10) unsigned NOT NULL DEFAULT '0',
  `view_count_four` int(10) unsigned NOT NULL DEFAULT '0',
  `allow_comments` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `sticky` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `entry_date` int(10) NOT NULL,
  `year` char(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  `month` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `day` char(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration_date` int(10) NOT NULL DEFAULT '0',
  `comment_expiration_date` int(10) NOT NULL DEFAULT '0',
  `edit_date` bigint(14) DEFAULT NULL,
  `recent_comment_date` int(10) DEFAULT NULL,
  `comment_total` int(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`entry_id`),
  KEY `channel_id` (`channel_id`),
  KEY `author_id` (`author_id`),
  KEY `url_title` (`url_title`(191)),
  KEY `status` (`status`),
  KEY `entry_date` (`entry_date`),
  KEY `expiration_date` (`expiration_date`),
  KEY `site_id` (`site_id`),
  KEY `sticky_date_id_idx` (`sticky`,`entry_date`,`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_channel_titles` WRITE;
/*!40000 ALTER TABLE `exp_channel_titles` DISABLE KEYS */;

INSERT INTO `exp_channel_titles` (`entry_id`, `site_id`, `channel_id`, `author_id`, `forum_topic_id`, `ip_address`, `title`, `url_title`, `status`, `status_id`, `versioning_enabled`, `view_count_one`, `view_count_two`, `view_count_three`, `view_count_four`, `allow_comments`, `sticky`, `entry_date`, `year`, `month`, `day`, `expiration_date`, `comment_expiration_date`, `edit_date`, `recent_comment_date`, `comment_total`)
VALUES
	(1,1,1,2,NULL,'172.20.0.4','5 Brilliant Ways To Use Hot Chicken','5-brilliant-ways-to-use-hot-chicken','open',1,'n',0,0,0,0,'y','n',1540215780,'2018','10','22',0,0,1540219663,NULL,0),
	(2,1,1,2,NULL,'172.20.0.4','Never Lose Your Hot Chicken Again','never-lose-your-hot-chicken-again','open',1,'n',0,0,0,0,'y','n',1540216620,'2018','10','22',0,0,1540219634,NULL,0),
	(3,1,1,2,NULL,'172.20.0.4','How To Get A Fabulous Hot Chicken On A Tight Budget','how-to-get-a-fabulous-hot-chicken-on-a-tight-budget','open',1,'n',0,0,0,0,'y','n',1540216680,'2018','10','22',0,0,1540221054,NULL,0),
	(4,1,1,2,NULL,'172.20.0.4','How Hot Chicken Really Happened','how-hot-chicken-really-happened','open',1,'n',0,0,0,0,'y','n',1540221000,'2018','10','22',0,0,1540221107,NULL,0);

/*!40000 ALTER TABLE `exp_channel_titles` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_channels
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_channels`;

CREATE TABLE `exp_channels` (
  `channel_id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `channel_name` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `channel_title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `channel_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `channel_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `channel_lang` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_entries` mediumint(8) NOT NULL DEFAULT '0',
  `total_records` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_comments` mediumint(8) NOT NULL DEFAULT '0',
  `last_entry_date` int(10) unsigned NOT NULL DEFAULT '0',
  `last_comment_date` int(10) unsigned NOT NULL DEFAULT '0',
  `cat_group` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deft_status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `search_excerpt` int(4) unsigned DEFAULT NULL,
  `deft_category` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deft_comments` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `channel_require_membership` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `channel_max_chars` int(5) unsigned DEFAULT NULL,
  `channel_html_formatting` char(4) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'all',
  `extra_publish_controls` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `channel_allow_img_urls` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `channel_auto_link_urls` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `channel_notify` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `channel_notify_emails` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment_url` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment_system_enabled` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `comment_require_membership` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `comment_moderate` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `comment_max_chars` int(5) unsigned DEFAULT '5000',
  `comment_timelock` int(5) unsigned NOT NULL DEFAULT '0',
  `comment_require_email` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `comment_text_formatting` char(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'xhtml',
  `comment_html_formatting` char(4) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'safe',
  `comment_allow_img_urls` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `comment_auto_link_urls` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `comment_notify` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `comment_notify_authors` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `comment_notify_emails` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment_expiration` int(4) unsigned NOT NULL DEFAULT '0',
  `search_results_url` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rss_url` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enable_versioning` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `max_revisions` smallint(4) unsigned NOT NULL DEFAULT '10',
  `default_entry_title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_field_label` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Title',
  `url_title_prefix` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preview_url` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `max_entries` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`channel_id`),
  KEY `cat_group` (`cat_group`(191)),
  KEY `channel_name` (`channel_name`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_channels` WRITE;
/*!40000 ALTER TABLE `exp_channels` DISABLE KEYS */;

INSERT INTO `exp_channels` (`channel_id`, `site_id`, `channel_name`, `channel_title`, `channel_url`, `channel_description`, `channel_lang`, `total_entries`, `total_records`, `total_comments`, `last_entry_date`, `last_comment_date`, `cat_group`, `deft_status`, `search_excerpt`, `deft_category`, `deft_comments`, `channel_require_membership`, `channel_max_chars`, `channel_html_formatting`, `extra_publish_controls`, `channel_allow_img_urls`, `channel_auto_link_urls`, `channel_notify`, `channel_notify_emails`, `comment_url`, `comment_system_enabled`, `comment_require_membership`, `comment_moderate`, `comment_max_chars`, `comment_timelock`, `comment_require_email`, `comment_text_formatting`, `comment_html_formatting`, `comment_allow_img_urls`, `comment_auto_link_urls`, `comment_notify`, `comment_notify_authors`, `comment_notify_emails`, `comment_expiration`, `search_results_url`, `rss_url`, `enable_versioning`, `max_revisions`, `default_entry_title`, `title_field_label`, `url_title_prefix`, `preview_url`, `max_entries`)
VALUES
	(1,1,'blog','Blog','http://eeconf.vmg/index.php','','en',4,4,0,1540221000,0,'','open',NULL,'','y','y',NULL,'all','n','y','n','n','','','y','n','n',5000,0,'y','xhtml','safe','n','y','n','n','',0,'','','n',10,'','Title','','',0);

/*!40000 ALTER TABLE `exp_channels` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_channels_channel_field_groups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_channels_channel_field_groups`;

CREATE TABLE `exp_channels_channel_field_groups` (
  `channel_id` int(4) unsigned NOT NULL,
  `group_id` int(4) unsigned NOT NULL,
  PRIMARY KEY (`channel_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_channels_channel_field_groups` WRITE;
/*!40000 ALTER TABLE `exp_channels_channel_field_groups` DISABLE KEYS */;

INSERT INTO `exp_channels_channel_field_groups` (`channel_id`, `group_id`)
VALUES
	(1,1);

/*!40000 ALTER TABLE `exp_channels_channel_field_groups` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_channels_channel_fields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_channels_channel_fields`;

CREATE TABLE `exp_channels_channel_fields` (
  `channel_id` int(4) unsigned NOT NULL,
  `field_id` int(6) unsigned NOT NULL,
  PRIMARY KEY (`channel_id`,`field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_channels_statuses
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_channels_statuses`;

CREATE TABLE `exp_channels_statuses` (
  `channel_id` int(4) unsigned NOT NULL,
  `status_id` int(4) unsigned NOT NULL,
  PRIMARY KEY (`channel_id`,`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_channels_statuses` WRITE;
/*!40000 ALTER TABLE `exp_channels_statuses` DISABLE KEYS */;

INSERT INTO `exp_channels_statuses` (`channel_id`, `status_id`)
VALUES
	(1,1),
	(1,2);

/*!40000 ALTER TABLE `exp_channels_statuses` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_comment_subscriptions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_comment_subscriptions`;

CREATE TABLE `exp_comment_subscriptions` (
  `subscription_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_id` int(10) unsigned DEFAULT NULL,
  `member_id` int(10) DEFAULT '0',
  `email` varchar(75) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subscription_date` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notification_sent` char(1) COLLATE utf8mb4_unicode_ci DEFAULT 'n',
  `hash` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`subscription_id`),
  KEY `entry_id` (`entry_id`),
  KEY `member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_comments
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_comments`;

CREATE TABLE `exp_comments` (
  `comment_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) DEFAULT '1',
  `entry_id` int(10) unsigned DEFAULT '0',
  `channel_id` int(4) unsigned DEFAULT '1',
  `author_id` int(10) unsigned DEFAULT '0',
  `status` char(1) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(75) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(75) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment_date` int(10) DEFAULT NULL,
  `edit_date` int(10) DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`comment_id`),
  KEY `entry_id` (`entry_id`),
  KEY `channel_id` (`channel_id`),
  KEY `author_id` (`author_id`),
  KEY `status` (`status`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_consent_audit_log
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_consent_audit_log`;

CREATE TABLE `exp_consent_audit_log` (
  `consent_audit_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `consent_request_id` int(10) unsigned NOT NULL,
  `member_id` int(10) unsigned NOT NULL,
  `action` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `log_date` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`consent_audit_id`),
  KEY `consent_request_id` (`consent_request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_consent_request_versions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_consent_request_versions`;

CREATE TABLE `exp_consent_request_versions` (
  `consent_request_version_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `consent_request_id` int(10) unsigned NOT NULL,
  `request` mediumtext COLLATE utf8mb4_unicode_ci,
  `request_format` tinytext COLLATE utf8mb4_unicode_ci,
  `create_date` int(10) NOT NULL DEFAULT '0',
  `author_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`consent_request_version_id`),
  KEY `consent_request_id` (`consent_request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_consent_request_versions` WRITE;
/*!40000 ALTER TABLE `exp_consent_request_versions` DISABLE KEYS */;

INSERT INTO `exp_consent_request_versions` (`consent_request_version_id`, `consent_request_id`, `request`, `request_format`, `create_date`, `author_id`)
VALUES
	(1,1,'These cookies help us personalize content and functionality for you, including remembering changes you have made to parts of the website that you can customize, or selections for services made on previous visits. If you do not allow these cookies, some portions of our website may be less friendly and easy to use, forcing you to enter content or set your preferences on each visit.','none',1540210616,0),
	(2,2,'These cookies allow us measure how visitors use our website, which pages are popular, and what our traffic sources are. This helps us improve how our website works and make it easier for all visitors to find what they are looking for. The information is aggregated and anonymous, and cannot be used to identify you. If you do not allow these cookies, we will be unable to use your visits to our website to help make improvements.','none',1540210616,0),
	(3,3,'These cookies are usually placed by third-party advertising networks, which may use information about your website visits to develop a profile of your interests. This information may be shared with other advertisers and/or websites to deliver more relevant advertising to you across multiple websites. If you do not allow these cookies, visits to this website will not be shared with advertising partners and will not contribute to targeted advertising on other websites.','none',1540210616,0);

/*!40000 ALTER TABLE `exp_consent_request_versions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_consent_requests
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_consent_requests`;

CREATE TABLE `exp_consent_requests` (
  `consent_request_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `consent_request_version_id` int(10) unsigned DEFAULT NULL,
  `user_created` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consent_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `double_opt_in` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `retention_period` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`consent_request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_consent_requests` WRITE;
/*!40000 ALTER TABLE `exp_consent_requests` DISABLE KEYS */;

INSERT INTO `exp_consent_requests` (`consent_request_id`, `consent_request_version_id`, `user_created`, `title`, `consent_name`, `double_opt_in`, `retention_period`)
VALUES
	(1,1,'n','Functionality Cookies','ee:cookies_functionality','n',NULL),
	(2,2,'n','Performance Cookies','ee:cookies_performance','n',NULL),
	(3,3,'n','Targeting Cookies','ee:cookies_targeting','n',NULL);

/*!40000 ALTER TABLE `exp_consent_requests` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_consents
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_consents`;

CREATE TABLE `exp_consents` (
  `consent_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `consent_request_id` int(10) unsigned NOT NULL,
  `consent_request_version_id` int(10) unsigned NOT NULL,
  `member_id` int(10) unsigned NOT NULL,
  `request_copy` mediumtext COLLATE utf8mb4_unicode_ci,
  `request_format` tinytext COLLATE utf8mb4_unicode_ci,
  `consent_given` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `consent_given_via` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expiration_date` int(10) DEFAULT NULL,
  `response_date` int(10) DEFAULT NULL,
  PRIMARY KEY (`consent_id`),
  KEY `consent_request_version_id` (`consent_request_version_id`),
  KEY `member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_content_types
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_content_types`;

CREATE TABLE `exp_content_types` (
  `content_type_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`content_type_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_content_types` WRITE;
/*!40000 ALTER TABLE `exp_content_types` DISABLE KEYS */;

INSERT INTO `exp_content_types` (`content_type_id`, `name`)
VALUES
	(2,'channel'),
	(1,'grid');

/*!40000 ALTER TABLE `exp_content_types` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_cp_log
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_cp_log`;

CREATE TABLE `exp_cp_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `member_id` int(10) unsigned NOT NULL,
  `username` varchar(75) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `act_date` int(10) NOT NULL,
  `action` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_cp_log` WRITE;
/*!40000 ALTER TABLE `exp_cp_log` DISABLE KEYS */;

INSERT INTO `exp_cp_log` (`id`, `site_id`, `member_id`, `username`, `ip_address`, `act_date`, `action`)
VALUES
	(10,1,2,'admin','172.20.0.4',1540311466,'Logged in');

/*!40000 ALTER TABLE `exp_cp_log` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_developer_log
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_developer_log`;

CREATE TABLE `exp_developer_log` (
  `log_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` int(10) unsigned NOT NULL,
  `viewed` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `description` text COLLATE utf8mb4_unicode_ci,
  `function` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `line` int(10) unsigned DEFAULT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deprecated_since` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `use_instead` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template_id` int(10) unsigned NOT NULL DEFAULT '0',
  `template_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template_group` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addon_module` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addon_method` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `snippets` text COLLATE utf8mb4_unicode_ci,
  `hash` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_email_cache
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_email_cache`;

CREATE TABLE `exp_email_cache` (
  `cache_id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `cache_date` int(10) unsigned NOT NULL DEFAULT '0',
  `total_sent` int(6) unsigned NOT NULL,
  `from_name` varchar(70) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_email` varchar(75) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recipient` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `cc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `bcc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `recipient_array` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `plaintext_alt` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `mailtype` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text_fmt` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `wordwrap` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `attachments` mediumtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`cache_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_email_cache_mg
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_email_cache_mg`;

CREATE TABLE `exp_email_cache_mg` (
  `cache_id` int(6) unsigned NOT NULL,
  `group_id` smallint(4) NOT NULL,
  PRIMARY KEY (`cache_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_email_cache_ml
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_email_cache_ml`;

CREATE TABLE `exp_email_cache_ml` (
  `cache_id` int(6) unsigned NOT NULL,
  `list_id` smallint(4) NOT NULL,
  PRIMARY KEY (`cache_id`,`list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_email_console_cache
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_email_console_cache`;

CREATE TABLE `exp_email_console_cache` (
  `cache_id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `cache_date` int(10) unsigned NOT NULL DEFAULT '0',
  `member_id` int(10) unsigned NOT NULL,
  `member_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `recipient` varchar(75) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recipient_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`cache_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_entry_versioning
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_entry_versioning`;

CREATE TABLE `exp_entry_versioning` (
  `version_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_id` int(10) unsigned NOT NULL,
  `channel_id` int(4) unsigned NOT NULL,
  `author_id` int(10) unsigned NOT NULL,
  `version_date` int(10) NOT NULL,
  `version_data` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`version_id`),
  KEY `entry_id` (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_extensions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_extensions`;

CREATE TABLE `exp_extensions` (
  `extension_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `method` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hook` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `settings` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `priority` int(2) NOT NULL DEFAULT '10',
  `version` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `enabled` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  PRIMARY KEY (`extension_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_extensions` WRITE;
/*!40000 ALTER TABLE `exp_extensions` DISABLE KEYS */;

INSERT INTO `exp_extensions` (`extension_id`, `class`, `method`, `hook`, `settings`, `priority`, `version`, `enabled`)
VALUES
	(1,'Comment_ext','addCommentMenu','cp_custom_menu','a:0:{}',10,'2.3.3','y'),
	(2,'Rte_ext','myaccount_nav_setup','myaccount_nav_setup','',10,'1.0.1','y'),
	(3,'Rte_ext','cp_menu_array','cp_menu_array','',10,'1.0.1','y');

/*!40000 ALTER TABLE `exp_extensions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_field_groups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_field_groups`;

CREATE TABLE `exp_field_groups` (
  `group_id` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned DEFAULT '1',
  `group_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_field_groups` WRITE;
/*!40000 ALTER TABLE `exp_field_groups` DISABLE KEYS */;

INSERT INTO `exp_field_groups` (`group_id`, `site_id`, `group_name`)
VALUES
	(1,0,'Blog');

/*!40000 ALTER TABLE `exp_field_groups` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_fieldtypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_fieldtypes`;

CREATE TABLE `exp_fieldtypes` (
  `fieldtype_id` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `settings` text COLLATE utf8mb4_unicode_ci,
  `has_global_settings` char(1) COLLATE utf8mb4_unicode_ci DEFAULT 'n',
  PRIMARY KEY (`fieldtype_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_fieldtypes` WRITE;
/*!40000 ALTER TABLE `exp_fieldtypes` DISABLE KEYS */;

INSERT INTO `exp_fieldtypes` (`fieldtype_id`, `name`, `version`, `settings`, `has_global_settings`)
VALUES
	(1,'select','1.0.0','YTowOnt9','n'),
	(2,'text','1.0.0','YTowOnt9','n'),
	(3,'textarea','1.0.0','YTowOnt9','n'),
	(4,'date','1.0.0','YTowOnt9','n'),
	(5,'duration','1.0.0','YTowOnt9','n'),
	(6,'email_address','1.0.0','YTowOnt9','n'),
	(7,'file','1.0.0','YTowOnt9','n'),
	(8,'fluid_field','1.0.0','YTowOnt9','n'),
	(9,'grid','1.0.0','YTowOnt9','n'),
	(10,'multi_select','1.0.0','YTowOnt9','n'),
	(11,'checkboxes','1.0.0','YTowOnt9','n'),
	(12,'radio','1.0.0','YTowOnt9','n'),
	(13,'relationship','1.0.0','YTowOnt9','n'),
	(14,'rte','1.0.1','YTowOnt9','n'),
	(15,'toggle','1.0.0','YTowOnt9','n'),
	(16,'url','1.0.0','YTowOnt9','n');

/*!40000 ALTER TABLE `exp_fieldtypes` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_file_categories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_file_categories`;

CREATE TABLE `exp_file_categories` (
  `file_id` int(10) unsigned NOT NULL,
  `cat_id` int(10) unsigned NOT NULL,
  `sort` int(10) unsigned DEFAULT '0',
  `is_cover` char(1) COLLATE utf8mb4_unicode_ci DEFAULT 'n',
  PRIMARY KEY (`file_id`,`cat_id`),
  KEY `cat_id` (`cat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_file_dimensions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_file_dimensions`;

CREATE TABLE `exp_file_dimensions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `upload_location_id` int(4) unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `short_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `resize_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `width` int(10) DEFAULT '0',
  `height` int(10) DEFAULT '0',
  `quality` tinyint(1) unsigned DEFAULT '90',
  `watermark_id` int(4) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `upload_location_id` (`upload_location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_file_watermarks
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_file_watermarks`;

CREATE TABLE `exp_file_watermarks` (
  `wm_id` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `wm_name` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `wm_type` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'text',
  `wm_image_path` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `wm_test_image_path` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `wm_use_font` char(1) COLLATE utf8mb4_unicode_ci DEFAULT 'y',
  `wm_font` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `wm_font_size` int(3) unsigned DEFAULT NULL,
  `wm_text` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `wm_vrt_alignment` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'top',
  `wm_hor_alignment` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'left',
  `wm_padding` int(3) unsigned DEFAULT NULL,
  `wm_opacity` int(3) unsigned DEFAULT NULL,
  `wm_hor_offset` int(4) unsigned DEFAULT NULL,
  `wm_vrt_offset` int(4) unsigned DEFAULT NULL,
  `wm_x_transp` int(4) DEFAULT NULL,
  `wm_y_transp` int(4) DEFAULT NULL,
  `wm_font_color` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `wm_use_drop_shadow` char(1) COLLATE utf8mb4_unicode_ci DEFAULT 'y',
  `wm_shadow_distance` int(3) unsigned DEFAULT NULL,
  `wm_shadow_color` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`wm_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_files
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_files`;

CREATE TABLE `exp_files` (
  `file_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned DEFAULT '1',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upload_location_id` int(4) unsigned DEFAULT '0',
  `mime_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` int(10) DEFAULT '0',
  `description` text COLLATE utf8mb4_unicode_ci,
  `credit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uploaded_by_member_id` int(10) unsigned DEFAULT '0',
  `upload_date` int(10) DEFAULT NULL,
  `modified_by_member_id` int(10) unsigned DEFAULT '0',
  `modified_date` int(10) DEFAULT NULL,
  `file_hw_original` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`file_id`),
  KEY `upload_location_id` (`upload_location_id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_files` WRITE;
/*!40000 ALTER TABLE `exp_files` DISABLE KEYS */;

INSERT INTO `exp_files` (`file_id`, `site_id`, `title`, `upload_location_id`, `mime_type`, `file_name`, `file_size`, `description`, `credit`, `location`, `uploaded_by_member_id`, `upload_date`, `modified_by_member_id`, `modified_date`, `file_hw_original`)
VALUES
	(1,1,'1.jpg',6,'image/jpeg','1.jpg',346061,'','','',2,1540219508,2,1540219508,'525 700'),
	(2,1,'2.jpg',6,'image/jpeg','2.jpg',308869,'','','',2,1540219631,2,1540219631,'525 700'),
	(3,1,'3.jpg',6,'image/jpeg','3.jpg',321669,'','','',2,1540219659,2,1540219659,'525 700'),
	(4,1,'4.jpg',6,'image/jpeg','4.jpg',506737,'','','',2,1540221103,2,1540221103,'525 700');

/*!40000 ALTER TABLE `exp_files` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_fluid_field_data
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_fluid_field_data`;

CREATE TABLE `exp_fluid_field_data` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `fluid_field_id` int(11) unsigned NOT NULL,
  `entry_id` int(11) unsigned NOT NULL,
  `field_id` int(11) unsigned NOT NULL,
  `field_data_id` int(11) unsigned NOT NULL,
  `order` int(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fluid_field_id_entry_id` (`fluid_field_id`,`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_formgrab_forms
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_formgrab_forms`;

CREATE TABLE `exp_formgrab_forms` (
  `form_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(10) unsigned DEFAULT '0',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `save_submission` char(1) COLLATE utf8mb4_unicode_ci DEFAULT 'y',
  `status` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT 'open',
  `return_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `email_notification` char(1) COLLATE utf8mb4_unicode_ci DEFAULT 'n',
  `email_to` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `email_subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `email_body` text COLLATE utf8mb4_unicode_ci,
  `email_from_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `email_from_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `view_order` int(10) unsigned DEFAULT '0',
  `created_at` int(10) NOT NULL,
  `updated_at` int(10) NOT NULL,
  PRIMARY KEY (`form_id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_formgrab_submissions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_formgrab_submissions`;

CREATE TABLE `exp_formgrab_submissions` (
  `submission_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(10) unsigned DEFAULT '0',
  `form_id` int(10) unsigned DEFAULT '0',
  `member_id` int(10) unsigned DEFAULT '0',
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT 'new',
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `data` text COLLATE utf8mb4_unicode_ci,
  `created_at` int(10) NOT NULL,
  `updated_at` int(10) NOT NULL,
  PRIMARY KEY (`submission_id`),
  KEY `site_id` (`site_id`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_global_variables
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_global_variables`;

CREATE TABLE `exp_global_variables` (
  `variable_id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `variable_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `variable_data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `edit_date` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`variable_id`),
  KEY `variable_name` (`variable_name`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_grid_columns
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_grid_columns`;

CREATE TABLE `exp_grid_columns` (
  `col_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `field_id` int(10) unsigned DEFAULT NULL,
  `content_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col_order` int(3) unsigned DEFAULT NULL,
  `col_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col_label` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col_name` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col_instructions` text COLLATE utf8mb4_unicode_ci,
  `col_required` char(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col_search` char(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col_width` int(3) unsigned DEFAULT NULL,
  `col_settings` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`col_id`),
  KEY `field_id` (`field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_html_buttons
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_html_buttons`;

CREATE TABLE `exp_html_buttons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `member_id` int(10) NOT NULL DEFAULT '0',
  `tag_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tag_open` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tag_close` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accesskey` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tag_order` int(3) unsigned NOT NULL,
  `tag_row` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `classname` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_html_buttons` WRITE;
/*!40000 ALTER TABLE `exp_html_buttons` DISABLE KEYS */;

INSERT INTO `exp_html_buttons` (`id`, `site_id`, `member_id`, `tag_name`, `tag_open`, `tag_close`, `accesskey`, `tag_order`, `tag_row`, `classname`)
VALUES
	(1,1,0,'html_btn_bold','<strong>','</strong>','b',1,'1','html-bold'),
	(2,1,0,'html_btn_italic','<em>','</em>','i',2,'1','html-italic'),
	(3,1,0,'html_btn_blockquote','<blockquote>','</blockquote>','q',3,'1','html-quote'),
	(4,1,0,'html_btn_anchor','<a href=\"[![Link:!:http://]!]\"(!( title=\"[![Title]!]\")!)>','</a>','a',4,'1','html-link'),
	(5,1,0,'html_btn_picture','<img src=\"[![Link:!:http://]!]\" alt=\"[![Alternative text]!]\" />','','',5,'1','html-upload');

/*!40000 ALTER TABLE `exp_html_buttons` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_layout_publish
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_layout_publish`;

CREATE TABLE `exp_layout_publish` (
  `layout_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `channel_id` int(4) unsigned NOT NULL DEFAULT '0',
  `layout_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_layout` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`layout_id`),
  KEY `site_id` (`site_id`),
  KEY `channel_id` (`channel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_layout_publish_member_groups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_layout_publish_member_groups`;

CREATE TABLE `exp_layout_publish_member_groups` (
  `layout_id` int(10) unsigned NOT NULL,
  `group_id` int(4) unsigned NOT NULL,
  PRIMARY KEY (`layout_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_member_bulletin_board
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_member_bulletin_board`;

CREATE TABLE `exp_member_bulletin_board` (
  `bulletin_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sender_id` int(10) unsigned NOT NULL,
  `bulletin_group` int(8) unsigned NOT NULL,
  `bulletin_date` int(10) unsigned NOT NULL,
  `hash` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `bulletin_expires` int(10) unsigned NOT NULL DEFAULT '0',
  `bulletin_message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`bulletin_id`),
  KEY `sender_id` (`sender_id`),
  KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_member_data
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_member_data`;

CREATE TABLE `exp_member_data` (
  `member_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_member_data` WRITE;
/*!40000 ALTER TABLE `exp_member_data` DISABLE KEYS */;

INSERT INTO `exp_member_data` (`member_id`)
VALUES
	(2);

/*!40000 ALTER TABLE `exp_member_data` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_member_fields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_member_fields`;

CREATE TABLE `exp_member_fields` (
  `m_field_id` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `m_field_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `m_field_label` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `m_field_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `m_field_type` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `m_field_list_items` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `m_field_ta_rows` tinyint(2) DEFAULT '8',
  `m_field_maxl` smallint(3) DEFAULT NULL,
  `m_field_width` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `m_field_search` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `m_field_required` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `m_field_public` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `m_field_reg` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `m_field_cp_reg` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `m_field_fmt` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `m_field_show_fmt` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `m_field_exclude_from_anon` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `m_field_order` int(3) unsigned DEFAULT NULL,
  `m_field_text_direction` char(3) COLLATE utf8mb4_unicode_ci DEFAULT 'ltr',
  `m_field_settings` text COLLATE utf8mb4_unicode_ci,
  `m_legacy_field_data` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  PRIMARY KEY (`m_field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_member_groups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_member_groups`;

CREATE TABLE `exp_member_groups` (
  `group_id` smallint(4) unsigned NOT NULL,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `menu_set_id` int(5) unsigned NOT NULL DEFAULT '1',
  `group_title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_locked` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_view_offline_system` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_view_online_system` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `can_access_cp` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `can_access_footer_report_bug` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_access_footer_new_ticket` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_access_footer_user_guide` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_view_homepage_news` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `can_access_files` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_access_design` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_access_addons` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_access_members` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_access_sys_prefs` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_access_comm` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_access_utilities` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_access_data` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_access_logs` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_admin_channels` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_admin_design` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_delete_members` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_admin_mbr_groups` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_admin_mbr_templates` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_ban_users` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_admin_addons` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_edit_categories` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_delete_categories` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_view_other_entries` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_edit_other_entries` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_assign_post_authors` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_delete_self_entries` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_delete_all_entries` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_view_other_comments` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_edit_own_comments` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_delete_own_comments` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_edit_all_comments` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_delete_all_comments` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_moderate_comments` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_send_cached_email` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_email_member_groups` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_email_from_profile` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_view_profiles` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_edit_html_buttons` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_delete_self` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `mbr_delete_notify_emails` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `can_post_comments` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `exclude_from_moderation` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_search` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `search_flood_control` mediumint(5) unsigned NOT NULL,
  `can_send_private_messages` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `prv_msg_send_limit` smallint(5) unsigned NOT NULL DEFAULT '20',
  `prv_msg_storage_limit` smallint(5) unsigned NOT NULL DEFAULT '60',
  `can_attach_in_private_messages` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_send_bulletins` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `include_in_authorlist` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `include_in_memberlist` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `cp_homepage` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cp_homepage_channel` int(10) unsigned NOT NULL DEFAULT '0',
  `cp_homepage_custom` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `can_create_entries` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_edit_self_entries` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_upload_new_files` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_edit_files` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_delete_files` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_upload_new_toolsets` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_edit_toolsets` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_delete_toolsets` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_create_upload_directories` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_edit_upload_directories` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_delete_upload_directories` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_create_channels` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_edit_channels` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_delete_channels` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_create_channel_fields` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_edit_channel_fields` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_delete_channel_fields` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_create_statuses` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_delete_statuses` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_edit_statuses` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_create_categories` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_create_member_groups` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_delete_member_groups` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_edit_member_groups` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_create_members` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_edit_members` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_create_new_templates` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_edit_templates` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_delete_templates` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_create_template_groups` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_edit_template_groups` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_delete_template_groups` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_create_template_partials` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_edit_template_partials` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_delete_template_partials` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_create_template_variables` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_delete_template_variables` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_edit_template_variables` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_access_security_settings` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_access_translate` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_access_import` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_access_sql_manager` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_moderate_spam` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `can_manage_consents` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  PRIMARY KEY (`group_id`,`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_member_groups` WRITE;
/*!40000 ALTER TABLE `exp_member_groups` DISABLE KEYS */;

INSERT INTO `exp_member_groups` (`group_id`, `site_id`, `menu_set_id`, `group_title`, `group_description`, `is_locked`, `can_view_offline_system`, `can_view_online_system`, `can_access_cp`, `can_access_footer_report_bug`, `can_access_footer_new_ticket`, `can_access_footer_user_guide`, `can_view_homepage_news`, `can_access_files`, `can_access_design`, `can_access_addons`, `can_access_members`, `can_access_sys_prefs`, `can_access_comm`, `can_access_utilities`, `can_access_data`, `can_access_logs`, `can_admin_channels`, `can_admin_design`, `can_delete_members`, `can_admin_mbr_groups`, `can_admin_mbr_templates`, `can_ban_users`, `can_admin_addons`, `can_edit_categories`, `can_delete_categories`, `can_view_other_entries`, `can_edit_other_entries`, `can_assign_post_authors`, `can_delete_self_entries`, `can_delete_all_entries`, `can_view_other_comments`, `can_edit_own_comments`, `can_delete_own_comments`, `can_edit_all_comments`, `can_delete_all_comments`, `can_moderate_comments`, `can_send_cached_email`, `can_email_member_groups`, `can_email_from_profile`, `can_view_profiles`, `can_edit_html_buttons`, `can_delete_self`, `mbr_delete_notify_emails`, `can_post_comments`, `exclude_from_moderation`, `can_search`, `search_flood_control`, `can_send_private_messages`, `prv_msg_send_limit`, `prv_msg_storage_limit`, `can_attach_in_private_messages`, `can_send_bulletins`, `include_in_authorlist`, `include_in_memberlist`, `cp_homepage`, `cp_homepage_channel`, `cp_homepage_custom`, `can_create_entries`, `can_edit_self_entries`, `can_upload_new_files`, `can_edit_files`, `can_delete_files`, `can_upload_new_toolsets`, `can_edit_toolsets`, `can_delete_toolsets`, `can_create_upload_directories`, `can_edit_upload_directories`, `can_delete_upload_directories`, `can_create_channels`, `can_edit_channels`, `can_delete_channels`, `can_create_channel_fields`, `can_edit_channel_fields`, `can_delete_channel_fields`, `can_create_statuses`, `can_delete_statuses`, `can_edit_statuses`, `can_create_categories`, `can_create_member_groups`, `can_delete_member_groups`, `can_edit_member_groups`, `can_create_members`, `can_edit_members`, `can_create_new_templates`, `can_edit_templates`, `can_delete_templates`, `can_create_template_groups`, `can_edit_template_groups`, `can_delete_template_groups`, `can_create_template_partials`, `can_edit_template_partials`, `can_delete_template_partials`, `can_create_template_variables`, `can_delete_template_variables`, `can_edit_template_variables`, `can_access_security_settings`, `can_access_translate`, `can_access_import`, `can_access_sql_manager`, `can_moderate_spam`, `can_manage_consents`)
VALUES
	(1,1,1,'Super Admin','','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y',NULL,'y','y','y',0,'y',20,60,'y','y','y','y',NULL,0,NULL,'y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y','y'),
	(2,1,1,'Banned','','n','n','n','n','n','n','n','y','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n',NULL,'n','n','n',60,'n',20,60,'n','n','n','n',NULL,0,NULL,'n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n'),
	(3,1,1,'Guests','','n','n','y','n','n','n','n','y','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n',NULL,'n','n','n',10,'n',20,60,'n','n','n','y',NULL,0,NULL,'n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n'),
	(4,1,1,'Pending','','n','n','y','n','n','n','n','y','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n',NULL,'n','n','n',10,'n',20,60,'n','n','n','y',NULL,0,NULL,'n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n'),
	(5,1,1,'Members','','n','n','y','n','n','n','n','y','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','y','y','y','y',NULL,'n','n','n',10,'y',20,60,'y','n','n','y',NULL,0,NULL,'n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n','n');

/*!40000 ALTER TABLE `exp_member_groups` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_member_news_views
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_member_news_views`;

CREATE TABLE `exp_member_news_views` (
  `news_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `member_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`news_id`),
  KEY `member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_member_search
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_member_search`;

CREATE TABLE `exp_member_search` (
  `search_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `search_date` int(10) unsigned NOT NULL,
  `keywords` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fields` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `member_id` int(10) unsigned NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `total_results` int(8) unsigned NOT NULL,
  `query` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`search_id`),
  KEY `member_id` (`member_id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_members
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_members`;

CREATE TABLE `exp_members` (
  `member_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` smallint(4) NOT NULL DEFAULT '0',
  `username` varchar(75) COLLATE utf8mb4_unicode_ci NOT NULL,
  `screen_name` varchar(75) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `salt` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `unique_id` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `crypt_key` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authcode` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(75) COLLATE utf8mb4_unicode_ci NOT NULL,
  `signature` text COLLATE utf8mb4_unicode_ci,
  `avatar_filename` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar_width` int(4) unsigned DEFAULT NULL,
  `avatar_height` int(4) unsigned DEFAULT NULL,
  `photo_filename` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_width` int(4) unsigned DEFAULT NULL,
  `photo_height` int(4) unsigned DEFAULT NULL,
  `sig_img_filename` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sig_img_width` int(4) unsigned DEFAULT NULL,
  `sig_img_height` int(4) unsigned DEFAULT NULL,
  `ignore_list` text COLLATE utf8mb4_unicode_ci,
  `private_messages` int(4) unsigned NOT NULL DEFAULT '0',
  `accept_messages` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `last_view_bulletins` int(10) NOT NULL DEFAULT '0',
  `last_bulletin_date` int(10) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `join_date` int(10) unsigned NOT NULL DEFAULT '0',
  `last_visit` int(10) unsigned NOT NULL DEFAULT '0',
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `total_entries` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_comments` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_forum_topics` mediumint(8) NOT NULL DEFAULT '0',
  `total_forum_posts` mediumint(8) NOT NULL DEFAULT '0',
  `last_entry_date` int(10) unsigned NOT NULL DEFAULT '0',
  `last_comment_date` int(10) unsigned NOT NULL DEFAULT '0',
  `last_forum_post_date` int(10) unsigned NOT NULL DEFAULT '0',
  `last_email_date` int(10) unsigned NOT NULL DEFAULT '0',
  `in_authorlist` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `accept_admin_email` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `accept_user_email` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `notify_by_default` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `notify_of_pm` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `display_avatars` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `display_signatures` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `parse_smileys` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `smart_notifications` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `language` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `timezone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time_format` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_format` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `include_seconds` char(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_theme` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `forum_theme` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tracker` text COLLATE utf8mb4_unicode_ci,
  `template_size` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '28',
  `notepad` text COLLATE utf8mb4_unicode_ci,
  `notepad_size` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '18',
  `bookmarklets` text COLLATE utf8mb4_unicode_ci,
  `quick_links` text COLLATE utf8mb4_unicode_ci,
  `quick_tabs` text COLLATE utf8mb4_unicode_ci,
  `show_sidebar` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `pmember_id` int(10) NOT NULL DEFAULT '0',
  `rte_enabled` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `rte_toolset_id` int(10) NOT NULL DEFAULT '0',
  `cp_homepage` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cp_homepage_channel` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cp_homepage_custom` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`member_id`),
  KEY `group_id` (`group_id`),
  KEY `unique_id` (`unique_id`),
  KEY `password` (`password`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_members` WRITE;
/*!40000 ALTER TABLE `exp_members` DISABLE KEYS */;

INSERT INTO `exp_members` (`member_id`, `group_id`, `username`, `screen_name`, `password`, `salt`, `unique_id`, `crypt_key`, `authcode`, `email`, `signature`, `avatar_filename`, `avatar_width`, `avatar_height`, `photo_filename`, `photo_width`, `photo_height`, `sig_img_filename`, `sig_img_width`, `sig_img_height`, `ignore_list`, `private_messages`, `accept_messages`, `last_view_bulletins`, `last_bulletin_date`, `ip_address`, `join_date`, `last_visit`, `last_activity`, `total_entries`, `total_comments`, `total_forum_topics`, `total_forum_posts`, `last_entry_date`, `last_comment_date`, `last_forum_post_date`, `last_email_date`, `in_authorlist`, `accept_admin_email`, `accept_user_email`, `notify_by_default`, `notify_of_pm`, `display_avatars`, `display_signatures`, `parse_smileys`, `smart_notifications`, `language`, `timezone`, `time_format`, `date_format`, `include_seconds`, `profile_theme`, `forum_theme`, `tracker`, `template_size`, `notepad`, `notepad_size`, `bookmarklets`, `quick_links`, `quick_tabs`, `show_sidebar`, `pmember_id`, `rte_enabled`, `rte_toolset_id`, `cp_homepage`, `cp_homepage_channel`, `cp_homepage_custom`)
VALUES
	(2,1,'admin','admin','875ae8a3508d6a0b026b2bef06d2bb075dbef3ca00d7953cd0af54df4b9201c466ff6d8edb4939040c67e3c7c9fe253d83170e43b9be86d88b7089120ba26294',']F]~*kOIN,X3zA^h&AAB$C,zZL0/^?z$1vNnD.cX,M|Pumzy/8qXz4+.u#\\e[-Id,h>&;|1[->=XfBeZ#ZM00ijYw99Yz1.pTNDmp)~*x.%s]`a-C+Jy6eI>bQAUurY!','f0b9fa8f2e1d279839b98c49b0deaaec4c2998b7','cf67203656ec685e81356234787bc05698197d78',NULL,'admin@example.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'y',0,0,'172.20.0.4',1540311443,1540311467,1540312870,4,0,0,0,1540221000,0,0,0,'n','y','y','y','y','y','y','y','y','english',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'28',NULL,'18',NULL,NULL,NULL,'n',0,'y',0,NULL,NULL,NULL);

/*!40000 ALTER TABLE `exp_members` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_menu_items
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_menu_items`;

CREATE TABLE `exp_menu_items` (
  `item_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) NOT NULL DEFAULT '0',
  `set_id` int(10) DEFAULT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`item_id`),
  KEY `set_id` (`set_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_menu_sets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_menu_sets`;

CREATE TABLE `exp_menu_sets` (
  `set_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`set_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_menu_sets` WRITE;
/*!40000 ALTER TABLE `exp_menu_sets` DISABLE KEYS */;

INSERT INTO `exp_menu_sets` (`set_id`, `name`)
VALUES
	(1,'Default');

/*!40000 ALTER TABLE `exp_menu_sets` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_message_attachments
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_message_attachments`;

CREATE TABLE `exp_message_attachments` (
  `attachment_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sender_id` int(10) unsigned NOT NULL DEFAULT '0',
  `message_id` int(10) unsigned NOT NULL DEFAULT '0',
  `attachment_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `attachment_hash` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `attachment_extension` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `attachment_location` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `attachment_date` int(10) unsigned NOT NULL DEFAULT '0',
  `attachment_size` int(10) unsigned NOT NULL DEFAULT '0',
  `is_temp` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  PRIMARY KEY (`attachment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_message_copies
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_message_copies`;

CREATE TABLE `exp_message_copies` (
  `copy_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `message_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sender_id` int(10) unsigned NOT NULL DEFAULT '0',
  `recipient_id` int(10) unsigned NOT NULL DEFAULT '0',
  `message_received` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `message_read` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `message_time_read` int(10) unsigned NOT NULL DEFAULT '0',
  `attachment_downloaded` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `message_folder` int(10) unsigned NOT NULL DEFAULT '1',
  `message_authcode` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `message_deleted` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `message_status` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`copy_id`),
  KEY `message_id` (`message_id`),
  KEY `recipient_id` (`recipient_id`),
  KEY `sender_id` (`sender_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_message_data
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_message_data`;

CREATE TABLE `exp_message_data` (
  `message_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sender_id` int(10) unsigned NOT NULL DEFAULT '0',
  `message_date` int(10) unsigned NOT NULL DEFAULT '0',
  `message_subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `message_body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `message_tracking` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `message_attachments` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `message_recipients` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `message_cc` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `message_hide_cc` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `message_sent_copy` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `total_recipients` int(5) unsigned NOT NULL DEFAULT '0',
  `message_status` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`message_id`),
  KEY `sender_id` (`sender_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_message_folders
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_message_folders`;

CREATE TABLE `exp_message_folders` (
  `member_id` int(10) unsigned NOT NULL DEFAULT '0',
  `folder1_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'InBox',
  `folder2_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sent',
  `folder3_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `folder4_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `folder5_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `folder6_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `folder7_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `folder8_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `folder9_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `folder10_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_message_listed
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_message_listed`;

CREATE TABLE `exp_message_listed` (
  `listed_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(10) unsigned NOT NULL DEFAULT '0',
  `listed_member` int(10) unsigned NOT NULL DEFAULT '0',
  `listed_description` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `listed_type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'blocked',
  PRIMARY KEY (`listed_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_module_member_groups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_module_member_groups`;

CREATE TABLE `exp_module_member_groups` (
  `group_id` smallint(4) unsigned NOT NULL,
  `module_id` mediumint(5) unsigned NOT NULL,
  PRIMARY KEY (`group_id`,`module_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_modules
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_modules`;

CREATE TABLE `exp_modules` (
  `module_id` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `module_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module_version` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `has_cp_backend` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `has_publish_fields` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  PRIMARY KEY (`module_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_modules` WRITE;
/*!40000 ALTER TABLE `exp_modules` DISABLE KEYS */;

INSERT INTO `exp_modules` (`module_id`, `module_name`, `module_version`, `has_cp_backend`, `has_publish_fields`)
VALUES
	(1,'Channel','2.0.1','n','n'),
	(2,'Comment','2.3.3','y','n'),
	(3,'Consent','1.0.0','n','n'),
	(4,'Stats','2.0.0','n','n'),
	(5,'Rte','1.0.1','y','n'),
	(6,'File','1.0.0','n','n'),
	(7,'Filepicker','1.0','y','n'),
	(8,'Relationship','1.0.0','n','n'),
	(9,'Search','2.2.2','n','n'),
	(10,'Formgrab','1.0.2','y','n');

/*!40000 ALTER TABLE `exp_modules` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_online_users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_online_users`;

CREATE TABLE `exp_online_users` (
  `online_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `member_id` int(10) NOT NULL DEFAULT '0',
  `in_forum` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `date` int(10) unsigned NOT NULL DEFAULT '0',
  `anon` char(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`online_id`),
  KEY `date` (`date`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_password_lockout
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_password_lockout`;

CREATE TABLE `exp_password_lockout` (
  `lockout_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `login_date` int(10) unsigned NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `user_agent` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(75) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`lockout_id`),
  KEY `login_date` (`login_date`),
  KEY `ip_address` (`ip_address`),
  KEY `user_agent` (`user_agent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_plugins
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_plugins`;

CREATE TABLE `exp_plugins` (
  `plugin_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `plugin_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `plugin_package` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `plugin_version` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_typography_related` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  PRIMARY KEY (`plugin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_plugins` WRITE;
/*!40000 ALTER TABLE `exp_plugins` DISABLE KEYS */;

INSERT INTO `exp_plugins` (`plugin_id`, `plugin_name`, `plugin_package`, `plugin_version`, `is_typography_related`)
VALUES
	(1,'Trunk','trunk','1.0','n'),
	(2,'Trunk NS','trunk_ns','1.0','n'),
	(3,'Partner Content','partner_content','1.0','n'),
	(4,'Hot Comments','hot_comments','1.0','n');

/*!40000 ALTER TABLE `exp_plugins` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_relationships
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_relationships`;

CREATE TABLE `exp_relationships` (
  `relationship_id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `child_id` int(10) unsigned NOT NULL DEFAULT '0',
  `field_id` int(10) unsigned NOT NULL DEFAULT '0',
  `fluid_field_data_id` int(10) unsigned NOT NULL DEFAULT '0',
  `grid_field_id` int(10) unsigned NOT NULL DEFAULT '0',
  `grid_col_id` int(10) unsigned NOT NULL DEFAULT '0',
  `grid_row_id` int(10) unsigned NOT NULL DEFAULT '0',
  `order` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`relationship_id`),
  KEY `parent_id` (`parent_id`),
  KEY `child_id` (`child_id`),
  KEY `field_id` (`field_id`),
  KEY `fluid_field_data_id` (`fluid_field_data_id`),
  KEY `grid_row_id` (`grid_row_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_remember_me
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_remember_me`;

CREATE TABLE `exp_remember_me` (
  `remember_me_id` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `member_id` int(10) DEFAULT '0',
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `user_agent` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `admin_sess` tinyint(1) DEFAULT '0',
  `site_id` int(4) DEFAULT '1',
  `expiration` int(10) DEFAULT '0',
  `last_refresh` int(10) DEFAULT '0',
  PRIMARY KEY (`remember_me_id`),
  KEY `member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_reset_password
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_reset_password`;

CREATE TABLE `exp_reset_password` (
  `reset_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(10) unsigned NOT NULL,
  `resetcode` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` int(10) NOT NULL,
  PRIMARY KEY (`reset_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_revision_tracker
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_revision_tracker`;

CREATE TABLE `exp_revision_tracker` (
  `tracker_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` int(10) unsigned NOT NULL,
  `item_table` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_field` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_date` int(10) NOT NULL,
  `item_author_id` int(10) unsigned NOT NULL,
  `item_data` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`tracker_id`),
  KEY `item_id` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_rte_tools
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_rte_tools`;

CREATE TABLE `exp_rte_tools` (
  `tool_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(75) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `class` varchar(75) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enabled` char(1) COLLATE utf8mb4_unicode_ci DEFAULT 'y',
  PRIMARY KEY (`tool_id`),
  KEY `enabled` (`enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_rte_tools` WRITE;
/*!40000 ALTER TABLE `exp_rte_tools` DISABLE KEYS */;

INSERT INTO `exp_rte_tools` (`tool_id`, `name`, `class`, `enabled`)
VALUES
	(1,'Blockquote','Blockquote_rte','y'),
	(2,'Bold','Bold_rte','y'),
	(3,'Headings','Headings_rte','y'),
	(4,'Image','Image_rte','y'),
	(5,'Italic','Italic_rte','y'),
	(6,'Link','Link_rte','y'),
	(7,'Ordered List','Ordered_list_rte','y'),
	(8,'Underline','Underline_rte','y'),
	(9,'Unordered List','Unordered_list_rte','y'),
	(10,'View Source','View_source_rte','y');

/*!40000 ALTER TABLE `exp_rte_tools` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_rte_toolsets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_rte_toolsets`;

CREATE TABLE `exp_rte_toolsets` (
  `toolset_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(10) DEFAULT '0',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tools` text COLLATE utf8mb4_unicode_ci,
  `enabled` char(1) COLLATE utf8mb4_unicode_ci DEFAULT 'y',
  PRIMARY KEY (`toolset_id`),
  KEY `member_id` (`member_id`),
  KEY `enabled` (`enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_rte_toolsets` WRITE;
/*!40000 ALTER TABLE `exp_rte_toolsets` DISABLE KEYS */;

INSERT INTO `exp_rte_toolsets` (`toolset_id`, `member_id`, `name`, `tools`, `enabled`)
VALUES
	(1,0,'Default','3|2|5|1|9|7|6|4|10','y');

/*!40000 ALTER TABLE `exp_rte_toolsets` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_search
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_search`;

CREATE TABLE `exp_search` (
  `search_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `site_id` int(4) NOT NULL DEFAULT '1',
  `search_date` int(10) NOT NULL,
  `keywords` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `member_id` int(10) unsigned NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_results` int(6) NOT NULL,
  `per_page` tinyint(3) unsigned NOT NULL,
  `query` mediumtext COLLATE utf8mb4_unicode_ci,
  `custom_fields` mediumtext COLLATE utf8mb4_unicode_ci,
  `result_page` varchar(70) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`search_id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_search_log
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_search_log`;

CREATE TABLE `exp_search_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `member_id` int(10) unsigned NOT NULL,
  `screen_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `search_date` int(10) NOT NULL,
  `search_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `search_terms` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_security_hashes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_security_hashes`;

CREATE TABLE `exp_security_hashes` (
  `hash_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` int(10) unsigned NOT NULL,
  `session_id` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `hash` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`hash_id`),
  KEY `session_id` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_security_hashes` WRITE;
/*!40000 ALTER TABLE `exp_security_hashes` DISABLE KEYS */;

INSERT INTO `exp_security_hashes` (`hash_id`, `date`, `session_id`, `hash`)
VALUES
	(1,1540210626,'43c6ffc98894e91d09abceb5772958c7ea6bbfd5','9c202a24a1bf177276f1f9f4b6641ffae4363fee'),
	(2,1540228104,'9949212b83b46a5671d8877b50c43474d5973feb','40aa35ad3b4f3c9f63d4f4f155675907d3422026'),
	(3,1540237492,'4c5e526e7f08256cab01550c9ec4a55feb6f28a8','01d381aa84a095fb47d54279348dc2d76ab5dcfd'),
	(4,1540298434,'a03eb49997a7ac310f3f50afd9492ea5e47cede5','a745203ca740468e5e5243c98098f7150bb5680a'),
	(5,1540299820,'a9900a125efb19568861157e5ee1bb8699ea236f','f22000fe80666380f65521465d0a5094bc7682eb'),
	(7,1540311467,'f6442620db45b097bbffc276b3ec3f3e62354c6b','f1d98fed740d3cc916d814df8876cc1c80244473');

/*!40000 ALTER TABLE `exp_security_hashes` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_sessions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_sessions`;

CREATE TABLE `exp_sessions` (
  `session_id` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `member_id` int(10) NOT NULL DEFAULT '0',
  `admin_sess` tinyint(1) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `user_agent` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_state` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fingerprint` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sess_start` int(10) unsigned NOT NULL DEFAULT '0',
  `auth_timeout` int(10) unsigned NOT NULL DEFAULT '0',
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `can_debug` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  PRIMARY KEY (`session_id`),
  KEY `member_id` (`member_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_sessions` WRITE;
/*!40000 ALTER TABLE `exp_sessions` DISABLE KEYS */;

INSERT INTO `exp_sessions` (`session_id`, `member_id`, `admin_sess`, `ip_address`, `user_agent`, `login_state`, `fingerprint`, `sess_start`, `auth_timeout`, `last_activity`, `can_debug`)
VALUES
	('f6442620db45b097bbffc276b3ec3f3e62354c6b',2,1,'172.20.0.4','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.67 Safari/537.36',NULL,'fe811634196d87d43053ffc399c4f574',1540311466,1540312384,1540312889,'n');

/*!40000 ALTER TABLE `exp_sessions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_sites
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_sites`;

CREATE TABLE `exp_sites` (
  `site_id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `site_label` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `site_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `site_description` text COLLATE utf8mb4_unicode_ci,
  `site_system_preferences` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `site_member_preferences` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `site_template_preferences` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `site_channel_preferences` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `site_bootstrap_checksums` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `site_pages` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`site_id`),
  KEY `site_name` (`site_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_sites` WRITE;
/*!40000 ALTER TABLE `exp_sites` DISABLE KEYS */;

INSERT INTO `exp_sites` (`site_id`, `site_label`, `site_name`, `site_description`, `site_system_preferences`, `site_member_preferences`, `site_template_preferences`, `site_channel_preferences`, `site_bootstrap_checksums`, `site_pages`)
VALUES
	(1,'Hot Chicken Blog','default_site',NULL,'YTo5MTp7czoxMDoiaXNfc2l0ZV9vbiI7czoxOiJ5IjtzOjg6ImJhc2VfdXJsIjtzOjE4OiJodHRwOi8vZWVjb25mLnZtZy8iO3M6OToiYmFzZV9wYXRoIjtzOjE3OiIvY29kZS9lZWNvbmYyMDE4LyI7czoxMDoic2l0ZV9pbmRleCI7czo5OiJpbmRleC5waHAiO3M6ODoic2l0ZV91cmwiO3M6MTA6IntiYXNlX3VybH0iO3M6NjoiY3BfdXJsIjtzOjE5OiJ7YmFzZV91cmx9YWRtaW4ucGhwIjtzOjE2OiJ0aGVtZV9mb2xkZXJfdXJsIjtzOjE3OiJ7YmFzZV91cmx9dGhlbWVzLyI7czoxNzoidGhlbWVfZm9sZGVyX3BhdGgiO3M6MTg6IntiYXNlX3BhdGh9dGhlbWVzLyI7czoxNToid2VibWFzdGVyX2VtYWlsIjtzOjI3OiJqdWxpYW5AdmVjdG9ybWVkaWFncm91cC5jb20iO3M6MTQ6IndlYm1hc3Rlcl9uYW1lIjtzOjA6IiI7czoyMDoiY2hhbm5lbF9ub21lbmNsYXR1cmUiO3M6NzoiY2hhbm5lbCI7czoxMDoibWF4X2NhY2hlcyI7czozOiIxNTAiO3M6MTE6ImNhcHRjaGFfdXJsIjtzOjI2OiJ7YmFzZV91cmx9aW1hZ2VzL2NhcHRjaGFzLyI7czoxMjoiY2FwdGNoYV9wYXRoIjtzOjI3OiJ7YmFzZV9wYXRofWltYWdlcy9jYXB0Y2hhcy8iO3M6MTI6ImNhcHRjaGFfZm9udCI7czoxOiJ5IjtzOjEyOiJjYXB0Y2hhX3JhbmQiO3M6MToieSI7czoyMzoiY2FwdGNoYV9yZXF1aXJlX21lbWJlcnMiO3M6MToibiI7czoxNToicmVxdWlyZV9jYXB0Y2hhIjtzOjE6Im4iO3M6MTg6ImVuYWJsZV9zcWxfY2FjaGluZyI7czoxOiJuIjtzOjE4OiJmb3JjZV9xdWVyeV9zdHJpbmciO3M6MToibiI7czoxMzoic2hvd19wcm9maWxlciI7czoxOiJuIjtzOjE1OiJpbmNsdWRlX3NlY29uZHMiO3M6MToibiI7czoxMzoiY29va2llX2RvbWFpbiI7czowOiIiO3M6MTE6ImNvb2tpZV9wYXRoIjtzOjE6Ii8iO3M6MTU6ImNvb2tpZV9odHRwb25seSI7TjtzOjEzOiJjb29raWVfc2VjdXJlIjtOO3M6MjA6IndlYnNpdGVfc2Vzc2lvbl90eXBlIjtzOjE6ImMiO3M6MTU6ImNwX3Nlc3Npb25fdHlwZSI7czoxOiJjIjtzOjIxOiJhbGxvd191c2VybmFtZV9jaGFuZ2UiO3M6MToieSI7czoxODoiYWxsb3dfbXVsdGlfbG9naW5zIjtzOjE6InkiO3M6MTY6InBhc3N3b3JkX2xvY2tvdXQiO3M6MToieSI7czoyNToicGFzc3dvcmRfbG9ja291dF9pbnRlcnZhbCI7czoxOiIxIjtzOjIwOiJyZXF1aXJlX2lwX2Zvcl9sb2dpbiI7czoxOiJ5IjtzOjIyOiJyZXF1aXJlX2lwX2Zvcl9wb3N0aW5nIjtzOjE6InkiO3M6MjQ6InJlcXVpcmVfc2VjdXJlX3Bhc3N3b3JkcyI7czoxOiJuIjtzOjE5OiJhbGxvd19kaWN0aW9uYXJ5X3B3IjtzOjE6InkiO3M6MjM6Im5hbWVfb2ZfZGljdGlvbmFyeV9maWxlIjtzOjA6IiI7czoxNzoieHNzX2NsZWFuX3VwbG9hZHMiO3M6MToieSI7czoxNToicmVkaXJlY3RfbWV0aG9kIjtzOjg6InJlZGlyZWN0IjtzOjk6ImRlZnRfbGFuZyI7czo3OiJlbmdsaXNoIjtzOjg6InhtbF9sYW5nIjtzOjI6ImVuIjtzOjEyOiJzZW5kX2hlYWRlcnMiO3M6MToieSI7czoxMToiZ3ppcF9vdXRwdXQiO3M6MToibiI7czoyMToiZGVmYXVsdF9zaXRlX3RpbWV6b25lIjtzOjA6IiI7czoxMToiZGF0ZV9mb3JtYXQiO3M6ODoiJW4vJWovJVkiO3M6MTE6InRpbWVfZm9ybWF0IjtzOjI6IjEyIjtzOjEzOiJtYWlsX3Byb3RvY29sIjtzOjQ6Im1haWwiO3M6MTM6ImVtYWlsX25ld2xpbmUiO3M6MjoiXG4iO3M6MTE6InNtdHBfc2VydmVyIjtzOjA6IiI7czo5OiJzbXRwX3BvcnQiO047czoxMzoic210cF91c2VybmFtZSI7czowOiIiO3M6MTM6InNtdHBfcGFzc3dvcmQiO3M6MDoiIjtzOjE3OiJlbWFpbF9zbXRwX2NyeXB0byI7czozOiJzc2wiO3M6MTE6ImVtYWlsX2RlYnVnIjtzOjE6Im4iO3M6MTM6ImVtYWlsX2NoYXJzZXQiO3M6NToidXRmLTgiO3M6MTU6ImVtYWlsX2JhdGNobW9kZSI7czoxOiJuIjtzOjE2OiJlbWFpbF9iYXRjaF9zaXplIjtzOjA6IiI7czoxMToibWFpbF9mb3JtYXQiO3M6NToicGxhaW4iO3M6OToid29yZF93cmFwIjtzOjE6InkiO3M6MjI6ImVtYWlsX2NvbnNvbGVfdGltZWxvY2siO3M6MToiNSI7czoyMjoibG9nX2VtYWlsX2NvbnNvbGVfbXNncyI7czoxOiJ5IjtzOjE2OiJsb2dfc2VhcmNoX3Rlcm1zIjtzOjE6InkiO3M6MTk6ImRlbnlfZHVwbGljYXRlX2RhdGEiO3M6MToieSI7czoyNDoicmVkaXJlY3Rfc3VibWl0dGVkX2xpbmtzIjtzOjE6Im4iO3M6MTY6ImVuYWJsZV9jZW5zb3JpbmciO3M6MToibiI7czoxNDoiY2Vuc29yZWRfd29yZHMiO3M6MDoiIjtzOjE4OiJjZW5zb3JfcmVwbGFjZW1lbnQiO3M6MDoiIjtzOjEwOiJiYW5uZWRfaXBzIjtzOjA6IiI7czoxMzoiYmFubmVkX2VtYWlscyI7czowOiIiO3M6MTY6ImJhbm5lZF91c2VybmFtZXMiO3M6MDoiIjtzOjE5OiJiYW5uZWRfc2NyZWVuX25hbWVzIjtzOjA6IiI7czoxMDoiYmFuX2FjdGlvbiI7czo4OiJyZXN0cmljdCI7czoxMToiYmFuX21lc3NhZ2UiO3M6MzQ6IlRoaXMgc2l0ZSBpcyBjdXJyZW50bHkgdW5hdmFpbGFibGUiO3M6MTU6ImJhbl9kZXN0aW5hdGlvbiI7czoyMToiaHR0cDovL3d3dy55YWhvby5jb20vIjtzOjE2OiJlbmFibGVfZW1vdGljb25zIjtzOjE6InkiO3M6MTI6ImVtb3RpY29uX3VybCI7czoyNToie2Jhc2VfdXJsfWltYWdlcy9zbWlsZXlzLyI7czoxOToicmVjb3VudF9iYXRjaF90b3RhbCI7czo0OiIxMDAwIjtzOjE3OiJuZXdfdmVyc2lvbl9jaGVjayI7czoxOiJ5IjtzOjE3OiJlbmFibGVfdGhyb3R0bGluZyI7czoxOiJuIjtzOjE3OiJiYW5pc2hfbWFza2VkX2lwcyI7czoxOiJ5IjtzOjE0OiJtYXhfcGFnZV9sb2FkcyI7czoyOiIxMCI7czoxMzoidGltZV9pbnRlcnZhbCI7czoxOiI4IjtzOjEyOiJsb2Nrb3V0X3RpbWUiO3M6MjoiMzAiO3M6MTU6ImJhbmlzaG1lbnRfdHlwZSI7czo3OiJtZXNzYWdlIjtzOjE0OiJiYW5pc2htZW50X3VybCI7czowOiIiO3M6MTg6ImJhbmlzaG1lbnRfbWVzc2FnZSI7czo1MDoiWW91IGhhdmUgZXhjZWVkZWQgdGhlIGFsbG93ZWQgcGFnZSBsb2FkIGZyZXF1ZW5jeS4iO3M6MTc6ImVuYWJsZV9zZWFyY2hfbG9nIjtzOjE6InkiO3M6MTk6Im1heF9sb2dnZWRfc2VhcmNoZXMiO3M6MzoiNTAwIjtzOjExOiJydGVfZW5hYmxlZCI7czoxOiJ5IjtzOjIyOiJydGVfZGVmYXVsdF90b29sc2V0X2lkIjtzOjE6IjEiO3M6MTM6ImZvcnVtX3RyaWdnZXIiO047fQ==','YTo0Nzp7czoxMDoidW5fbWluX2xlbiI7czoxOiI0IjtzOjEwOiJwd19taW5fbGVuIjtzOjE6IjUiO3M6MjU6ImFsbG93X21lbWJlcl9yZWdpc3RyYXRpb24iO3M6MToibiI7czoyNToiYWxsb3dfbWVtYmVyX2xvY2FsaXphdGlvbiI7czoxOiJ5IjtzOjE4OiJyZXFfbWJyX2FjdGl2YXRpb24iO3M6NToiZW1haWwiO3M6MjM6Im5ld19tZW1iZXJfbm90aWZpY2F0aW9uIjtzOjE6Im4iO3M6MjM6Im1icl9ub3RpZmljYXRpb25fZW1haWxzIjtzOjA6IiI7czoyNDoicmVxdWlyZV90ZXJtc19vZl9zZXJ2aWNlIjtzOjE6InkiO3M6MjA6ImRlZmF1bHRfbWVtYmVyX2dyb3VwIjtzOjE6IjUiO3M6MTU6InByb2ZpbGVfdHJpZ2dlciI7czo2OiJtZW1iZXIiO3M6MTI6Im1lbWJlcl90aGVtZSI7czo3OiJkZWZhdWx0IjtzOjE0OiJlbmFibGVfYXZhdGFycyI7czoxOiJ5IjtzOjIwOiJhbGxvd19hdmF0YXJfdXBsb2FkcyI7czoxOiJuIjtzOjEwOiJhdmF0YXJfdXJsIjtzOjI1OiJ7YmFzZV91cmx9aW1hZ2VzL2F2YXRhcnMvIjtzOjExOiJhdmF0YXJfcGF0aCI7czoyNjoie2Jhc2VfcGF0aH1pbWFnZXMvYXZhdGFycy8iO3M6MTY6ImF2YXRhcl9tYXhfd2lkdGgiO3M6MzoiMTAwIjtzOjE3OiJhdmF0YXJfbWF4X2hlaWdodCI7czozOiIxMDAiO3M6MTM6ImF2YXRhcl9tYXhfa2IiO3M6MjoiNTAiO3M6MTM6ImVuYWJsZV9waG90b3MiO3M6MToibiI7czo5OiJwaG90b191cmwiO3M6MzE6IntiYXNlX3VybH1pbWFnZXMvbWVtYmVyX3Bob3Rvcy8iO3M6MTA6InBob3RvX3BhdGgiO3M6MToiLyI7czoxNToicGhvdG9fbWF4X3dpZHRoIjtzOjM6IjEwMCI7czoxNjoicGhvdG9fbWF4X2hlaWdodCI7czozOiIxMDAiO3M6MTI6InBob3RvX21heF9rYiI7czoyOiI1MCI7czoxNjoiYWxsb3dfc2lnbmF0dXJlcyI7czoxOiJ5IjtzOjEzOiJzaWdfbWF4bGVuZ3RoIjtzOjM6IjUwMCI7czoyMToic2lnX2FsbG93X2ltZ19ob3RsaW5rIjtzOjE6Im4iO3M6MjA6InNpZ19hbGxvd19pbWdfdXBsb2FkIjtzOjE6Im4iO3M6MTE6InNpZ19pbWdfdXJsIjtzOjM5OiJ7YmFzZV91cmx9aW1hZ2VzL3NpZ25hdHVyZV9hdHRhY2htZW50cy8iO3M6MTI6InNpZ19pbWdfcGF0aCI7czo0MDoie2Jhc2VfcGF0aH1pbWFnZXMvc2lnbmF0dXJlX2F0dGFjaG1lbnRzLyI7czoxNzoic2lnX2ltZ19tYXhfd2lkdGgiO3M6MzoiNDgwIjtzOjE4OiJzaWdfaW1nX21heF9oZWlnaHQiO3M6MjoiODAiO3M6MTQ6InNpZ19pbWdfbWF4X2tiIjtzOjI6IjMwIjtzOjE1OiJwcnZfbXNnX2VuYWJsZWQiO3M6MToieSI7czoyNToicHJ2X21zZ19hbGxvd19hdHRhY2htZW50cyI7czoxOiJ5IjtzOjE5OiJwcnZfbXNnX3VwbG9hZF9wYXRoIjtzOjMzOiJ7YmFzZV9wYXRofWltYWdlcy9wbV9hdHRhY2htZW50cy8iO3M6MjM6InBydl9tc2dfbWF4X2F0dGFjaG1lbnRzIjtzOjE6IjMiO3M6MjI6InBydl9tc2dfYXR0YWNoX21heHNpemUiO3M6MzoiMjUwIjtzOjIwOiJwcnZfbXNnX2F0dGFjaF90b3RhbCI7czozOiIxMDAiO3M6MTk6InBydl9tc2dfaHRtbF9mb3JtYXQiO3M6NDoic2FmZSI7czoxODoicHJ2X21zZ19hdXRvX2xpbmtzIjtzOjE6InkiO3M6MTc6InBydl9tc2dfbWF4X2NoYXJzIjtzOjQ6IjYwMDAiO3M6MTk6Im1lbWJlcmxpc3Rfb3JkZXJfYnkiO3M6OToibWVtYmVyX2lkIjtzOjIxOiJtZW1iZXJsaXN0X3NvcnRfb3JkZXIiO3M6NDoiZGVzYyI7czoyMDoibWVtYmVybGlzdF9yb3dfbGltaXQiO3M6MjoiMjAiO3M6Mjg6ImFwcHJvdmVkX21lbWJlcl9ub3RpZmljYXRpb24iO047czoyODoiZGVjbGluZWRfbWVtYmVyX25vdGlmaWNhdGlvbiI7Tjt9','YTo2OntzOjIyOiJlbmFibGVfdGVtcGxhdGVfcm91dGVzIjtzOjE6InkiO3M6MTE6InN0cmljdF91cmxzIjtzOjE6InkiO3M6ODoic2l0ZV80MDQiO3M6MDoiIjtzOjE5OiJzYXZlX3RtcGxfcmV2aXNpb25zIjtzOjE6Im4iO3M6MTg6Im1heF90bXBsX3JldmlzaW9ucyI7czoxOiI1IjtzOjE4OiJ0bXBsX2ZpbGVfYmFzZXBhdGgiO047fQ==','YToxMzp7czoyMzoiYXV0b19hc3NpZ25fY2F0X3BhcmVudHMiO3M6MToieSI7czoyMzoiYXV0b19jb252ZXJ0X2hpZ2hfYXNjaWkiO3M6MToibiI7czoyMzoiY29tbWVudF9lZGl0X3RpbWVfbGltaXQiO047czoyNzoiY29tbWVudF9tb2RlcmF0aW9uX292ZXJyaWRlIjtOO3M6MjI6ImNvbW1lbnRfd29yZF9jZW5zb3JpbmciO047czoxNToiZW5hYmxlX2NvbW1lbnRzIjtOO3M6MTg6ImltYWdlX2xpYnJhcnlfcGF0aCI7czowOiIiO3M6MjE6ImltYWdlX3Jlc2l6ZV9wcm90b2NvbCI7czozOiJnZDIiO3M6MjI6Im5ld19wb3N0c19jbGVhcl9jYWNoZXMiO3M6MToieSI7czoyMjoicmVzZXJ2ZWRfY2F0ZWdvcnlfd29yZCI7czo4OiJjYXRlZ29yeSI7czoxNjoidGh1bWJuYWlsX3ByZWZpeCI7czo1OiJ0aHVtYiI7czoxNzoidXNlX2NhdGVnb3J5X25hbWUiO3M6MToibiI7czoxNDoid29yZF9zZXBhcmF0b3IiO3M6NDoiZGFzaCI7fQ==','YToyOntzOjI2OiIvY29kZS9lZWNvbmYyMDE4L2luZGV4LnBocCI7czozMjoiNTBkNjkxOTc3NzQ1MTRjYmY5NmU2NGJkMmJlZmVkY2UiO3M6NzoiZW1haWxlZCI7YTowOnt9fQ==','');

/*!40000 ALTER TABLE `exp_sites` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_snippets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_snippets`;

CREATE TABLE `exp_snippets` (
  `snippet_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) NOT NULL,
  `snippet_name` varchar(75) COLLATE utf8mb4_unicode_ci NOT NULL,
  `snippet_contents` text COLLATE utf8mb4_unicode_ci,
  `edit_date` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`snippet_id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_specialty_templates
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_specialty_templates`;

CREATE TABLE `exp_specialty_templates` (
  `template_id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `enable_template` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'y',
  `template_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_title` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `template_type` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template_subtype` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template_data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `template_notes` text COLLATE utf8mb4_unicode_ci,
  `edit_date` int(10) NOT NULL DEFAULT '0',
  `last_author_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`template_id`),
  KEY `template_name` (`template_name`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_specialty_templates` WRITE;
/*!40000 ALTER TABLE `exp_specialty_templates` DISABLE KEYS */;

INSERT INTO `exp_specialty_templates` (`template_id`, `site_id`, `enable_template`, `template_name`, `data_title`, `template_type`, `template_subtype`, `template_data`, `template_notes`, `edit_date`, `last_author_id`)
VALUES
	(1,1,'y','offline_template','','system',NULL,'<html>\n<head>\n\n<title>System Offline</title>\n\n<style type=\"text/css\">\n\nbody {\nbackground-color:	#ffffff;\nmargin:				50px;\nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nfont-size:			11px;\ncolor:				#000;\nbackground-color:	#fff;\n}\n\na {\nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nfont-weight:		bold;\nletter-spacing:		.09em;\ntext-decoration:	none;\ncolor:			  #330099;\nbackground-color:	transparent;\n}\n\na:visited {\ncolor:				#330099;\nbackground-color:	transparent;\n}\n\na:hover {\ncolor:				#000;\ntext-decoration:	underline;\nbackground-color:	transparent;\n}\n\n#content  {\nborder:				#999999 1px solid;\npadding:			22px 25px 14px 25px;\n}\n\nh1 {\nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nfont-weight:		bold;\nfont-size:			14px;\ncolor:				#000;\nmargin-top: 		0;\nmargin-bottom:		14px;\n}\n\np {\nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nfont-size: 			12px;\nfont-weight: 		normal;\nmargin-top: 		12px;\nmargin-bottom: 		14px;\ncolor: 				#000;\n}\n</style>\n\n</head>\n\n<body>\n\n<div id=\"content\">\n\n<h1>System Offline</h1>\n\n<p>This site is currently offline</p>\n\n</div>\n\n</body>\n\n</html>',NULL,1540210616,0),
	(2,1,'y','message_template','','system',NULL,'<html>\n<head>\n\n<title>{title}</title>\n\n<meta http-equiv=\'content-type\' content=\'text/html; charset={charset}\' />\n\n{meta_refresh}\n\n<style type=\"text/css\">\n\nbody {\nbackground-color:	#ffffff;\nmargin:				50px;\nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nfont-size:			11px;\ncolor:				#000;\nbackground-color:	#fff;\n}\n\na {\nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nletter-spacing:		.09em;\ntext-decoration:	none;\ncolor:			  #330099;\nbackground-color:	transparent;\n}\n\na:visited {\ncolor:				#330099;\nbackground-color:	transparent;\n}\n\na:active {\ncolor:				#ccc;\nbackground-color:	transparent;\n}\n\na:hover {\ncolor:				#000;\ntext-decoration:	underline;\nbackground-color:	transparent;\n}\n\n#content  {\nborder:				#000 1px solid;\nbackground-color: 	#DEDFE3;\npadding:			22px 25px 14px 25px;\n}\n\nh1 {\nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nfont-weight:		bold;\nfont-size:			14px;\ncolor:				#000;\nmargin-top: 		0;\nmargin-bottom:		14px;\n}\n\np {\nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nfont-size: 			12px;\nfont-weight: 		normal;\nmargin-top: 		12px;\nmargin-bottom: 		14px;\ncolor: 				#000;\n}\n\nul {\nmargin-bottom: 		16px;\n}\n\nli {\nlist-style:			square;\nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nfont-size: 			12px;\nfont-weight: 		normal;\nmargin-top: 		8px;\nmargin-bottom: 		8px;\ncolor: 				#000;\n}\n\n</style>\n\n</head>\n\n<body>\n\n<div id=\"content\">\n\n<h1>{heading}</h1>\n\n{content}\n\n<p>{link}</p>\n\n</div>\n\n</body>\n\n</html>',NULL,1540210616,0),
	(3,1,'y','admin_notify_reg','Notification of new member registration','email','members','New member registration site: {site_name}\n\nScreen name: {name}\nUser name: {username}\nEmail: {email}\n\nYour control panel URL: {control_panel_url}',NULL,1540210616,0),
	(4,1,'y','admin_notify_entry','A new channel entry has been posted','email','content','A new entry has been posted in the following channel:\n{channel_name}\n\nThe title of the entry is:\n{entry_title}\n\nPosted by: {name}\nEmail: {email}\n\nTo read the entry please visit:\n{entry_url}\n',NULL,1540210616,0),
	(5,1,'y','admin_notify_comment','You have just received a comment','email','comments','You have just received a comment for the following channel:\n{channel_name}\n\nThe title of the entry is:\n{entry_title}\n\nLocated at:\n{comment_url}\n\nPosted by: {name}\nEmail: {email}\nURL: {url}\nLocation: {location}\n\n{comment}',NULL,1540210616,0),
	(6,1,'y','mbr_activation_instructions','Enclosed is your activation code','email','members','Thank you for your new member registration.\n\nTo activate your new account, please visit the following URL:\n\n{unwrap}{activation_url}{/unwrap}\n\nThank You!\n\n{site_name}\n\n{site_url}',NULL,1540210616,0),
	(7,1,'y','forgot_password_instructions','Login information','email','members','{name},\n\nTo reset your password, please go to the following page:\n\n{reset_url}\n\nThen log in with your username: {username}\n\nIf you do not wish to reset your password, ignore this message. It will expire in 24 hours.\n\n{site_name}\n{site_url}',NULL,1540210616,0),
	(8,1,'y','password_changed_notification','Password changed','email','members','{name},\n\nYour password was just changed.\n\nIf you didn\'t make this change yourself, please contact an administrator right away.\n\n{site_name}\n{site_url}',NULL,1540210616,0),
	(9,1,'y','email_changed_notification','Email address changed','email','members','{name},\n\nYour email address has been changed, and this email address is no longer associated with your account.\n\nIf you didn\'t make this change yourself, please contact an administrator right away.\n\n{site_name}\n{site_url}',NULL,1540210616,0),
	(10,1,'y','validated_member_notify','Your membership account has been activated','email','members','{name},\n\nYour membership account has been activated and is ready for use.\n\nThank You!\n\n{site_name}\n{site_url}',NULL,1540210616,0),
	(11,1,'y','decline_member_validation','Your membership account has been declined','email','members','{name},\n\nWe\'re sorry but our staff has decided not to validate your membership.\n\n{site_name}\n{site_url}',NULL,1540210616,0),
	(12,1,'y','comment_notification','Someone just responded to your comment','email','comments','{name_of_commenter} just responded to the entry you subscribed to at:\n{channel_name}\n\nThe title of the entry is:\n{entry_title}\n\nYou can see the comment at the following URL:\n{comment_url}\n\n{comment}\n\nTo stop receiving notifications for this comment, click here:\n{notification_removal_url}',NULL,1540210616,0),
	(13,1,'y','comments_opened_notification','New comments have been added','email','comments','Responses have been added to the entry you subscribed to at:\n{channel_name}\n\nThe title of the entry is:\n{entry_title}\n\nYou can see the comments at the following URL:\n{comment_url}\n\n{comments}\n{comment}\n{/comments}\n\nTo stop receiving notifications for this entry, click here:\n{notification_removal_url}',NULL,1540210616,0),
	(14,1,'y','private_message_notification','Someone has sent you a Private Message','email','private_messages','\n{recipient_name},\n\n{sender_name} has just sent you a Private Message titled ‘{message_subject}’.\n\nYou can see the Private Message by logging in and viewing your inbox at:\n{site_url}\n\nContent:\n\n{message_content}\n\nTo stop receiving notifications of Private Messages, turn the option off in your Email Settings.\n\n{site_name}\n{site_url}',NULL,1540210616,0),
	(15,1,'y','pm_inbox_full','Your private message mailbox is full','email','private_messages','{recipient_name},\n\n{sender_name} has just attempted to send you a Private Message,\nbut your inbox is full, exceeding the maximum of {pm_storage_limit}.\n\nPlease log in and remove unwanted messages from your inbox at:\n{site_url}',NULL,1540210616,0);

/*!40000 ALTER TABLE `exp_specialty_templates` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_stats
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_stats`;

CREATE TABLE `exp_stats` (
  `stat_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `total_members` mediumint(7) NOT NULL DEFAULT '0',
  `recent_member_id` int(10) NOT NULL DEFAULT '0',
  `recent_member` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_entries` mediumint(8) NOT NULL DEFAULT '0',
  `total_forum_topics` mediumint(8) NOT NULL DEFAULT '0',
  `total_forum_posts` mediumint(8) NOT NULL DEFAULT '0',
  `total_comments` mediumint(8) NOT NULL DEFAULT '0',
  `last_entry_date` int(10) unsigned NOT NULL DEFAULT '0',
  `last_forum_post_date` int(10) unsigned NOT NULL DEFAULT '0',
  `last_comment_date` int(10) unsigned NOT NULL DEFAULT '0',
  `last_visitor_date` int(10) unsigned NOT NULL DEFAULT '0',
  `most_visitors` mediumint(7) NOT NULL DEFAULT '0',
  `most_visitor_date` int(10) unsigned NOT NULL DEFAULT '0',
  `last_cache_clear` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`stat_id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_stats` WRITE;
/*!40000 ALTER TABLE `exp_stats` DISABLE KEYS */;

INSERT INTO `exp_stats` (`stat_id`, `site_id`, `total_members`, `recent_member_id`, `recent_member`, `total_entries`, `total_forum_topics`, `total_forum_posts`, `total_comments`, `last_entry_date`, `last_forum_post_date`, `last_comment_date`, `last_visitor_date`, `most_visitors`, `most_visitor_date`, `last_cache_clear`)
VALUES
	(1,1,1,2,'admin',4,0,0,0,1540221000,0,0,0,0,0,1540818743);

/*!40000 ALTER TABLE `exp_stats` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_status_no_access
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_status_no_access`;

CREATE TABLE `exp_status_no_access` (
  `status_id` int(6) unsigned NOT NULL,
  `member_group` smallint(4) unsigned NOT NULL,
  PRIMARY KEY (`status_id`,`member_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_statuses
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_statuses`;

CREATE TABLE `exp_statuses` (
  `status_id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_order` int(3) unsigned NOT NULL,
  `highlight` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_statuses` WRITE;
/*!40000 ALTER TABLE `exp_statuses` DISABLE KEYS */;

INSERT INTO `exp_statuses` (`status_id`, `status`, `status_order`, `highlight`)
VALUES
	(1,'open',1,'009933'),
	(2,'closed',2,'990000');

/*!40000 ALTER TABLE `exp_statuses` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_template_groups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_template_groups`;

CREATE TABLE `exp_template_groups` (
  `group_id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `group_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_order` int(3) unsigned NOT NULL,
  `is_site_default` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  PRIMARY KEY (`group_id`),
  KEY `site_id` (`site_id`),
  KEY `group_name_idx` (`group_name`),
  KEY `group_order_idx` (`group_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_template_groups` WRITE;
/*!40000 ALTER TABLE `exp_template_groups` DISABLE KEYS */;

INSERT INTO `exp_template_groups` (`group_id`, `site_id`, `group_name`, `group_order`, `is_site_default`)
VALUES
	(1,1,'site',1,'y'),
	(2,1,'blog',2,'n'),
	(3,1,'includes',3,'n');

/*!40000 ALTER TABLE `exp_template_groups` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_template_member_groups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_template_member_groups`;

CREATE TABLE `exp_template_member_groups` (
  `group_id` smallint(4) unsigned NOT NULL,
  `template_group_id` mediumint(5) unsigned NOT NULL,
  PRIMARY KEY (`group_id`,`template_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_template_no_access
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_template_no_access`;

CREATE TABLE `exp_template_no_access` (
  `template_id` int(6) unsigned NOT NULL,
  `member_group` smallint(4) unsigned NOT NULL,
  PRIMARY KEY (`template_id`,`member_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_template_routes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_template_routes`;

CREATE TABLE `exp_template_routes` (
  `route_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template_id` int(10) unsigned NOT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `route` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `route_parsed` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `route_required` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  PRIMARY KEY (`route_id`),
  KEY `template_id` (`template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_templates
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_templates`;

CREATE TABLE `exp_templates` (
  `template_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `group_id` int(6) unsigned NOT NULL,
  `template_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `template_type` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'webpage',
  `template_data` mediumtext COLLATE utf8mb4_unicode_ci,
  `template_notes` text COLLATE utf8mb4_unicode_ci,
  `edit_date` int(10) NOT NULL DEFAULT '0',
  `last_author_id` int(10) unsigned NOT NULL DEFAULT '0',
  `cache` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `refresh` int(6) unsigned NOT NULL DEFAULT '0',
  `no_auth_bounce` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `enable_http_auth` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `allow_php` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  `php_parse_location` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'o',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `protect_javascript` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  PRIMARY KEY (`template_id`),
  KEY `group_id` (`group_id`),
  KEY `template_name` (`template_name`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_templates` WRITE;
/*!40000 ALTER TABLE `exp_templates` DISABLE KEYS */;

INSERT INTO `exp_templates` (`template_id`, `site_id`, `group_id`, `template_name`, `template_type`, `template_data`, `template_notes`, `edit_date`, `last_author_id`, `cache`, `refresh`, `no_auth_bounce`, `enable_http_auth`, `allow_php`, `php_parse_location`, `hits`, `protect_javascript`)
VALUES
	(1,1,1,'index','webpage','',NULL,1540213607,0,'n',0,'','n','n','o',0,'n'),
	(2,1,1,'_layout','webpage','<!doctype html>\n<html lang=\"en\">\n<head>\n	{embed=\"includes/head\" title=\"{layout:title}\"}\n</head>\n<body>\n	{embed=\"includes/header\"}\n	<div class=\"main_content\">\n		<div class=\"container\">\n			{layout:contents}\n		</div>\n	</div>\n	{embed=\"includes/footer\"}\n</body>\n</html>',NULL,1540226128,0,'n',0,'','n','n','o',0,'n'),
	(3,1,2,'index','webpage','{layout=\"site/_layout\"}\n\n{if segment_2 == \'\'}{redirect=\"{site_url}\"}{/if}\n\n{exp:channel:entries\n    channel=\"blog\"\n    limit=\"1\"\n}\n    {layout:set name=\'title\'}{title} | {site_name}{/layout:set}\n\n    {embed=\"blog/_article_1\"\n        single=\"yes\"\n        entry_id=\"{entry_id}\"\n    }\n{/exp:channel:entries}',NULL,1540307983,0,'n',0,'','n','n','o',0,'n'),
	(4,1,3,'logo_svg','webpage','<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<svg version=\"1.1\" id=\"Layer_1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\"\n viewBox=\"0 0 226 345\" style=\"enable-background:new 0 0 226 345;\" xml:space=\"preserve\">\n    <style type=\"text/css\">\n        .st0{fill:#FF3600;}\n        .st1{fill:#FFFFFF;}\n    </style>\n    <g>\n        <g>\n            <path class=\"st0\" d=\"M180.2,113c-10.3-22.6-34.6-50.7-34.6-50.7c3.9,20.5,0.9,36.9-4.5,49.6c-2.8-3.3-5.7-6.4-8.5-9.5\n                c-37.9-40.1-2.2-95.5-2.2-95.5c-90,53.3-59.5,151.6-59.5,151.6c-25.5-21.2-26-58-26-58c-53.7,115.1,0.3,166.1,26.6,179.6\n                c17.5,9,46.1,11.2,61,7.4C220.6,265.3,203.4,163.9,180.2,113z\"/>\n            <g>\n                <g>\n                    <polygon class=\"st1\" points=\"87,216.3 87,216.3 87,216.3 				\"/>\n                </g>\n                <g>\n                    <path class=\"st1\" d=\"M132.8,103c-0.1,0.5,0.3,0.6,0.3,1c0.5,0.6,0.3,1.8,1,2.2c-0.1,0.5,0.3,0.6,0.3,1c-0.1,0.8,0.6,0.7,0.3,1.6\n                        c0.7,0.1,0.3,1.2,1,1.3c0.7,0,0.1-1.4,0.3-1.9c0.2-1-0.3-1.2-0.3-1.9c-0.1-0.7-0.4-1.3-0.6-1.9c-0.2-0.9-0.9-1.2-1.3-1.9\n                        C133.2,102.4,132.9,102.6,132.8,103z\"/>\n                </g>\n                <g>\n                    <path class=\"st1\" d=\"M102.1,187.4c0.1-0.8,1-0.7,1.3-1.3c0.6-0.3,0.9-0.8,1.6-1c0.5-0.7,0.6-1.7,1.3-2.2c0.2-1,0.6-2,1-2.9\n                        c0.3-0.4,0.3-1.2,0.6-1.6c0.2-0.3,0.3-0.5,0.3-1c0.2-0.3,0.3-0.5,0.3-1c0.4-0.7,0.8-1.3,1.3-1.9c0.2-1,0.6-1.8,1-2.6\n                        c0.8-1.3,1.8-2.5,2.6-3.8c0.7-0.3,0.8-1.1,1.3-1.6c0.9-0.6,1.2-1.8,1.9-2.6c0-0.6-0.4-0.7-0.3-1.3c-1.2-0.3-0.5,1.2-1.6,1\n                        c-0.2,0.3-0.6,0.5-1,0.6c-0.5,0.4-1,0.9-1.6,1.3c-0.1,0-0.2,0-0.3,0c0,0.1,0,0.2,0,0.3c-1,0.7-1.8,1.6-2.6,2.6\n                        c-0.4,0.1-0.5,0.6-1,0.6c-0.3,0.6-0.6,1.4-1.3,1.6c0.2,0.9-0.6,0.6-0.6,1.3c-0.1,0-0.2,0-0.3,0c0.1,1.1-1,1.2-1,2.2\n                        c-1.1,0.5-1,2.2-1.9,2.9c0.1,0.6-0.4,0.7-0.3,1.3c-0.1,0-0.2,0-0.3,0c-0.2,1-0.7,1.9-1.3,2.6c0.2,1-0.5,1.2-0.6,1.9\n                        c0.1,0.8-0.6,0.7-0.3,1.6c-0.5,0.1-0.1,1-0.6,1c-0.1,0.4,0.1,0.9-0.3,1c-0.1,0.2,0,0.6-0.3,0.6c0.2,1-0.5,1.2-0.6,1.9\n                        c-0.1,0-0.2,0-0.3,0c-0.4,0.9-0.5,2-1.9,1.9c0-0.5,0-1.1,0-1.6c0.2-0.9,0.5-1.7,0.6-2.6c0-0.1,0-0.2,0-0.3\n                        c0.1-0.2,0-0.6,0.3-0.6c0-0.3,0-0.6,0-1c-0.1-0.4,0.1-0.6,0.3-0.6c0-0.3,0-0.6,0-1c-0.1-0.7,0.1-1.2,0.3-1.6\n                        c0-1.1,0.5-1.8,0.6-2.9c-0.3,0.1-0.3,0.3-0.6,0.3c-0.6,1.4-1.6,2.5-2.6,3.5c0,0.2,0,0.4,0,0.6c-0.1,0-0.2,0-0.3,0\n                        c-0.2,0.5-0.5,0.8-0.6,1.3c-0.2,0.1-0.4,0.3-0.3,0.6c-0.7,0.3-0.8,1.1-1.3,1.6c-0.2,0.4-0.3,0.7-0.6,1c-0.4,0.5-0.4,1.3-1,1.6\n                        c0,0.2,0,0.4,0,0.6c-1.9,3.3-4,6.4-4.2,11.5c-0.3,0.8-0.4,2-0.3,3.2c0.5-0.6,0.7-1.4,1-2.2c1.1-1.6,1.3-4,2.6-5.4\n                        c0.7-0.7,1-1.8,1.9-2.2c0-0.1,0-0.2,0-0.3c0.1,0,0.2,0,0.3,0c0-0.5,0.2-0.8,0.6-1c1,0,1.1-0.8,1.9-1c0.8,0.1-0.4,0.5,0,1.3\n                        c-0.1,1.8-1.1,2.7-1,4.8c0,2.1,0,4.3,0,6.4c1.1-1.7,1.5-4.1,1.9-6.4c0.7-0.6,0.5-2.2,1.3-2.9c0.2-1.5,0.9-2.5,1.6-3.5\n                        c0-0.2,0-0.4,0-0.6C100,190.4,100.6,188.4,102.1,187.4z\"/>\n                </g>\n                <g>\n                    <path class=\"st1\" d=\"M83.5,205c-0.1,0.4,0,0.7,0.2,1C83.6,205.7,83.5,205.4,83.5,205z\"/>\n                </g>\n                <g>\n                    <path class=\"st1\" d=\"M103,250.3c-0.7,0.3-0.1,2-0.3,2.9c0.5,2.1,0.5,6.5,0,8.6c0,0.7,0,1.5,0,2.2c0,0.7,0,1.5,0,2.2\n                        c-0.2,1.2,0.5,1.4,0.3,2.6c0,0.2,0,0.4,0,0.6c0.2,1.4,0.5,2.7,1,3.8c3.5,2.1,9,0.2,13.1,0c-0.9-2.2-2.5-3.7-3.2-6.1\n                        c-0.3-0.8-0.4-1.7-0.3-2.9c0-0.4-0.1-0.9,0.3-1c1.5,1.2,2.6,2.7,4.8,3.2c0.2-5.2-1.1-8.9-1.9-13.1c-0.7-0.1-0.1-1.4-0.6-1.6\n                        c0-0.2,0-0.4,0-0.6c-1.1-1.9-2.4-3.6-3.5-5.4c-0.4-0.1-0.5-0.4-0.6-0.6c-0.1,0-0.2,0-0.3,0c-0.9-2-3-3-4.2-4.8\n                        c-0.7,2.8,3.3,5,1.9,8.6c-1.4-0.2-1.7-1.5-2.6-2.2c-0.3-0.9-1-1.4-1.3-2.2c-0.3-0.1-0.3-0.3-0.6-0.3c-1.3,3.9,2.6,7.2,4.2,10.2\n                        c0.5,0.6-0.1,0.8,0.3,1.9c-0.4,0.3-0.9,0.4-1.6,0.3c0-0.1,0-0.2,0-0.3C105.9,254.7,104.7,252.3,103,250.3z\"/>\n                </g>\n                <g>\n                    <path class=\"st1\" d=\"M116.8,250.5c0.2-0.2,0.4-0.4,0.6-0.6C117.2,250.1,117,250.3,116.8,250.5\n                        C116.8,250.5,116.8,250.5,116.8,250.5z\"/>\n                </g>\n                <g>\n                    <path class=\"st1\" d=\"M118.1,280c-2.1-1.5-7.2-0.4-8.6-1.6c0.9-1.1,3.2-0.8,4.2-1.9c0.7,0.1,1.2-0.1,1.6-0.3\n                        c1.3-0.2,2.2-0.8,3.2-1.3c-4-1.2-8.6,1.3-12.8,0c-0.3-0.1-0.3-0.3-0.6-0.3c-0.7-0.2-0.5,0.6-1,0.6c0,0.1,0,0.2,0,0.3\n                        c-0.6,0.6-0.8,0-1.6,0c0,1,1.1,1.4,0.3,2.2c-0.9,0.3-0.8-0.4-1.6-0.3c-0.7,0.4-1.2,0.9-1.6,1.6c-0.1,0-0.2,0-0.3,0\n                        c0,0.1,0,0.2,0,0.3c-0.5,0.1-0.5,0.5-1,0.6c-0.1,0.4-0.4,0.7-1,0.6c-1.3,1.2-3.9,1.2-5.4,2.2c2.1,1.7,5.7-0.3,7.7-1\n                        c0-0.1,0-0.2,0-0.3c1.1-0.3,1-1.8,2.6-1.6c0.7,0.9,2.6,0.6,4.2,0.6c0-0.1,0-0.2,0-0.3c0.3,0.1,0.3-0.1,0.3-0.3\n                        c2.6,1.5,7.6-0.1,11.2,1.3C118.2,281.2,118,280.5,118.1,280z\"/>\n                </g>\n                <g>\n                    <path class=\"st1\" d=\"M43.3,241.3c0-0.3,0-0.6,0-0.9C43.3,240.7,43.3,241.1,43.3,241.3z\"/>\n                </g>\n                <g>\n                    <path class=\"st1\" d=\"M53.2,234.7c0,0.3-0.3,0.4-0.3,0.6c-0.3,0.7-0.7,1.3-1,1.9c0.1,0.3-0.1,0.3-0.3,0.3\n                        c0.1,0.4-0.1,0.6-0.3,0.6c0,0.3,0,0.6,0,1c-0.3-0.1-0.3,0.1-0.3,0.3c-0.4,1.7-0.6,3.7-1.3,5.1c0,0.1,0,0.2,0,0.3\n                        c0,0.4,0,0.9,0,1.3c0.1,0,0.2,0,0.3,0c0,0.2,0,0.4,0,0.6c1.3,1,2.1-0.7,2.9-1.3c0-0.3,0.3-0.4,0.3-0.6c0.1,0,0.2,0,0.3,0\n                        c0.6-1,0.2-3,0.3-4.5c-0.5-0.9-0.5-3.9,0-4.8c-0.1-0.7,0.1-1.2,0.3-1.6C53.4,233.8,53.7,234.6,53.2,234.7z\"/>\n                </g>\n                <g>\n                    <path class=\"st1\" d=\"M28.3,217.1c-0.8,0.3-1.5,0.8-1.9,1.6c-0.1,0-0.2,0-0.3,0c-0.3,0-0.4,0.3-0.6,0.3c-0.5,0.8-1.1,1.4-1.9,1.9\n                        c0.1,0.3-0.1,0.3-0.3,0.3c-0.2,0.7-1.1,0.9-1.3,1.6c-1.8,1.6-2.9,3.9-4.2,6.1c0.2,0.7-0.9,1,0.3,1c0.3-0.4,0.9-0.6,1.3-1\n                        c0.1,0,0.2,0,0.3,0c0.1-0.4,0.5-0.3,1-0.3c1.6-1.6,2.6-3.8,4.2-5.4c0.1-0.7,0.9-0.6,1-1.3c0-0.1,0-0.2,0-0.3\n                        c0.5-0.2,0.8-0.5,1-1c0.3,0.1,0.3-0.1,0.3-0.3c1.2-0.5,2-1.4,2.9-2.2c1.3-0.7,2.6-1.4,3.5-2.6c0.9,0.2,0.6-0.6,1.3-0.6\n                        c0.5-0.6,1.2-0.9,1.9-1.3c0-0.1,0-0.2,0-0.3c-1.2,0.2-2.3,0.5-3.2,1C31.2,214.6,29.6,215.7,28.3,217.1z\"/>\n                </g>\n                <g>\n                    <path class=\"st1\" d=\"M70.1,214.5c0.8-0.1,1-1,1.9-1c0.1,0,0.2,0,0.3,0c0.5-0.4,1-0.9,1.6-1.3c0.6-0.3,1-0.7,1.3-1.3\n                        c-1.2-0.7-3.8,0-5.1-0.6c-1.5-0.6-2.4-1.9-4.2-2.2c-2-1.2-4.5-1.9-7.3-2.2c-2.1-0.8-4.7-1.1-7.7-1c-1.3,0-2.6,0-3.8,0\n                        c-0.1,0.2-0.3,0.4-0.6,0.3c-0.9,0.4-2.5,0.1-3.2,0.6c-0.8,0-1.8-0.1-2.2,0.3c-0.2,0-0.4,0-0.6,0c-0.9,0.3-2.2,0.1-2.9,0.6\n                        c-2.5,0.2-4.9,0.5-5.8,2.2c2.5,0.2,4.4-0.3,6.4-0.6c0-0.1,0-0.2,0-0.3c0.5,0,1.1,0,1.6,0c2.4,0,4.9,0,7.3,0c0.5,0,1.1,0,1.6,0\n                        c1.2-0.1,2.1,0.1,2.9,0.3c1.2,0.1,2.3,0.3,3.2,0.6c0.3,0,0.6,0,1,0c0.1,0,0.2,0,0.3,0c1.5,0.7,3.6,0.9,4.8,1.9\n                        c0.3,1.5-1.2,1.3-1.9,1.9c-0.5,0.1-0.5,0.5-1,0.6c-0.8,0.1-0.6,1.1-1.6,1c-0.1,0.4-0.7,0.4-1,0.6c-0.3,0.6-0.7,1-1.3,1.3\n                        c-0.9,0.9-1.5,2.1-2.6,2.9c-0.3,0.6-0.7,1-1.3,1.3c-0.7,1.5-2,2.5-2.6,4.2c0,0.3-0.3,0.4-0.3,0.6c-0.5,0.4-0.5,1.4-1,1.9\n                        c-0.1,0.3-0.3,0.3-0.3,0.6c-0.3,0.7-0.5,1.6-1,2.2c0,0.2,0,0.4-0.3,0.3c0.2,1.2-0.7,1.2-0.6,2.2c0.1,0,0.2,0,0.3,0\n                        c0.6-0.9,0.9-2,1.9-2.6c0.9-2.2,2.6-3.6,3.8-5.4c0.3-0.6,0.7-1,1.3-1.3c0-0.4,0.2-0.7,0.3-1c0.7-0.6,1.7-1.1,1.9-2.2\n                        c1.7-1,2.5-3.1,4.5-3.8c0.3-0.6,0.7-1,1.3-1.3c0.3-0.7,1.5-0.4,1.6-1.3c1.1-0.1,1.4-0.9,2.9-0.6c0,0.4,0.4,0.4,0.3,1\n                        c-1.1,1-2.4,1.8-3.5,2.9c-0.1,0.5-0.5,0.5-0.6,1c-0.7,0.2-0.9,1.1-1.6,1.3c0.2,1-0.9,0.6-0.6,1.6c0.1,0,0.2,0,0.3,0\n                        c0-0.1,0-0.2,0-0.3c0.6-0.1,0.8-0.7,1.6-0.6c1,0,1.4-0.7,2.6-0.6c1-0.3,1.4-1.2,2.2-1.6c0.5-0.1,0.5-0.5,1-0.6\n                        c0.5-0.4,0.8-0.9,1.6-1c0-0.1,0-0.2,0-0.3c0.8,0,1-0.5,1.6-0.6C69.1,214.7,69.5,214.6,70.1,214.5z\"/>\n                </g>\n                <g>\n                    <path class=\"st1\" d=\"M81.3,220.6c0-0.3,0-0.6,0-1c0-0.8,0.5-0.9,0.3-1.9c0-0.6,0-1.3,0-1.9c0-0.2,0-0.4,0-0.6c0-0.1,0-0.2,0-0.3\n                        c-0.4-0.1-0.3-0.6-0.3-1c-1.7,0.5-2.1,2.2-3.5,2.9c-0.2,0.7-0.8,0.9-0.6,1.9c-0.9-0.2,0.2,1.5-0.6,1.3c0,0.4,0,0.9,0,1.3\n                        c-0.4,0.1-0.3,0.8-0.3,1.3c0,0.2,0,0.4,0,0.6c0,0.4,0,0.9,0,1.3c0,1.2,0,2.3,0,3.5c0,0.1,0,0.2,0,0.3c0,0.7,0,1.5,0,2.2\n                        c0.1,0,0.2,0,0.3,0c-0.2,2.4,0.5,3.7,0.3,6.1c0,0.2,0,0.4,0,0.6c0.5,0.5,0.5,1.4,0.6,2.2c0,0.1,0,0.2,0,0.3\n                        c0,1.1,0.5,1.6,0.3,2.9c0,0.1,0,0.2,0,0.3c0.3,1.2,0.3,2.7,0.6,3.8c0.1,0,0.2,0,0.3,0c0-0.1,0-0.2,0-0.3c0-1,0-1.9,0-2.9\n                        c-0.8-0.8,0.2-1.4,0-2.6c0-0.7,0-1.5,0-2.2c0.2-2.3,0.8-4.1,1.6-5.8c0.4-0.4,0.4-1.1,0.3-1.9c0-1.2,0-2.3,0-3.5\n                        c0.3,0.1,0.3-0.1,0.3-0.3c0.4-0.8-0.7-1.6,0-1.6c0.2-1.1,0.5-2.1,0.3-3.5c0-0.1,0-0.2,0-0.3C81.3,221.4,81.3,221,81.3,220.6z\"/>\n                </g>\n                <g>\n                    <path class=\"st1\" d=\"M73.3,216.8c-2.6,3.8-4.6,8.2-5.1,14.1c-0.6,1-0.4,4,0.6,4.5c-0.1-0.3,0.1-0.3,0.3-0.3c0-0.1,0-0.2,0-0.3\n                        c1.2-0.4,0.9-2.2,1-3.8c0.4-0.1,0.3-0.6,0.3-1c0-0.8,0-1.5,0.3-1.9c-0.1-1.1,0.1-1.8,0.3-2.6c-0.1-0.5,0.3-0.5,0.3-1\n                        c0-0.1,0-0.2,0-0.3c0.9-2,1.5-4.4,2.9-6.1c0.5-1,1-2,1.6-2.9c0-0.3,0-0.6,0-1C74.7,214.7,74.5,216.3,73.3,216.8z\"/>\n                </g>\n                <g>\n                    <polygon class=\"st1\" points=\"83.5,205 83.5,205 83.6,205 				\"/>\n                </g>\n                <g>\n                    <path class=\"st1\" d=\"M116.4,250.8c0,0-0.1-0.1-0.1,0C116.3,250.7,116.4,250.8,116.4,250.8z\"/>\n                </g>\n                <g>\n                    <path class=\"st1\" d=\"M123.2,204c0.1,0.5,0.4,0.4,0,0.9C123.6,204.4,123.3,204.4,123.2,204z\"/>\n                </g>\n                <g>\n                    <path class=\"st1\" d=\"M126.4,92.1c1.2-0.8,2.6-1.5,2.6-3.5c-0.6-0.9-1.5-1.5-3.2-1.3c-0.2,1.2,1.9,0.3,1.9,1.3\n                        c0.1,1.9-1.1,2.5-3.2,2.2C124.6,91.7,125.3,92.1,126.4,92.1z\"/>\n                </g>\n                <g>\n                    <path class=\"st1\" d=\"M122.5,182.9c0,0.5,0,1,0,1.4C122.6,183.9,122.5,183.4,122.5,182.9z\"/>\n                </g>\n                <g>\n                    <path class=\"st1\" d=\"M165,148.4c0-0.6,0-1.3,0-1.9c-0.2-0.3-0.3-0.7-0.3-1.3c0-0.1,0-0.2,0-0.3c-0.2-4.4,0.1-8.4-2.6-10.9\n                        c-1.4-2.8-2.9-5.4-5.1-7.3c0-0.3-0.4-0.2-0.6-0.3c-0.2-0.5-0.5-0.8-1-1c-0.8-0.5-1.4-1.1-2.2-1.6c-0.5-0.5-1.4-0.7-1.9-1.3\n                        c-0.1,0-0.2,0-0.3,0c-0.5-0.5-1.5-0.4-1.9-1c-0.2,0-0.4,0-0.6,0c0-0.2,0-0.4-0.3-0.3c-0.6,0.1-0.7-0.4-1.3-0.3\n                        c-0.6,0-1-0.1-1.3-0.3c-0.6,0-0.7-0.4-1.3-0.3c-0.6-0.4-1.9-0.1-2.2-0.6c-1.4,0.2-2.1-0.2-3.2-0.3c-1.3,0.1-1.8-0.6-3.2-0.3\n                        c-0.7-0.5-2.1-0.2-2.9-0.6c-0.7-0.4-1.7-0.7-2.6-1c-0.3-0.8-1.3-1.1-1.6-1.9c-0.5-0.8-1.1-1.4-1.6-2.2c-1.6,0.1-3.1,0.1-3.8-0.6\n                        c-0.4-0.3-1.2-0.3-1.3-1c0-0.3-0.3-0.4-0.3-0.6c-0.4-0.4-0.4-1.1-0.3-1.9c0-1.2,0.1-2.2,0.6-2.9c0-0.4-0.1-0.8-0.6-0.6\n                        c-1.3-0.2-2-0.9-2.2-2.2c-0.5,0-0.5-2.2,0-2.2c0,0.5,0.9,0.2,1,0.6c0.3,0,0.6,0,1,0c-0.2-1.5-0.5-2.4,0.6-3.2\n                        c0.4-0.4,1.2-0.4,1.6,0c0,0.1,0,0.2,0,0.3c0.7,0.6,0.2,2.4,1,2.9c-0.3,1,0.7,0.6,1.3,0.6c0.3-0.2,0.5-0.3,1-0.3\n                        c0.6-0.2-0.1-1.8,0.6-1.9c0-0.1,0-0.2,0-0.3c0.4-0.3,1.2-0.3,1.6-0.6c0.1-0.7,0.9-0.6,1-1.3c0.1,0,0.2,0,0.3,0\n                        c0.5,0,0.9-0.1,1,0.3c3.2,0,4.7-1.6,7-2.6c0.5-0.4,1-0.9,1.6-1.3c0.3,0,0.2-0.4,0.3-0.6c-1-0.1-1.1,0.8-2.2,0.6\n                        c-0.7,0.8-2.1,0.9-3.2,1.3c-0.7,0.2-2.1-0.4-2.2,0.3c-0.2,0-0.4,0-0.6,0c-0.3-0.2-0.7-0.3-1.3-0.3c0.1-0.7-0.1-1.2-0.3-1.6\n                        c0-0.8,0.5-1,0.6-1.6c-0.1-0.8,0.6-0.7,0.3-1.6c0.8-1.1,1.3-2.3,2.2-3.2c0.5-1.1,1.7-1.5,2.6-2.2c1.2-0.8,5.5-1.2,4.5-2.2\n                        c-1,0.2-1.1-0.6-2.2-0.3c-1.1,0.2-3-0.4-3.5,0.3c-0.2,0-0.4,0-0.6,0c-0.9,0.2-2,0.4-2.6,1c-0.1,0.5-0.5,0.5-0.6,1\n                        c-0.8,0-1.1-0.6-1.6-1c-0.3-0.2-0.5-0.3-1-0.3c-1.7-1.2-5.2-2.2-8-1.3c-1.2-0.1-1.5,0.6-2.2,1c-0.9,0.5-1.5,1.2-1.9,2.2\n                        c-0.4,0.1-0.7,0.4-0.6,1c-0.3-0.1-0.3,0.1-0.3,0.3c-0.3,0-0.2,0.4-0.3,0.6c-0.5,1.1-1.2,2-1.3,3.5c-0.7,0.1-0.3,1.2-1,1.3\n                        c-2,0,0.4-2.4-1.3-2.6c0,0.3-0.3,0.4-0.3,0.6c-0.6,0.6-0.8,1.6-1.3,2.2c0.1,0.5-0.3,0.6-0.3,1c0,0.2,0,0.4-0.3,0.3\n                        c0,1.4-0.8,2-1.3,2.9c-0.1,0.4-0.4,0.5-0.6,0.6c-0.2,0.7-1.1,0.9-1.3,1.6c-1.4,0.7-1.9,2.2-2.2,3.8c-0.9,1-1.2,2.4-1.9,3.5\n                        c-0.3,0.6-0.5,1.2-0.6,1.9c-0.8,1.6-1,3.7-1.3,5.8c1-1.3,1.5-3.2,2.6-4.5c0.9-0.2,0.5-1.7,1.9-1.3c0.6,0.6-0.2,0.6,0,1.6\n                        c-0.3,1.1-0.4,2.3-0.6,3.5c-0.4,0.4-0.4,1.1-0.3,1.9c-0.6,2.3-1,4.9-1,8c0.5,0.6,0.4,1.7,0.6,2.6c0.4-0.1,0.7-0.4,0.6-1\n                        c0-0.1,0-0.2,0-0.3c0.1-1.5,0.5-2.7,0.6-4.2c0.2-1.1,0.5-2,0.6-3.2c0.1-0.3,0.3-0.3,0.3-0.6c0-0.2,0-0.4,0-0.6\n                        c0.8-1,0.3-3.4,1.3-4.2c-0.1-0.4,0.1-0.6,0.3-0.6c0-0.3,0-0.6,0-1c0.5,0,0.2-0.9,0.6-1c0-0.6,0.1-1,0.3-1.3c0.4,0,0.4-0.4,1-0.3\n                        c0.2,1.8-0.3,2.9-0.3,4.5c-0.7-0.1-0.1,1.1-0.3,1.6c-0.1,0-0.2,0-0.3,0c0,0.5,0,1.1,0,1.6c0.2,3.5-0.4,7.9,0.3,10.9\n                        c0.2,0.7-0.4,2.1,0.3,2.2c0,0.3,0,0.6,0,1c-0.1,1.5,0.6,2.1,0.6,3.5c1.2-0.5,0.8-2.6,1-4.2c0.5-0.1,0.3-0.8,0.3-1.3\n                        c0.5-0.9,0.5-2.3,1-3.2c0.4-1,0.2-2.6,1.9-2.2c0.2,1-0.2,1.5-0.3,2.2c0,0.4,0,0.9,0,1.3c0,0.9,0,1.7,0,2.6c0,0.1,0,0.2,0,0.3\n                        c-0.2,2.1,0.5,3.1,0.3,5.1c1.3-0.2,1-2,2.9-1.6c0.2,0.9-0.4,2.5,0.3,2.9c-0.2,1.3,0.3,1.8,0.3,2.9c0.6,0.6,0.4,1.9,1,2.6\n                        c0.3,1.2,0.7,2.3,1.3,3.2c0.7-2.9,1.5-5.8,1.6-9.3c2-2.4,3.7,3,4.2,5.1c0.1,0,0.2,0,0.3,0c-0.1,1.4,0.5,2.1,0.6,3.2\n                        c0.1,1.1,0.5,1.8,0.3,3.2c0.7,1.1,0.1,3.5,0.3,5.1c0,0.1,0,0.2,0,0.3c1,0.9,0.6-1.5,1-2.2c0.5-0.6,0.4-2,1-2.6\n                        c0-0.1,0-0.2,0-0.3c0.3-0.6,0.1-1.6,0.6-1.9c0-0.4,0-0.9,0-1.3c0.1-0.4,0.5-0.6,0.3-1.3c0.7-0.2-0.1-3.5,1-2.2\n                        c0.4,0.1,0.5,0.4,0.6,0.6c0.2,0.7,0.8,0.9,0.6,1.9c0.1,0,0.2,0,0.3,0c0,0.4,0.2,0.7,0.3,1c0,0.4-0.1,0.9,0.3,1\n                        c-0.1,0.7,0.1,1.2,0.3,1.6c0,0.1,0,0.2,0,0.3c0,0.4,0,0.9,0,1.3c0.6,1.8,0.9,3.8,1,6.1c0,0.9,0,1.7,0,2.6c0,0.7,0,1.5,0,2.2\n                        c0,0.1,0,0.2,0,0.3c-0.1,1.1-0.5,1.8-0.3,3.2c0.3-0.2,0.5-0.6,0.6-1c1-2.3,1.3-5.3,2.2-7.7c0.6-2.1,0.6-4.7,1.6-6.4\n                        c0-0.7,0-1.5,0-2.2c0-0.4,0.2-0.7,0.3-1c1.1,0,1.3,1.1,1.3,2.2c0.5,0.5,0.3,1.9,0.3,2.9c-0.2,2,1,4.1,0,5.8c0,1.3,0,2.6,0,3.8\n                        c0.3,1.1-0.5,1.2-0.3,2.2c0,0.4,0,0.9,0,1.3c-0.6,0.7,0.1,2.6-0.6,3.2c0,0.8,0.1,1.8-0.3,2.2c0.2,0.8-0.4,2.3,0.3,2.6\n                        c0-0.8,0.2-1.5,0.6-1.9c0-1.5,0.8-2.2,0.6-3.8c0.5-0.6,0-2.4,0.6-2.9c0-1.1-0.1-2.2,0.6-2.6c1.7,0.3,1.8,2.3,1.9,4.2\n                        c0.7,0.1,0.1,1.4,0.6,1.6c0.2,0.7-0.4,2.1,0.3,2.2c0,1.2,0,2.3,0,3.5c0.3,0,0.2,0.4,0.3,0.6c0.1,0.4,0.6,0,0.6-0.3\n                        c-0.1-0.5,0.3-0.5,0.3-1c-0.1-0.5,0.3-0.6,0.3-1c-0.2-1.4,0.5-1.8,0.3-3.2c0-0.2,0-0.4,0-0.6c0-3,0.2-6.2-0.6-8.3\n                        c0-0.3,0-0.6,0-1c3.3,0.4,3.1,4.1,4.2,6.7c0.1,0.9,0.6,1.3,0.6,2.2c0.2,1.6,0.7,3,1,4.5c0,0.2,0,0.4,0.3,0.3\n                        c0.2-0.7-0.4-2.1,0.3-2.2c0-0.2,0-0.4,0-0.6c0-1.9,0-3.8,0-5.8c0-0.6,0-1.3,0-1.9c0.1-1.8-0.1-3.3-0.3-4.8c0-0.4-0.4-0.4-0.3-1\n                        c0-0.1,0-0.2,0-0.3c0-0.1,0-0.2,0-0.3c0-0.2,0-0.4,0-0.6c0.2-1.7-1.7-3.7-0.3-4.5c0.7,0.1,0.6,0.9,1.3,1c0,0.8,0.6,1.1,1,1.6\n                        c0.2,0.5,0.5,0.8,0.6,1.3c0.6,1.6,1.1,3.4,1.9,4.8c0.2,1.3,0.4,2.6,1,3.5c0.7-0.8,0.3-3.3,0-4.2c0-0.8,0-1.5-0.3-1.9\n                        c-0.6-2.1-0.7-4.8-1.6-6.7c-0.2-0.9,0.4-2.5-0.3-2.9c0.1-0.5-0.1-1.2,0.3-1.3c2,0.9,2.4,3.3,3.5,5.1c0.2,0.1,0.4,0.3,0.3,0.6\n                        c0.2,0,0.4,0,0.3,0.3c0.3,0.9,1,1.3,1,2.6c0.7,0.1,0.3,1.2,1,1.3c0-0.1,0-0.2,0-0.3c-0.5-2.8-1.3-5.3-1.6-8.3\n                        c-0.7,0.1-0.1-1.1-0.3-1.6c0.1-1.3-1.3-3.4,0-3.8c0.5,0.3,1,0.5,1,1.3c0.7,0.8,1.3,1.6,1.6,2.9c0.7,0.9,1.2,2,1.6,3.2\n                        c0.5,1,1.1,1.9,1.3,3.2c0,0.1,0,0.2,0,0.3c0.3,1.2,0.7,2.3,1,3.5C166,151.3,164.9,149.6,165,148.4z M118.4,92.5\n                        c0.4-0.8,0.8-1.6,1-2.6c0.4-0.7,1.2-0.9,1.3-1.9c1.7-1.2,3.1-2.7,6.4-2.2c0.5,0,1.1,0,1.6,0c1-0.2,1.2,0.3,1.9,0.3\n                        c0,0.4,0,0.9,0,1.3c-0.8,0.2-1.1,1-1,2.2c0.2,1-0.5,1.2-0.6,1.9c-0.5,0.2-0.8,0.5-1,1c-0.4-0.1-0.6,0.1-0.6,0.3\n                        c-2.2,0-4.4,0.2-4.8-1.6c-0.9,0.8-1.3,2.1-1.9,3.2c0.2,0.7-0.1,2.4-0.6,1.3c-0.1-0.7-0.7-1-1-1.6c-0.3-0.1-0.3-0.3-0.6-0.3\n                        C118.4,93.3,118.4,92.9,118.4,92.5z\"/>\n                </g>\n                <g>\n                    <path class=\"st1\" d=\"M131.8,228.9c-0.2,0.3-0.6,0.5-1,0.6c0,0.3-0.4,0.2-0.6,0.3c0,0.1,0,0.2,0,0.3c-0.5-0.1-0.6,0.3-1,0.3\n                        c-1.7,1.2-3.2,2.5-4.2,4.5c-0.5,0.9-0.9,1.9-1.3,2.9c-0.4,0.9-0.4,2.2-0.3,3.5c-0.2,0.9-0.5,1.8-1.3,2.2\n                        c-0.4,0.4-0.3,1.4-0.3,2.2c0.2,0.6-0.4,1.9,0.3,1.9c-1.5,5.7-0.3,12.9-1,19.8c0,1.6,0,3.2,0,4.8c0,2.2-0.5,3.9-0.3,6.4\n                        c0,0.3,0,0.6,0,1c0,1.3,0,2.6,0,3.8c0,0.2,0,0.4,0,0.6c0,0.2,0,0.4,0,0.6c-0.5,0-0.8,0.2-1,0.6c-0.5,0-0.9-0.1-1,0.3\n                        c-2.9,0.2-4.4,1.8-7,2.2c-0.1,0.2-0.3,0.4-0.6,0.3c-0.7,0.3-1.3,0.7-1.9,1c-0.2,0.1-0.6,0-0.6,0.3c-1-0.1-1.1,0.8-2.2,0.6\n                        c-0.9,0.5-1.8,1-2.2,1.9c1.8-0.4,4-0.2,4.5-1.9c0.1,0,0.2,0,0.3,0c0.1,0,0.2,0,0.3,0c0.7,0.7,2.8,0.2,3.5,0\n                        c1.8,0.2,2.1-1.1,3.2-1.6c1.4,0.4,2.1,1.4,3.5,0.3c0.3,0,0.4,0.3,0.6,0.3c1-0.2,0.9,0.6,1.9,0.3c0,0.8,1.1,0.1,1.3,0\n                        c1.8,1.5,4.7,1.3,6.7,1.9c0,0.3,0.3,0.4,0.3,0.6c0.2,0,0.4,0,0.6,0c1.5,0.6,4.1,0.2,5.4,1c-0.6-1.5-2.1-2.1-3.5-2.9\n                        c-0.1,0-0.2,0-0.3,0c-0.3-0.2-0.7-0.3-1.3-0.3c-2,0.2-2.1-1.5-3.5-1.9c-0.6-0.3-1.2-0.5-1.9-0.6c-0.1,0-0.2,0-0.3,0\n                        c0-0.2,0-0.4-0.3-0.3c-1.1-0.1-1.8-0.8-2.2-1.6c0-0.2,0-0.4,0.3-0.3c0-1.3,0.1-2.6-0.3-3.5c-0.2-0.5,0.4-1.7-0.3-1.6\n                        c0.2-12.3-0.1-25.2,3.5-34.2c0.1-1.3,1-1.8,1-3.2c0.7-0.5,0.8-1.5,1.3-2.2c0-0.6,0.1-1,0.3-1.3c0-0.1,0-0.2,0-0.3\n                        c0-0.1,0-0.2,0-0.3c0.8-0.7,1-2,1.6-2.9c0-0.2,0-0.4,0.3-0.3c0-0.1,0-0.2,0-0.3c0-0.8,0.6-0.9,0.3-1.9c-0.1-0.3,0.1-0.3,0.3-0.3\n                        c0-0.2,0-0.4,0-0.6C131.1,230.8,133.4,229.3,131.8,228.9z\"/>\n                </g>\n                <g>\n                    <path class=\"st1\" d=\"M118.1,278.4c0-0.6,0-1.3,0-1.9c-1.3,0.6-3.1,0.7-4.2,1.6C115.5,278,116.3,278.7,118.1,278.4z\"/>\n                </g>\n                <g>\n                    <path class=\"st1\" d=\"M130.5,284.8c2.8,1.7,5.4,0.1,8.6,0.6c0.1-0.4,0.6-0.5,0.6-1c1.9-0.2,2.3,1.1,3.8,1.3\n                        c1.3,0.1,1.7-0.6,1.6-1.9c1.1-0.2,1.5,0.4,2.2,0.6c1.5,0.7,2.9-0.8,4.8,0c-1.1-1-2.6-1.4-4.8-1.3c-1.2,0-2,0.3-2.9,0.6\n                        c-3.3,0.1-6.7,0.3-9.9,0.3C133.4,284.5,130.7,283.4,130.5,284.8z\"/>\n                </g>\n                <g>\n                    <path class=\"st1\" d=\"M116.1,266.3c-0.6,0.2,0,0.6,0,1c0.6,1.4,1.7,2.4,2.2,3.8c0.7-0.4,0.1-2.2,0.3-3.2\n                        C117.9,267.3,117,266.8,116.1,266.3z\"/>\n                </g>\n                <g>\n                    <path class=\"st1\" d=\"M127,284.2c0.2-0.1,0.6,0,0.6-0.3c-0.2-0.6-1.9,0.2-1.6-1c2.6-0.6,5.5-0.9,7.3-2.2c2-1.1,3.5-2.9,6.1-2.6\n                        c0-0.3-0.4-0.2-0.6-0.3c-1.5-0.5-2.7-0.1-4.2,0.3c-1.1,0.6-2.2,1.2-3.5,1.6c-0.8,0.6-1.4,1.3-2.6,1.6c-0.8,0.9-2,1.4-3.8,1.3\n                        c0,0.4,0,0.9,0,1.3C125.5,284,126,284.4,127,284.2z\"/>\n                </g>\n                <g>\n                    <path class=\"st1\" d=\"M159.3,177.8c-0.6,3.2-1.1,6.6-2.2,9.3c-0.3,1.3-0.4,2.8-1,3.8c0,0.5,0.1,0.9-0.3,1\n                        c-0.6,2.2-1.7,3.9-2.6,5.8c0,0.1,0,0.2,0,0.3c-0.4,0.5-0.9,0.8-1,1.6c-0.1,0-0.2,0-0.3,0c-0.2,0.3-0.3,0.5-0.3,1\n                        c-0.3,0.1-0.6,0.3-0.6,0.6c-0.2,0.5-0.5,0.8-1,1c0,0.6-0.9,0.4-0.6,1.3c-2.3,2.3-4.5,4.6-6.7,7c-0.3,0.1-0.6,0.3-0.6,0.6\n                        c-1.1,0.1-1.4,1-1.9,1.6c-2.1,1.3-3.6,3.2-5.8,4.5c-0.7,0.8-1.6,1.4-2.6,1.9c0.1,0.3-0.1,0.3-0.3,0.3c0,0.2,0,0.4-0.3,0.3\n                        c-0.1,0-0.2,0-0.3,0c-0.2,0.7-1,1-1.6,1.3c-0.1,0.2-0.3,0.4-0.6,0.3c-0.1,0.5-0.5,0.5-0.6,1c-0.9-0.2-0.6,0.6-1.3,0.6\n                        c-0.4,0.1-0.5,0.4-0.6,0.6c-1,0.1-1.4,0.7-2.2,1c-0.8,0.2-1.1-0.1-1-1c0-0.6,1.1-0.2,1-1c0.5,0,0.8-0.2,1-0.6\n                        c0.8-1.1,1.8-2.1,2.9-2.9c0.1-0.7,0.9-0.6,1-1.3c0.5-0.8,1.1-1.4,1.9-1.9c0.1-1.2-0.3-0.1-1-0.3c-0.7,0.9-1.9,1.3-2.9,1.9\n                        c-0.7,0.3-0.9,1-1.9,1c-0.2,0.3-0.6,0.5-1,0.6c-1.8,1.1-4.2,1.5-5.8,2.9c-1.7,0.7-2.9,2-5.4,1.9c0.3-1,1.6-0.9,1.9-1.9\n                        c0.4-0.1,0.5-0.6,1-0.6c0.6-0.6,1.5-0.9,1.9-1.6c0.1,0,0.2,0,0.3,0c0.8-1.2,2.2-1.9,3.2-2.9c0.3-0.6,0.7-1,1.3-1.3\n                        c0.9-1.5,2-2.9,3.2-4.2c-0.1-0.3,0.1-0.3,0.3-0.3c1-1.4,1.9-3,3.2-4.2c0.1-0.3-0.1-0.3-0.3-0.3c-1,0.4-1.7,1.1-2.6,1.6\n                        c-0.3,0.1-0.3,0.3-0.6,0.3c0,0.3-0.4,0.2-0.6,0.3c-0.1,0.4-0.4,0.7-1,0.6c0,0.1,0,0.2,0,0.3c-3.3,1.5-5.9,3.7-8.9,5.4\n                        c-0.3,0.5-0.8,0.7-1.6,0.6c0-0.8-0.5-0.9-0.3-1.9c-0.5,0-1.1,0-1.6,0c-0.9-0.1-1.5-0.4-1.9-1c0-0.1,0-0.2,0-0.3c0-0.3,0-0.6,0-1\n                        c0.2-0.4,1.2,0,1.3-0.6c1.7-0.1,2.4-1.2,3.8-1.6c0.4-0.3,1.2-0.3,1.3-1c1.6-0.7,3.1-1.6,4.2-2.9c0.6,0,0.4-0.9,1.3-0.6\n                        c0.2-0.5,0.5-0.8,1-1c1.2-1.4,2.5-2.8,3.8-4.2c-0.1-0.3,0.1-0.3,0.3-0.3c0-1.5-0.5,0.3-1.3,0c0.1,0.3-0.1,0.3-0.3,0.3\n                        c-1.2,1.1-2.7,2-4.5,2.6c0,0.8-1.2,0.5-1.6,1c-0.3,0.3-0.9,0.2-1,0.6c-1.2,0.4-2,1.2-3.2,1.6c-0.5,0.4-1.3,0.4-1.6,1\n                        c-0.7-0.1-1.2,0.1-1.6,0.3c-0.6,0-0.7,0.4-1.3,0.3c-0.5,0.2-0.8,0.5-1.3,0.6c-1.8-0.4-1.2,1.6-1.3,2.9c0,0.2,0,0.4,0,0.6\n                        c-0.2,1,0.3,1.2,0.3,1.9c0,0.2,0,0.4,0,0.6c-0.1,1,0.6,1.4,0.3,2.6c0.6,0,0.2,1.1,0.6,1.3c1.6,3.5,2.6,7.6,4.8,10.5\n                        c-0.4,1.4-1.7,0-2.6,0c0-0.1,0-0.2,0-0.3c-2.1,0.1-2.1-1.9-3.8-2.2c0,0.1,0,0.2,0,0.3c0,0.6,0.1,1,0.3,1.3\n                        c0.1,0.4,0.5,0.6,0.3,1.3c0,0.1,0,0.2,0,0.3c0,0.4,0,0.9,0,1.3c-1.6,0.2-1.9-0.9-2.6-1.6c-0.7-0.6-0.8-1.7-1.6-2.2\n                        c-0.5-0.7-0.9-1.4-1.3-2.2c-0.1,0-0.2,0-0.3,0c0,0.4,0,0.9,0,1.3c-0.1,1.7,0.1,3.1,0.6,4.2c0,0.2,0,0.4,0,0.6\n                        c0.7,0.1,0.1,1.4,0.6,1.6c0.3,0.6,0.5,1.2,0.6,1.9c0.4,0,0.7,0.2,1,0.3c0.9,0.8,1.8-0.3,3.2,0c0.5-0.2,1.7,0.4,1.6-0.3\n                        c2.9,0,5.1-0.7,7.7-1c0.4-0.5,1.1-0.6,1.9-0.6c0.2,0,0.4,0,0.3-0.3c0.9-0.2,1.7-0.5,2.6-0.6c0.4,0,0.4-0.4,1-0.3\n                        c0.1-0.7,1.4-0.3,1.6-1c1.8-0.3,2.5-1.6,4.2-1.9c0.3-0.4,0.9-0.6,1.3-1c0.1,0,0.2,0,0.3,0c0.1-0.4,0.7-0.4,1-0.6\n                        c0.5-0.4,0.8-0.9,1.6-1c0.7-0.3,0.3-1.6,1.3-1.6c3.2-4.9,9.2-7,12.8-11.5c0.9-0.6,1.5-1.5,1.9-2.6c1-0.8,1.7-1.9,2.6-2.9\n                        c0.1-0.4,0.4-0.5,0.6-0.6c0-0.2,0-0.4,0.3-0.3c0-0.1,0-0.2,0-0.3c1-0.3,1-1.5,1.9-1.9c0.2-0.3,0.3-0.5,0.3-1\n                        c0.4-0.1,0.7-0.4,0.6-1c0.7-0.3,1.2-1,1.3-1.9c0.3,0,0.2-0.4,0.3-0.6c0.3-0.1,0.2-0.6,0.6-0.6c0-0.8,0.2-1.3,0.6-1.6\n                        c1.4-4.7,2.7-9.4,2.9-15.3c0-0.7,0-1.5,0-2.2c0-0.2,0-0.4,0-0.6c-0.5-1.6-0.9-3.4-1.3-5.1C159.4,174.7,159.3,176.2,159.3,177.8z\n                        \"/>\n                </g>\n                <path d=\"M120,95.7c0.5,1.1,0.8-0.6,0.6-1.3c0.6-1.1,1-2.4,1.9-3.2c0.4,1.8,2.6,1.6,4.8,1.6c0.1-0.2,0.3-0.4,0.6-0.3\n                    c0.2-0.5,0.5-0.8,1-1c0.2-0.7,0.8-0.9,0.6-1.9c-0.2-1.2,0.1-2,1-2.2c0-0.4,0-0.9,0-1.3c-0.8,0-0.9-0.6-1.9-0.3\n                    c-0.5,0-1.1,0-1.6,0c-3.3-0.4-4.7,1.1-6.4,2.2c-0.1,1-0.9,1.2-1.3,1.9c-0.2,1-0.6,1.8-1,2.6c0,0.4,0,0.9,0,1.3\n                    c0.3,0,0.4,0.3,0.6,0.3C119.3,94.6,119.8,94.9,120,95.7z M127.6,88.6c-0.1-1-2.1,0-1.9-1.3c1.7-0.2,2.6,0.4,3.2,1.3\n                    c0,2-1.3,2.7-2.6,3.5c-1,0-1.7-0.4-1.9-1.3C126.5,91.1,127.7,90.5,127.6,88.6z\"/>\n                <path d=\"M174.3,149.7c-0.1-0.4,0.1-0.9-0.3-1c0-0.3,0-0.6,0-1c-0.3-1.5-0.7-2.9-1-4.5c0.1-0.3-0.1-0.3-0.3-0.3\n                    c-4.6-9.7-11.5-17.2-21.1-22c-0.2-0.4-0.7-0.6-1.3-0.6c-0.9-0.2-1.7-0.5-2.6-0.6c-1.5-0.7-3.9-0.6-5.4-1.3\n                    c-3.7-0.5-8-0.6-10.5-2.2c-1.1-0.9-2.2-1.8-2.9-3.2c-0.1-0.7,0.2-0.8,0.3-1.3c0.7-0.1,0.4,0.9,1,1c0.1,1.1,0.7,1.6,1.6,1.9\n                    c0.5,0.7,1.9,0.4,2.6,1c0.1,0,0.2,0,0.3,0c0.3,0,0.6,0,1,0c0.4-0.4,1.5-0.2,1.9-0.6c0.1,0,0.2,0,0.3,0c0.9-1.1,1.8-2.3,1.6-4.5\n                    c0-1.5-0.9-2.1-1.3-3.2c-0.1-0.2,0-0.6-0.3-0.6c-0.2-1.4-0.3-2.9-1.3-3.5c-0.5-0.5-0.6-1.3-1.3-1.6c-0.4-0.8-1.2-1.2-1-2.6\n                    c0.9-1,2.8-1,3.5-2.2c1.2-0.5,2.2-1.2,2.9-2.2c0.3-0.7,1-0.9,1-1.9c-1.9-0.4-2,1-3.8,0.6c0,0.1,0,0.2,0,0.3\n                    c-1.2,0.1-2.6,1.7-3.5,1c1.8-1.9,4.8-2.7,7.3-3.8c-3.9-1.2-7.3,1.9-9.9,1.9c2.2-3.9,5.5-6.7,11.2-7c-0.1-1.5-1.1-2.1-2.2-2.6\n                    c-0.3-0.6-1.1-0.6-1.6-1c-3.4-0.9-7.1,0.2-9.6,1.3c-0.3-0.1-0.3-0.3-0.6-0.3c-6.6-2.5-4.8-13.6-13.1-14.4c-0.5,0-1.1,0-1.6,0\n                    c0,0.6-0.9,0.4-0.6,1.3c0.1,0.3,0.3,0.3,0.3,0.6c0.7,1-0.2,0.4-1,0.3c-0.7-0.8-2.1-0.9-3.5-1c-0.2,0.3-0.3,0.7-0.3,1.3\n                    c0.1,0.8,1.6,1.8,1,2.2c-0.6-0.1-0.8-0.7-1.6-0.6c-0.7-0.9-3.2-1.4-4.5-0.6c-0.9,1.8,1.8,2.6,2.6,3.8c0,0.3,0,0.6,0,1\n                    c-1.7,0.2-2.6-0.7-3.8,0c-0.3,2.2,1.7,2.1,1.6,4.2c-2-0.5-4.4-1.8-6.7-1c0.3,2.4,3.4,2.1,3.5,4.8c-0.6-0.1-0.8-0.7-1.6-0.6\n                    c-0.6-0.8-2.5-0.2-3.2,0c0,0.5-0.1,0.9,0.3,1c1,2.7,3.3,3.9,5.4,5.4c1.4,0.8,3,1.3,4.8,1.6c-1.4,3.6-4.8,5.2-6.7,8.3\n                    c-0.7,0.2-1,1-1.3,1.6c-0.7,0.1-0.6,0.9-1,1.3c-2.2,2.6-3.2,6.3-4.2,10.2c0.1,1.7-0.6,2.6-0.3,4.5c1,0,1.1-0.8,1.3-1.6\n                    c1.5,3.2-1.4,11,1.9,13.1c0.9-1,0.5-3.3,1.3-4.5c0.7,0.7,1.3,1.5,1.3,2.9c0.3,0.6,0.1,1.6,0.6,1.9c0,0.2,0,0.4,0,0.6\n                    c0,0.5-0.2,1.2,0.3,1.3c0,0.1,0,0.2,0,0.3c0.2,0.9,0.8,1.3,1,2.2c1.1,0.9,1.6,2.5,2.9,3.2c1.3,2.5,3.9,0.4,5.4,3.2\n                    c0.2,1.5-0.4,3.8,0.3,4.8c0,0.3,0,0.6,0,1c-0.2,1.4,0.5,1.8,0.3,3.2c0.1,1.5,0.7,2.5,0.6,4.2c0.2,0.3,0.3,0.5,0.3,1\n                    c0,0.8,0.5,0.9,0.3,1.9c0.4,0.6,0.1,1.9,0.6,2.2c0,0.1,0,0.2,0,0.3c0.5,2-1,1.9-1.6,2.9c-0.3,0.1-0.6,0.3-0.6,0.6\n                    c-1.9,1-3.1,2.6-4.5,4.2c-0.6,0.3-1,0.7-1.3,1.3c-1.3,0.8-2,2.1-2.9,3.2c-1.5,1.3-2.6,3-3.8,4.5c-0.3,0-0.2,0.4-0.3,0.6\n                    c-0.5,0.2-0.8,0.5-1,1c-0.7,0.6-1.3,1.2-1.6,2.2c-0.3-0.1-0.3,0.1-0.3,0.3c-0.4,0.1-0.7,0.4-0.6,1c-1.5,1.7-2.7,3.7-3.8,5.8\n                    c-0.3,0.7-1,0.9-1,1.9c-1.6,2.7-3.1,5.5-4.2,8.6c-0.3-0.1-0.3,0.1-0.3,0.3c-0.5,1.2-1.1,2.3-2.2,2.9c-0.5-0.7-0.6-1.7-1.3-2.2\n                    c-0.3-0.7-0.7-1.4-1.3-1.9c-2.5-3.4-5-6.9-8.3-9.6c-0.3-0.5-0.5-1-1.3-1c-2.8-2.6-6.4-4.5-10.2-6.1c0-0.3-0.4-0.2-0.6-0.3\n                    c-0.6-0.1-0.8-0.7-1.6-0.6c-0.7-0.4-1.3-0.8-2.6-0.6c-0.3-0.5-1.4-0.3-1.9-0.6c-0.2,0-0.4,0-0.6,0c-0.8-0.2-1.5-0.5-2.6-0.3\n                    c-0.5-0.5-1.6-0.3-2.6-0.3c-2.9-0.5-8-0.5-10.9,0c-4.6,0.3-8.2,1.6-12.5,2.2c-0.4-0.1-0.6,0.1-0.6,0.3c-1-0.2-1.2,0.5-1.9,0.6\n                    c-0.6,0-1.1,0.2-1.3,0.6c-1.8,0.9-4.1,1.2-4.8,3.2c0.6,1.6,3.5,2.6,5.4,1.9c0.5,0.1,0.5-0.3,1-0.3c3.5-0.1,6.2-1,9.6-1.3\n                    c0.4,0,0.9,0,1.3,0c0.4,0.1,0.6-0.1,0.6-0.3c0.7,0.6,2.4,0.3,3.2,0c0.8,0.2,1.5,0.5,2.6,0.3c1,0,1.9,0,2.9,0c0.2,0,0.4,0,0.6,0\n                    c2.5,0.5,5.5,0.7,8,1.3c0.1,0.7,1.4,0.1,1.6,0.6c0.8,0.4,2.1,0.4,2.9,1c1.4,0.6,2.4,1.4,3.8,1.9c0.1,0.3,0.3,0.6,0.6,0.6\n                    c3.1,2.4,7.3,5.4,8.9,8.3c-1.2-0.9-2.4-1.8-3.8-2.6c-2.6-1.8-5.6-3.3-8.6-4.8c-0.1,0-0.2,0-0.3,0c-1-0.4-1.7-1.1-2.9-1.3\n                    c-1.9-0.8-3.8-1.8-6.4-1.9c-0.1-0.7-1.7,0-1.9-0.6c-2.7-0.3-5.1-0.8-8.3-0.6c-0.8,0.2-2.3-0.4-2.6,0.3c-2.2-0.2-3.6,0.4-5.1,1\n                    c-0.8,0.2-1.6,0.5-2.2,1c-1,0-1.1,0.8-1.9,1c-1.5,1.2-3.3,2.2-4.2,4.2c-2,1.7-3.2,4.3-4.5,6.7c0,0.1,0,0.2,0,0.3\n                    c-0.6,0.9-0.7,2.3-1,3.5c1.3,0.1,2-0.4,2.6-1c0.3-0.1,0.3-0.3,0.6-0.3c0.3-0.1,0.6-0.3,0.6-0.6c0.6-0.3,1-0.7,1.3-1.3\n                    c2-1.4,3.4-3.4,5.4-4.8c0.5-0.5,1.3-0.6,1.6-1.3c1.5-0.4,2.4-1.2,3.8-1.6c0.2-0.4,1.2,0,1.3-0.6c1.9,0.1,3.1-0.6,5.1-0.3\n                    c2.1,0.2,4,0.7,6.1,1c0.7,0.5,1.7,0.7,2.9,0.6c1.2,0.6,2.9,0.7,4.2,1.3c0.7,0.2,1.2,0.7,2.2,0.6c1.2,0.7,2.8,1,4.2,1.6\n                    c-0.1,0.3,0.1,0.3,0.3,0.3c0.3,0.2,0.5,0.3,1,0.3c0.8,0.6,1.8,1.2,2.9,1.6c0.8,1.2,3.4,2.4,3.2,3.5c-1.5-0.1-2.4-0.8-3.8-1\n                    c-1-0.3-2.4-0.2-3.2-0.6c-2.3,0-4.7,0-7,0c-0.8,0-1.5,0-1.9,0.3c-2.6,0-5.2-0.1-7.3,0.3c-0.3,0-0.6,0-1,0c-1.1,0.4-2.7,0.3-3.5,1\n                    c-1.3-0.2-1.9,0.3-2.6,0.6c-1.2,0.2-2.4,0.3-3.2,1c-0.5,0.2-1.7-0.4-1.6,0.3c-0.8,0-1.3,0.2-1.6,0.6c-0.5,0-0.9-0.1-1,0.3\n                    c-0.4-0.1-0.6,0.1-0.6,0.3c-0.5,0-0.8,0.2-1,0.6c-0.4-0.1-0.6,0.1-0.6,0.3c-0.8,0-1.1,0.6-1.6,1c-0.8-0.1-1,0.5-1.3,1\n                    c-1.2,0.3-1.8,1.2-2.6,1.9c-0.7,0.4-1.2,1.1-1.9,1.6c0,1,0.7,1.4,1.9,1.3c-0.1,0.4-0.6,0.5-0.6,1c-0.5,0.2-0.8,0.5-1,1\n                    c-1.2,1.1-2.6,1.9-3.2,3.5c-0.3-0.1-0.3,0.1-0.3,0.3c-0.4,0.5-0.9,0.8-1,1.6c-0.4,0.1-0.3,0.6-0.3,1c-0.7,1.3-1.2,2.8-1.6,4.5\n                    c0.1,0.8-0.6,0.7-0.3,1.6c-0.1,0.8-0.5,1.2-0.3,2.2c0,0.3,0,0.6,0,1c0.3,1.3-0.5,1.6-0.3,2.9c-0.1,0-0.2,0-0.3,0\n                    c0,0.5,0,1.1,0,1.6c0.1,0,0.2,0,0.3,0c0.1,1.3-0.3,3.1,0.3,3.8c1,0.2,1.2-0.5,1.9-0.6c1.4-0.2,1.4-1.8,2.2-2.6c0.4,1.6-1.7,5-1,7\n                    c1.8,0.7,4.3-0.6,5.8-1.3c0.3,0,0.2,0.4,0.3,0.6c0.2,1.4-0.6,3.8,0.6,4.2c0,0.1,0,0.2,0,0.3c2.4-0.2,3.5-1.6,5.1-2.6\n                    c0.1,0,0.2,0,0.3,0c0.1,0,0.2,0,0.3,0c-0.4,3,3.4,3.6,4.8,3.8c1,0.2,1.2-0.3,1.9-0.3c1.3,1.9,3.8,1,5.1-0.3\n                    c0.5,0.1,0.5-0.3,1-0.3c1.1-0.3,2.2-0.6,2.9-1.3c1.5-0.5,2.8-2.7,3.8-2.6c0.1,0.7-0.2,0.8-0.3,1.3c0,0.2,0,0.4,0,0.6\n                    c0,1.4-0.5,2.2-0.3,3.8c0,0.8,0.1,1.8-0.3,2.2c0,0.6,0,1.3,0,1.9c-0.2,1.2,0.4,1.5,0.3,2.6c-0.3,1.6,0.2,2.3,1,2.9\n                    c1.4,0.1,1.6-0.9,2.2-1.6c0.7-0.3,0.8-1.1,1.3-1.6c0.9-0.5,1.2-1.5,1.9-2.2c0.8-0.8,1.9-1.3,2.2-2.6c0.9-0.7,0.8-2.4,1.9-2.9\n                    c0.1,0,0.2,0,0.3,0c0.1,2,0.7,3.4,1.3,4.8c0,0.1,0,0.2,0,0.3c0.1,0.3,0.3,0.3,0.3,0.6c0.2,0.3,0.3,0.5,0.3,1\n                    c0.5,2.2,1.6,4,2.9,5.4c0.1,0.6,0.5,0.7,1.3,0.6c1-0.4-0.3-1.1,0-1.9c-0.4-0.7-0.5-1.8-1-2.6c0-0.2,0-0.4,0-0.6\n                    c0.3,0.1,0.3,0.3,0.6,0.3c0.6,1.1,1.6,1.8,2.6,2.6c1,0.8,1.7,1.9,3.5,1.9c0.7-2.1,0.1-5.6,0.3-8.3c1-0.3,3.2,0.5,2.9-1.9\n                    c1.5,0.6,1.4,2.9,3.2,3.2c0.1,0,0.2,0,0.3,0c0.4,0.3,0.9,0.4,1.6,0.3c1.2-0.2,1.9-0.9,1.9-2.2c0.3,0.2,0.5,0.6,0.6,1\n                    c1.1,3.9,0.8,9.2,5.1,9.9c2.8-1.9,0.9-8.5,1.9-12.1c1.5,1.6,2,4.4,3.2,6.4c1.2,1.6,1.9,3.7,3.5,4.8c0.3-0.8,1.2-3.1,0-3.5\n                    c-0.5-0.8-1.1-1.4-1.3-2.6c-0.1-0.3-0.3-0.3-0.3-0.6c0.3-0.5,0.3-1.3,1-0.6c-0.1,0.5,0.3,0.5,0.3,1c0.4,0.7,0.9,1.2,1.3,1.9\n                    c0.1,0.5,1.7,2.2,1.9,0.6c0.7-0.5,0.4-2.7-0.3-2.9c-0.3-1.4-0.9-2.5-1.3-3.8c-0.5-1.9-1.4-3.5-1.6-5.8c-0.1-0.7-0.4-1.3-0.6-1.9\n                    c0-0.6-0.4-0.7-0.3-1.3c-0.9-3-1.5-6.2-2.2-9.3c0-0.4,0-0.9,0-1.3c0.3,0,0.2-0.4,0.3-0.6c0.7,0.2,1,1,1.3,1.6\n                    c1,1.6,1.8,3.4,2.9,4.8c0.4,0.8,0.8,1.6,1.3,2.2c0.1,1.2,1.4,1.1,1,2.9c0.4,1.4,0.5,3.2,1,4.5c0,0.7,0,1.5,0,2.2c0.1,2.9,1,5,1,8\n                    c0,0.1,0,0.2,0,0.3c0.4,6.5,2.7,12.5,1.9,19.2c-0.3,0.2-0.5,0.6-0.6,1c-0.3-0.1-0.3,0.1-0.3,0.3c-3,2.8-8.1,3.4-11.2,6.1\n                    c3.4,1.8,10.7,1.1,13.4-0.6c2.1-1.2,4.2-1.1,6.7-1.3c3.5,0.5,7.6,0.5,11.2,1c-0.5,3-4.3,2.8-6.4,4.2c-1.4,0.5-3,0.8-4.2,1.6\n                    c-0.3,0.1-0.3,0.3-0.6,0.3c-2.7,0.8-4.2,2.7-4.8,5.4c0.1,0.7,1.4-0.1,1.6-0.3c0.6-0.3,1.2-0.5,1.9-0.6c0.3-0.2,0.5-0.3,1-0.3\n                    c0.8,0,0.9-0.5,1.9-0.3c2.1-0.5,4.5-0.6,6.7-1c1.7-0.3,3.1-0.9,4.8-1.3c3.8-0.1,5.3,2.2,8.6,2.6c3.3,0.9,8,0.3,9.9,2.6\n                    c0.4-4.3-2.5-5.4-5.1-6.7c-1.8-0.3-3.2-1-4.5-1.9c0.6-0.7,2.1,0.4,3.5,0c1-0.2,1.2,0.3,1.9,0.3c0.4,0,0.9,0,1.3,0\n                    c3.3-0.3,5.1-0.7,8.6-0.3c1.4,0,2.7,0,3.5-0.6c2.1-0.8,3.8-1.7,6.7-1c-0.6-2.8-3.6-3.2-6.7-3.5c-1.2,0.1-2.1,0.4-3.2,0.6\n                    c-3.1-0.1-6.9,0.7-9.9,0.3c1.6-1.5,3.2-2.9,5.1-4.2c0.6,0,1.3,0,1.9,0c0.1-1.4-0.9-1.7-1.9-1.9c-0.1,0-0.2,0-0.3,0\n                    c-1.5-0.7-3-0.5-4.8,0c-1.7,0.5-3.2,1.3-4.5,2.2c-0.7,0.3-1.4,0.7-1.9,1.3c-1.3,0.2-1.9,1.1-3.5,1c0-0.7,0-1.5,0-2.2\n                    c0-2.2,0-4.5,0-6.7c0.1-11.1,1-21.3,4.5-29.1c0.3-0.6,0.8-0.9,1-1.6c0.5-0.3,0.5-1,0.6-1.6c0.2-0.9,0.5-1.7,0.6-2.6\n                    c0.4-1,1.3-1.5,1.3-2.9c0.4-0.8,0.4-2.1,1-2.9c-0.1-0.8,0.6-0.7,0.3-1.6c0.4-1.2,0.9-2.3,1.3-3.5c0-0.1,0-0.2,0-0.3\n                    c1.3,0.1,2.2-0.1,2.6-1c0.4-0.3,1.2-0.3,1.3-1c1,0,1.2-0.7,1.9-1c3.9-2.5,7-5.8,10.2-8.9c0.8-0.5,1.4-1.1,1.9-1.9\n                    c0.1,0,0.2,0,0.3,0c1.3-1,2.5-2.2,3.5-3.5c0.9-1.3,2.3-2.1,2.9-3.8c0.5-0.3,1-0.5,1-1.3c1.1-0.8,1.5-2.3,2.2-3.5\n                    c1.1-2.7,2.4-5,2.9-8.3c0.4-0.1,0.3-0.6,0.3-1c0.8-2.9,1.4-5.8,1.9-8.9c0.6-0.4,0.5-1.7,1-2.2c0-0.1,0-0.2,0-0.3\n                    c1.1-2.4,2.3-4.7,3.2-7.3C173.9,166.2,176,157.7,174.3,149.7z M36.6,213.6c-0.7,0.3-1.4,0.7-1.9,1.3c-0.6,0-0.4,0.9-1.3,0.6\n                    c-0.9,1.1-2.2,1.9-3.5,2.6c-0.9,0.9-1.7,1.7-2.9,2.2c0,0.2,0,0.4-0.3,0.3c-0.2,0.5-0.5,0.8-1,1c0,0.1,0,0.2,0,0.3\n                    c-0.1,0.7-0.9,0.6-1,1.3c-1.5,1.7-2.6,3.8-4.2,5.4c-0.5,0-0.9-0.1-1,0.3c-0.1,0-0.2,0-0.3,0c-0.4,0.3-1,0.5-1.3,1\n                    c-1.2,0.1-0.1-0.3-0.3-1c1.3-2.1,2.4-4.4,4.2-6.1c0.2-0.7,1.1-0.9,1.3-1.6c0.2,0,0.4,0,0.3-0.3c0.8-0.5,1.4-1.1,1.9-1.9\n                    c0.3-0.1,0.3-0.3,0.6-0.3c0.1,0,0.2,0,0.3,0c0.4-0.8,1.1-1.2,1.9-1.6c1.3-1.3,2.9-2.4,5.1-2.9c0.9-0.5,2-0.8,3.2-1\n                    C36.6,213.4,36.6,213.5,36.6,213.6z M43.3,240.4c0.1,0.3,0,0.6,0,0.9C43.3,241.1,43.3,240.7,43.3,240.4z M53.8,235.6\n                    c-0.5,0.9-0.5,3.9,0,4.8c-0.1,1.5,0.3,3.5-0.3,4.5c-0.1,0-0.2,0-0.3,0c-0.1,0.3-0.3,0.3-0.3,0.6c-0.7,0.6-1.5,2.3-2.9,1.3\n                    c0-0.2,0-0.4,0-0.6c-0.1,0-0.2,0-0.3,0c0-0.4,0-0.9,0-1.3c0-0.1,0-0.2,0-0.3c0.7-1.4,0.9-3.4,1.3-5.1c0-0.2,0-0.4,0.3-0.3\n                    c0-0.3,0-0.6,0-1c0.2-0.1,0.4-0.3,0.3-0.6c0.2,0,0.4,0,0.3-0.3c0.3-0.7,0.7-1.3,1-1.9c0.1-0.3,0.3-0.3,0.3-0.6\n                    c0.5,0,0.3-0.8,1-0.6C53.9,234.4,53.7,234.9,53.8,235.6z M67.3,216.1c-0.8,0-1.1,0.6-1.6,1c-0.4,0.1-0.5,0.6-1,0.6\n                    c-0.8,0.4-1.2,1.3-2.2,1.6c-1.2-0.1-1.5,0.6-2.6,0.6c-0.8,0-1,0.5-1.6,0.6c0,0.1,0,0.2,0,0.3c-0.1,0-0.2,0-0.3,0\n                    c-0.2-1,0.9-0.6,0.6-1.6c0.7-0.2,0.9-1.1,1.6-1.3c0.1-0.4,0.6-0.5,0.6-1c1.1-1.1,2.4-1.9,3.5-2.9c0.1-0.5-0.3-0.6-0.3-1\n                    c-1.5-0.3-1.8,0.5-2.9,0.6c-0.1,0.9-1.3,0.6-1.6,1.3c-0.6,0.3-1,0.7-1.3,1.3c-2,0.8-2.7,2.8-4.5,3.8c-0.2,1.2-1.2,1.6-1.9,2.2\n                    c-0.2,0.3-0.3,0.5-0.3,1c-0.6,0.3-1,0.7-1.3,1.3c-1.3,1.8-2.9,3.3-3.8,5.4c-1,0.5-1.4,1.6-1.9,2.6c-0.1,0-0.2,0-0.3,0\n                    c-0.1-1,0.8-1.1,0.6-2.2c0.3,0.1,0.3-0.1,0.3-0.3c0.4-0.6,0.6-1.5,1-2.2c0-0.3,0.3-0.4,0.3-0.6c0.5-0.5,0.4-1.5,1-1.9\n                    c0.1-0.3,0.3-0.3,0.3-0.6c0.6-1.6,1.8-2.7,2.6-4.2c0.6-0.3,1-0.7,1.3-1.3c1-0.8,1.7-1.9,2.6-2.9c0.6-0.3,1-0.7,1.3-1.3\n                    c0.3-0.3,0.9-0.2,1-0.6c1,0.2,0.8-0.9,1.6-1c0.4-0.1,0.5-0.6,1-0.6c0.7-0.6,2.2-0.4,1.9-1.9c-1.2-1-3.3-1.2-4.8-1.9\n                    c-0.1,0-0.2,0-0.3,0c-0.3,0-0.6,0-1,0c-0.9-0.4-2-0.6-3.2-0.6c-0.8-0.3-1.7-0.4-2.9-0.3c-0.5,0-1.1,0-1.6,0c-2.4,0-4.9,0-7.3,0\n                    c-0.5,0-1.1,0-1.6,0c0,0.1,0,0.2,0,0.3c-2,0.3-3.9,0.8-6.4,0.6c0.9-1.8,3.3-2,5.8-2.2c0.6-0.5,2-0.3,2.9-0.6c0.2,0,0.4,0,0.6,0\n                    c0.4-0.4,1.4-0.3,2.2-0.3c0.7-0.6,2.3-0.3,3.2-0.6c0.4,0.1,0.6-0.1,0.6-0.3c1.3,0,2.6,0,3.8,0c3-0.1,5.6,0.2,7.7,1\n                    c2.9,0.3,5.3,1.1,7.3,2.2c1.8,0.3,2.6,1.6,4.2,2.2c1.3,0.6,3.9-0.1,5.1,0.6c-0.3,0.6-0.7,1-1.3,1.3c-0.6,0.4-1.1,0.8-1.6,1.3\n                    c-0.1,0-0.2,0-0.3,0c-1,0-1.1,0.8-1.9,1c-0.6,0-1.1,0.2-1.3,0.6c-0.6,0.1-0.8,0.7-1.6,0.6C67.3,215.9,67.3,216,67.3,216.1z\n                     M75.9,215.2c-0.6,0.9-1.1,1.9-1.6,2.9c-1.4,1.6-1.9,4-2.9,6.1c0,0.1,0,0.2,0,0.3c0,0.4-0.4,0.4-0.3,1c-0.2,0.8-0.5,1.5-0.3,2.6\n                    c-0.4,0.4-0.4,1.1-0.3,1.9c0,0.4,0.1,0.9-0.3,1c0,1.6,0.2,3.4-1,3.8c0,0.1,0,0.2,0,0.3c-0.2,0-0.4,0-0.3,0.3\n                    c-1-0.5-1.2-3.4-0.6-4.5c0.5-5.9,2.6-10.2,5.1-14.1c1.2-0.5,1.3-2.1,2.6-2.6C75.9,214.5,75.9,214.8,75.9,215.2z M81,225.7\n                    c-0.7,0,0.4,0.8,0,1.6c0,0.2,0,0.4-0.3,0.3c0,1.2,0,2.3,0,3.5c0,0.8,0,1.5-0.3,1.9c-0.8,1.6-1.4,3.5-1.6,5.8c0,0.7,0,1.5,0,2.2\n                    c0.2,1.2-0.8,1.8,0,2.6c0,1,0,1.9,0,2.9c0,0.1,0,0.2,0,0.3c-0.1,0-0.2,0-0.3,0c-0.4-1.1-0.4-2.6-0.6-3.8c0-0.1,0-0.2,0-0.3\n                    c0.2-1.3-0.3-1.8-0.3-2.9c0-0.1,0-0.2,0-0.3c-0.1-0.8-0.2-1.8-0.6-2.2c0-0.2,0-0.4,0-0.6c0.2-2.3-0.6-3.7-0.3-6.1\n                    c-0.1,0-0.2,0-0.3,0c0-0.7,0-1.5,0-2.2c0-0.1,0-0.2,0-0.3c0-1.2,0-2.3,0-3.5c0-0.4,0-0.9,0-1.3c0-0.2,0-0.4,0-0.6\n                    c0.1-0.5-0.1-1.2,0.3-1.3c0-0.4,0-0.9,0-1.3c0.9,0.2-0.2-1.5,0.6-1.3c-0.2-1,0.5-1.2,0.6-1.9c1.4-0.7,1.8-2.4,3.5-2.9\n                    c0,0.4-0.1,0.9,0.3,1c0,0.1,0,0.2,0,0.3c0,0.2,0,0.4,0,0.6c0,0.6,0,1.3,0,1.9c0.2,1-0.3,1.2-0.3,1.9c0,0.3,0,0.6,0,1\n                    c0,0.4,0,0.9,0,1.3c0,0.1,0,0.2,0,0.3C81.5,223.6,81.2,224.6,81,225.7z M83.5,205C83.5,205,83.5,205,83.5,205\n                    C83.5,205,83.5,205,83.5,205L83.5,205z M83.7,206c-0.2-0.2-0.3-0.5-0.2-1C83.5,205.4,83.6,205.7,83.7,206\n                    c0.1,0.1,0.1,0.1,0.2,0.2C83.9,206.1,83.8,206,83.7,206z M84.1,206.3c0.1,0.1,0.3,0.2,0.4,0.2C84.4,206.5,84.2,206.4,84.1,206.3z\n                     M135,104.3c0.3,0.6,0.5,1.2,0.6,1.9c0,0.8,0.6,0.9,0.3,1.9c-0.2,0.6,0.4,1.9-0.3,1.9c-0.7-0.1-0.3-1.2-1-1.3\n                    c0.3-0.9-0.5-0.8-0.3-1.6c0-0.4-0.4-0.4-0.3-1c-0.6-0.4-0.5-1.7-1-2.2c0-0.4-0.4-0.4-0.3-1c0.1-0.4,0.4-0.7,1-0.6\n                    C134.1,103.1,134.8,103.4,135,104.3z M87,216.3C87,216.3,87,216.3,87,216.3C87,216.3,87,216.3,87,216.3S87,216.3,87,216.3z\n                     M98.6,191.5c0,0.2,0,0.4,0,0.6c-0.7,1-1.4,2-1.6,3.5c-0.7,0.6-0.5,2.2-1.3,2.9c-0.5,2.3-0.8,4.7-1.9,6.4c0-2.1,0-4.3,0-6.4\n                    c-0.1-2.1,0.8-3,1-4.8c-0.4-0.7,0.8-1.2,0-1.3c-0.8,0.1-1,1-1.9,1c-0.4,0.1-0.7,0.4-0.6,1c-0.1,0-0.2,0-0.3,0c0,0.1,0,0.2,0,0.3\n                    c-0.9,0.5-1.2,1.5-1.9,2.2c-1.3,1.4-1.5,3.8-2.6,5.4c-0.2,0.8-0.5,1.6-1,2.2c-0.1-1.2,0-2.4,0.3-3.2c0.2-5.1,2.3-8.2,4.2-11.5\n                    c0-0.2,0-0.4,0-0.6c0.6-0.3,0.6-1.1,1-1.6c0.3-0.2,0.5-0.6,0.6-1c0.5-0.5,0.6-1.3,1.3-1.6c-0.1-0.4,0.1-0.6,0.3-0.6\n                    c0.2-0.5,0.5-0.8,0.6-1.3c0.1,0,0.2,0,0.3,0c0-0.2,0-0.4,0-0.6c1-1,2-2.1,2.6-3.5c0.3,0,0.4-0.3,0.6-0.3c-0.1,1-0.6,1.7-0.6,2.9\n                    c-0.3,0.4-0.4,0.9-0.3,1.6c0,0.3,0,0.6,0,1c-0.2,0.1-0.4,0.3-0.3,0.6c0,0.3,0,0.6,0,1c-0.3,0-0.2,0.4-0.3,0.6c0,0.1,0,0.2,0,0.3\n                    c-0.2,0.9-0.5,1.7-0.6,2.6c0,0.5,0,1.1,0,1.6c1.4,0.1,1.5-1,1.9-1.9c0.1,0,0.2,0,0.3,0c0.2-0.7,0.8-0.9,0.6-1.9\n                    c0.3,0,0.2-0.4,0.3-0.6c0.4-0.1,0.3-0.6,0.3-1c0.5,0,0.2-0.9,0.6-1c-0.3-0.9,0.5-0.8,0.3-1.6c0.2-0.7,0.8-0.9,0.6-1.9\n                    c0.6-0.7,1-1.5,1.3-2.6c0.1,0,0.2,0,0.3,0c0-0.6,0.4-0.7,0.3-1.3c0.9-0.7,0.8-2.4,1.9-2.9c0-1.1,1-1.1,1-2.2c0.1,0,0.2,0,0.3,0\n                    c0-0.6,0.9-0.4,0.6-1.3c0.7-0.2,1-1,1.3-1.6c0.5-0.1,0.5-0.5,1-0.6c0.7-1,1.6-1.8,2.6-2.6c0-0.1,0-0.2,0-0.3c0.1,0,0.2,0,0.3,0\n                    c0.6-0.4,1.1-0.8,1.6-1.3c0.4-0.2,0.7-0.3,1-0.6c1.1,0.2,0.4-1.3,1.6-1c-0.1,0.6,0.4,0.7,0.3,1.3c-0.7,0.8-1,2-1.9,2.6\n                    c-0.5,0.5-0.6,1.3-1.3,1.6c-0.8,1.4-1.7,2.5-2.6,3.8c-0.4,0.8-0.8,1.6-1,2.6c-0.5,0.6-0.9,1.3-1.3,1.9c0,0.4-0.2,0.7-0.3,1\n                    c0,0.4-0.1,0.7-0.3,1c-0.3,0.4-0.3,1.2-0.6,1.6c-0.4,0.9-0.7,1.8-1,2.9c-0.7,0.5-0.8,1.5-1.3,2.2c-0.7,0.2-1,0.7-1.6,1\n                    c-0.3,0.6-1.2,0.5-1.3,1.3C100.6,188.4,100,190.4,98.6,191.5z M106.6,280c0,0.2,0,0.4-0.3,0.3c0,0.1,0,0.2,0,0.3\n                    c-1.6,0-3.4,0.2-4.2-0.6c-1.6-0.2-1.5,1.3-2.6,1.6c0,0.1,0,0.2,0,0.3c-1.9,0.6-5.5,2.6-7.7,1c1.5-1,4.1-1,5.4-2.2\n                    c0.5,0,0.8-0.2,1-0.6c0.4-0.1,0.5-0.6,1-0.6c0-0.1,0-0.2,0-0.3c0.1,0,0.2,0,0.3,0c0.4-0.7,0.9-1.2,1.6-1.6\n                    c0.8-0.1,0.7,0.6,1.6,0.3c0.8-0.8-0.4-1.3-0.3-2.2c0.8,0,1,0.6,1.6,0c0-0.1,0-0.2,0-0.3c0.5,0,0.2-0.8,1-0.6\n                    c0.3,0,0.4,0.3,0.6,0.3c4.1,1.3,8.8-1.2,12.8,0c-1,0.5-1.9,1.1-3.2,1.3c-0.4,0.3-0.9,0.4-1.6,0.3c-0.9,1.1-3.2,0.8-4.2,1.9\n                    c1.4,1.2,6.6,0.1,8.6,1.6c-0.1,0.5,0.1,1.2-0.3,1.3C114.2,279.9,109.2,281.5,106.6,280z M109.4,256.4c-0.4-1.1,0.2-1.4-0.3-1.9\n                    c-1.5-3-5.5-6.4-4.2-10.2c0.3,0,0.4,0.3,0.6,0.3c0.3,0.9,1,1.4,1.3,2.2c0.8,0.8,1.1,2.1,2.6,2.2c1.4-3.6-2.6-5.8-1.9-8.6\n                    c1.2,1.8,3.2,2.7,4.2,4.8c0.1,0,0.2,0,0.3,0c0.1,0.3,0.3,0.6,0.6,0.6c1.1,1.8,2.4,3.6,3.5,5.4c0,0.2,0,0.4,0,0.6\n                    c0.6,0.2,0,1.5,0.6,1.6c0.8,4.2,2.1,7.9,1.9,13.1c-2.2-0.5-3.3-2-4.8-3.2c-0.4,0.1-0.3,0.6-0.3,1c-0.1,1.2,0.1,2.1,0.3,2.9\n                    c0.7,2.4,2.3,3.9,3.2,6.1c-4.1,0.2-9.6,2.1-13.1,0c-0.4-1.2-0.8-2.4-1-3.8c0-0.2,0-0.4,0-0.6c0.2-1.2-0.5-1.4-0.3-2.6\n                    c0-0.7,0-1.5,0-2.2c0-0.7,0-1.5,0-2.2c0.5-2.1,0.5-6.5,0-8.6c0.2-0.9-0.4-2.5,0.3-2.9c1.6,2,2.9,4.4,4.8,6.1c0,0.1,0,0.2,0,0.3\n                    C108.6,256.8,109.1,256.6,109.4,256.4z M116.3,250.7c0,0,0.1,0,0.1,0C116.4,250.8,116.3,250.7,116.3,250.7z M116.8,250.5\n                    C116.8,250.5,116.8,250.5,116.8,250.5c0.2-0.2,0.4-0.4,0.6-0.6C117.2,250.1,117,250.3,116.8,250.5z M118.4,271.1\n                    c-0.6-1.5-1.6-2.5-2.2-3.8c0-0.4-0.6-0.7,0-1c0.9,0.5,1.8,1,2.6,1.6C118.5,268.9,119.1,270.6,118.4,271.1z M118.1,276.5\n                    c0,0.6,0,1.3,0,1.9c-1.7,0.2-2.6-0.4-4.2-0.3C115,277.2,116.8,277.2,118.1,276.5z M134.7,284.2c3.2,0,6.6-0.2,9.9-0.3\n                    c0.9-0.3,1.7-0.7,2.9-0.6c2.2-0.2,3.7,0.3,4.8,1.3c-1.9-0.8-3.3,0.7-4.8,0c-0.7-0.3-1.1-0.8-2.2-0.6c0.1,1.3-0.3,2-1.6,1.9\n                    c-1.5-0.2-2-1.4-3.8-1.3c-0.1,0.5-0.5,0.5-0.6,1c-3.2-0.6-5.9,1-8.6-0.6C130.7,283.4,133.4,284.5,134.7,284.2z M124.8,282.6\n                    c1.8,0.1,3-0.4,3.8-1.3c1.1-0.3,1.8-1,2.6-1.6c1.3-0.4,2.4-1,3.5-1.6c1.4-0.4,2.6-0.9,4.2-0.3c0.2,0.1,0.6,0,0.6,0.3\n                    c-2.5-0.3-4,1.5-6.1,2.6c-1.9,1.3-4.7,1.7-7.3,2.2c-0.3,1.2,1.4,0.3,1.6,1c0,0.3-0.4,0.2-0.6,0.3c-1,0.2-1.5-0.2-2.2-0.3\n                    C124.8,283.4,124.8,283,124.8,282.6z M131.5,232.1c0,0.2,0,0.4,0,0.6c-0.2,0-0.4,0-0.3,0.3c0.2,1-0.3,1.2-0.3,1.9\n                    c0,0.1,0,0.2,0,0.3c-0.3-0.1-0.3,0.1-0.3,0.3c-0.6,0.9-0.8,2.1-1.6,2.9c0,0.1,0,0.2,0,0.3c0,0.1,0,0.2,0,0.3\n                    c-0.2,0.3-0.3,0.7-0.3,1.3c-0.5,0.7-0.6,1.7-1.3,2.2c0,1.4-0.9,1.9-1,3.2c-3.6,9-3.3,21.8-3.5,34.2c0.7-0.1,0.1,1.1,0.3,1.6\n                    c0.4,0.9,0.4,2.2,0.3,3.5c-0.3-0.1-0.3,0.1-0.3,0.3c0.5,0.8,1.1,1.5,2.2,1.6c0.3-0.1,0.3,0.1,0.3,0.3c0.1,0,0.2,0,0.3,0\n                    c0.7,0.1,1.3,0.4,1.9,0.6c1.4,0.4,1.5,2.1,3.5,1.9c0.6,0,1,0.1,1.3,0.3c0.1,0,0.2,0,0.3,0c1.4,0.7,2.9,1.4,3.5,2.9\n                    c-1.4-0.8-3.9-0.3-5.4-1c-0.2,0-0.4,0-0.6,0c-0.1-0.3-0.3-0.3-0.3-0.6c-2-0.6-4.9-0.4-6.7-1.9c-0.2,0.1-1.2,0.8-1.3,0\n                    c-1,0.2-0.9-0.6-1.9-0.3c-0.3-0.1-0.3-0.3-0.6-0.3c-1.4,1.1-2.1,0.1-3.5-0.3c-1.1,0.5-1.4,1.8-3.2,1.6c-0.8,0.2-2.9,0.7-3.5,0\n                    c-0.1,0-0.2,0-0.3,0c-0.1,0-0.2,0-0.3,0c-0.4,1.7-2.7,1.5-4.5,1.9c0.4-0.9,1.4-1.4,2.2-1.9c1.2,0.2,1.2-0.7,2.2-0.6\n                    c0-0.3,0.4-0.2,0.6-0.3c0.7-0.3,1.3-0.7,1.9-1c0.4,0.1,0.6-0.1,0.6-0.3c2.7-0.4,4.1-2,7-2.2c0.1-0.4,0.5-0.3,1-0.3\n                    c0.1-0.4,0.4-0.7,1-0.6c0-0.2,0-0.4,0-0.6c0-0.2,0-0.4,0-0.6c0-1.3,0-2.6,0-3.8c0-0.3,0-0.6,0-1c-0.2-2.5,0.3-4.2,0.3-6.4\n                    c0-1.6,0-3.2,0-4.8c0.6-7-0.5-14.1,1-19.8c-0.7,0-0.1-1.4-0.3-1.9c0-0.8-0.1-1.8,0.3-2.2c0.8-0.4,1-1.3,1.3-2.2\n                    c0-1.3-0.1-2.6,0.3-3.5c0.4-1,0.8-2,1.3-2.9c0.9-1.9,2.5-3.3,4.2-4.5c0.4,0,0.4-0.4,1-0.3c0-0.1,0-0.2,0-0.3\n                    c0.2-0.1,0.6,0,0.6-0.3c0.4-0.2,0.7-0.3,1-0.6C133.4,229.3,131.1,230.8,131.5,232.1z M161.2,179.4c0,0.7,0,1.5,0,2.2\n                    c-0.1,5.9-1.5,10.7-2.9,15.3c-0.5,0.3-0.7,0.8-0.6,1.6c-0.4,0-0.3,0.6-0.6,0.6c-0.1,0.2,0,0.6-0.3,0.6c-0.1,0.9-0.6,1.6-1.3,1.9\n                    c0,0.5-0.2,0.8-0.6,1c0,0.4-0.2,0.7-0.3,1c-0.9,0.4-0.9,1.6-1.9,1.9c0,0.1,0,0.2,0,0.3c-0.3-0.1-0.3,0.1-0.3,0.3\n                    c-0.3,0.1-0.6,0.3-0.6,0.6c-0.9,0.9-1.5,2.1-2.6,2.9c-0.4,1.1-1.1,1.9-1.9,2.6c-3.6,4.5-9.6,6.6-12.8,11.5c-1,0-0.6,1.3-1.3,1.6\n                    c-0.8,0-1.1,0.6-1.6,1c-0.3,0.3-0.9,0.2-1,0.6c-0.1,0-0.2,0-0.3,0c-0.4,0.3-1,0.5-1.3,1c-1.7,0.4-2.4,1.6-4.2,1.9\n                    c-0.2,0.6-1.5,0.2-1.6,1c-0.5-0.1-0.5,0.3-1,0.3c-0.9,0.2-1.7,0.5-2.6,0.6c0.1,0.3-0.1,0.3-0.3,0.3c-0.8,0-1.5,0.2-1.9,0.6\n                    c-2.6,0.3-4.8,1-7.7,1c0.1,0.7-1.1,0.1-1.6,0.3c-1.4-0.3-2.3,0.8-3.2,0c-0.3-0.2-0.5-0.3-1-0.3c-0.1-0.7-0.4-1.3-0.6-1.9\n                    c-0.6-0.2,0-1.5-0.6-1.6c0-0.2,0-0.4,0-0.6c-0.5-1.1-0.8-2.4-0.6-4.2c0-0.4,0-0.9,0-1.3c0.1,0,0.2,0,0.3,0\n                    c0.4,0.8,0.8,1.6,1.3,2.2c0.8,0.5,0.9,1.6,1.6,2.2c0.6,0.7,1,1.8,2.6,1.6c0-0.4,0-0.9,0-1.3c0-0.1,0-0.2,0-0.3\n                    c0.1-0.7-0.2-0.8-0.3-1.3c-0.2-0.3-0.3-0.7-0.3-1.3c0-0.1,0-0.2,0-0.3c1.7,0.3,1.7,2.4,3.8,2.2c0,0.1,0,0.2,0,0.3\n                    c0.9,0,2.1,1.4,2.6,0c-2.2-2.9-3.2-7-4.8-10.5c-0.4-0.2,0-1.2-0.6-1.3c0.2-1.2-0.4-1.5-0.3-2.6c0-0.2,0-0.4,0-0.6\n                    c0-0.8-0.6-0.9-0.3-1.9c0-0.2,0-0.4,0-0.6c0.1-1.3-0.5-3.3,1.3-2.9c0.5-0.2,0.8-0.5,1.3-0.6c0.6,0.1,0.7-0.4,1.3-0.3\n                    c0.4-0.3,0.9-0.4,1.6-0.3c0.3-0.6,1.1-0.6,1.6-1c1.2-0.4,2-1.2,3.2-1.6c0.1-0.5,0.7-0.4,1-0.6c0.4-0.4,1.6-0.1,1.6-1\n                    c1.8-0.6,3.3-1.4,4.5-2.6c0.2,0,0.4,0,0.3-0.3c0.8,0.3,1.2-1.5,1.3,0c-0.2,0-0.4,0-0.3,0.3c-1.3,1.3-2.6,2.7-3.8,4.2\n                    c-0.5,0.2-0.8,0.5-1,1c-0.9-0.2-0.6,0.6-1.3,0.6c-1.1,1.3-2.6,2.1-4.2,2.9c-0.1,0.7-0.9,0.6-1.3,1c-1.4,0.4-2.2,1.4-3.8,1.6\n                    c0,0.6-1.1,0.2-1.3,0.6c0,0.3,0,0.6,0,1c0,0.1,0,0.2,0,0.3c0.4,0.5,1.1,0.9,1.9,1c0.5,0,1.1,0,1.6,0c-0.2,1,0.3,1.2,0.3,1.9\n                    c0.8,0,1.3-0.2,1.6-0.6c3.1-1.7,5.7-3.9,8.9-5.4c0-0.1,0-0.2,0-0.3c0.5,0,0.8-0.2,1-0.6c0.2-0.1,0.6,0,0.6-0.3\n                    c0.3,0,0.4-0.3,0.6-0.3c0.9-0.5,1.6-1.2,2.6-1.6c0.2,0,0.4,0,0.3,0.3c-1.2,1.2-2.2,2.7-3.2,4.2c-0.2,0-0.4,0-0.3,0.3\n                    c-1.2,1.3-2.3,2.6-3.2,4.2c-0.6,0.3-1,0.7-1.3,1.3c-1,1-2.4,1.7-3.2,2.9c-0.1,0-0.2,0-0.3,0c-0.4,0.7-1.3,1-1.9,1.6\n                    c-0.5,0.1-0.5,0.5-1,0.6c-0.3,1-1.6,0.9-1.9,1.9c2.5,0.1,3.7-1.2,5.4-1.9c1.5-1.4,3.9-1.8,5.8-2.9c0.4-0.2,0.7-0.3,1-0.6\n                    c1,0,1.2-0.7,1.9-1c0.9-0.6,2.2-1,2.9-1.9c0.7,0.2,1-0.9,1,0.3c-0.8,0.5-1.4,1.1-1.9,1.9c-0.1,0.7-0.9,0.6-1,1.3\n                    c-1.1,0.8-2.1,1.8-2.9,2.9c-0.1,0.4-0.4,0.7-1,0.6c0.1,0.7-0.9,0.4-1,1c-0.2,0.8,0.1,1.1,1,1c0.8-0.3,1.3-0.9,2.2-1\n                    c0.1-0.3,0.3-0.6,0.6-0.6c0.6,0,0.4-0.9,1.3-0.6c0.1-0.4,0.6-0.5,0.6-1c0.4,0.1,0.6-0.1,0.6-0.3c0.6-0.3,1.4-0.6,1.6-1.3\n                    c0.1,0,0.2,0,0.3,0c0.3,0.1,0.3-0.1,0.3-0.3c0.2,0,0.4,0,0.3-0.3c1-0.5,1.9-1.1,2.6-1.9c2.2-1.3,3.6-3.2,5.8-4.5\n                    c0.5-0.6,0.9-1.5,1.9-1.6c0.1-0.4,0.4-0.5,0.6-0.6c2.2-2.4,4.4-4.7,6.7-7c-0.2-0.9,0.6-0.6,0.6-1.3c0.5-0.2,0.8-0.5,1-1\n                    c0.1-0.4,0.4-0.5,0.6-0.6c0-0.4,0.1-0.7,0.3-1c0.1,0,0.2,0,0.3,0c0-0.8,0.6-1.1,1-1.6c0-0.1,0-0.2,0-0.3c0.9-1.9,1.9-3.6,2.6-5.8\n                    c0.4-0.1,0.3-0.5,0.3-1c0.5-1.1,0.7-2.5,1-3.8c1.1-2.7,1.6-6,2.2-9.3c0-1.6,0.1-3.1,0.6-4.2c0.4,1.7,0.8,3.5,1.3,5.1\n                    C161.2,178.9,161.2,179.2,161.2,179.4z M122.5,182.9c0,0.5,0,1,0,1.4C122.6,183.9,122.5,183.4,122.5,182.9z M122.5,182.9\n                    c0.2,0.2,0.5,0.3,0.9,0.3c0.1,0,0.2,0,0.4,0c0,0,0,0,0,0c0.2,0,0.4,0,0.6,0c-0.2,0-0.4,0-0.6,0c0,0,0,0,0,0c-0.1,0-0.3,0-0.4,0\n                    C123.1,183.2,122.7,183.1,122.5,182.9z M123.2,204c0.1,0.5,0.4,0.4,0,0.9C123.6,204.4,123.3,204.4,123.2,204z M165,152.2\n                    c-0.2-1.3-0.7-2.3-1-3.5c0-0.1,0-0.2,0-0.3c-0.2-1.3-0.8-2.2-1.3-3.2c-0.4-1.2-0.9-2.3-1.6-3.2c-0.2-1.2-0.9-2.1-1.6-2.9\n                    c0.1-0.8-0.5-1-1-1.3c-1.3,0.5,0.1,2.5,0,3.8c0.2,0.5-0.4,1.7,0.3,1.6c0.3,3,1.1,5.5,1.6,8.3c0,0.1,0,0.2,0,0.3\n                    c-0.7-0.1-0.3-1.2-1-1.3c0.1-1.2-0.7-1.7-1-2.6c0.1-0.3-0.1-0.3-0.3-0.3c0.1-0.4-0.1-0.6-0.3-0.6c-1.1-1.8-1.5-4.2-3.5-5.1\n                    c-0.4,0.1-0.3,0.8-0.3,1.3c0.7,0.3,0.1,2,0.3,2.9c0.9,1.9,1,4.6,1.6,6.7c0.4,0.4,0.4,1.1,0.3,1.9c0.3,0.9,0.7,3.3,0,4.2\n                    c-0.6-0.9-0.7-2.3-1-3.5c-0.9-1.4-1.3-3.2-1.9-4.8c-0.2-0.5-0.5-0.8-0.6-1.3c-0.4-0.5-0.9-0.8-1-1.6c-0.7-0.1-0.6-0.9-1.3-1\n                    c-1.4,0.8,0.5,2.8,0.3,4.5c0,0.2,0,0.4,0,0.6c0,0.1,0,0.2,0,0.3c0,0.1,0,0.2,0,0.3c-0.1,0.5,0.3,0.5,0.3,1\n                    c0.2,1.5,0.5,2.9,0.3,4.8c0,0.6,0,1.3,0,1.9c0,1.9,0,3.8,0,5.8c0,0.2,0,0.4,0,0.6c-0.7,0.1-0.1,1.6-0.3,2.2\n                    c-0.3,0.1-0.3-0.1-0.3-0.3c-0.3-1.5-0.7-2.9-1-4.5c-0.1-0.9-0.6-1.3-0.6-2.2c-1.1-2.6-0.9-6.4-4.2-6.7c0,0.3,0,0.6,0,1\n                    c0.8,2.1,0.6,5.3,0.6,8.3c0,0.2,0,0.4,0,0.6c0.2,1.4-0.5,1.8-0.3,3.2c0,0.4-0.4,0.4-0.3,1c0,0.4-0.4,0.4-0.3,1\n                    c-0.1,0.3-0.5,0.8-0.6,0.3c-0.1-0.2,0-0.6-0.3-0.6c0-1.2,0-2.3,0-3.5c-0.7-0.1-0.1-1.6-0.3-2.2c-0.6-0.2,0-1.5-0.6-1.6\n                    c-0.1-1.9-0.2-3.8-1.9-4.2c-0.7,0.3-0.7,1.5-0.6,2.6c-0.7,0.5-0.1,2.2-0.6,2.9c0.2,1.7-0.6,2.4-0.6,3.8c-0.5,0.4-0.6,1.1-0.6,1.9\n                    c-0.7-0.2-0.1-1.8-0.3-2.6c0.4-0.4,0.3-1.4,0.3-2.2c0.7-0.6,0.1-2.5,0.6-3.2c0-0.4,0-0.9,0-1.3c-0.2-1,0.6-1.1,0.3-2.2\n                    c0-1.3,0-2.6,0-3.8c1-1.6-0.2-3.8,0-5.8c-0.1-1,0.2-2.3-0.3-2.9c0-1.2-0.1-2.2-1.3-2.2c-0.2,0.3-0.3,0.5-0.3,1c0,0.7,0,1.5,0,2.2\n                    c-1,1.7-1,4.3-1.6,6.4c-0.9,2.4-1.2,5.4-2.2,7.7c-0.2,0.4-0.3,0.7-0.6,1c-0.2-1.4,0.2-2.1,0.3-3.2c0-0.1,0-0.2,0-0.3\n                    c0-0.7,0-1.5,0-2.2c0-0.9,0-1.7,0-2.6c0-2.3-0.4-4.3-1-6.1c0-0.4,0-0.9,0-1.3c0-0.1,0-0.2,0-0.3c-0.3-0.4-0.4-0.9-0.3-1.6\n                    c-0.4-0.1-0.3-0.6-0.3-1c-0.2-0.3-0.3-0.5-0.3-1c-0.1,0-0.2,0-0.3,0c0.2-1-0.5-1.2-0.6-1.9c-0.1-0.3-0.3-0.6-0.6-0.6\n                    c-1.1-1.3-0.3,2-1,2.2c0.1,0.7-0.2,0.8-0.3,1.3c0,0.4,0,0.9,0,1.3c-0.5,0.3-0.3,1.4-0.6,1.9c0,0.1,0,0.2,0,0.3\n                    c-0.6,0.6-0.4,1.9-1,2.6c-0.3,0.7,0,3.1-1,2.2c0-0.1,0-0.2,0-0.3c-0.2-1.6,0.4-4-0.3-5.1c0.2-1.4-0.2-2.1-0.3-3.2\n                    c-0.1-1.1-0.7-1.8-0.6-3.2c-0.1,0-0.2,0-0.3,0c-0.5-2.1-2.2-7.6-4.2-5.1c-0.1,3.5-0.9,6.3-1.6,9.3c-0.6-0.9-1-2-1.3-3.2\n                    c-0.5-0.6-0.4-2-1-2.6c0-1.1-0.5-1.6-0.3-2.9c-0.7-0.3-0.1-2-0.3-2.9c-1.9-0.4-1.6,1.4-2.9,1.6c0.2-2-0.6-3.1-0.3-5.1\n                    c0-0.1,0-0.2,0-0.3c0-0.9,0-1.7,0-2.6c0-0.4,0-0.9,0-1.3c0.1-0.8,0.5-1.2,0.3-2.2c-1.8-0.4-1.5,1.2-1.9,2.2\n                    c-0.5,0.9-0.5,2.3-1,3.2c0,0.5,0.2,1.2-0.3,1.3c-0.1,1.6,0.2,3.7-1,4.2c0-1.4-0.7-2-0.6-3.5c0-0.3,0-0.6,0-1\n                    c-0.7-0.1-0.1-1.6-0.3-2.2c-0.7-3-0.1-7.3-0.3-10.9c0-0.5,0-1.1,0-1.6c0.1,0,0.2,0,0.3,0c0.2-0.5-0.4-1.7,0.3-1.6\n                    c0-1.6,0.5-2.6,0.3-4.5c-0.5-0.1-0.5,0.3-1,0.3c-0.2,0.3-0.3,0.7-0.3,1.3c-0.5,0.1-0.1,1-0.6,1c0,0.3,0,0.6,0,1\n                    c-0.2,0.1-0.4,0.3-0.3,0.6c-1,0.8-0.5,3.2-1.3,4.2c0,0.2,0,0.4,0,0.6c0,0.3-0.3,0.4-0.3,0.6c-0.1,1.2-0.4,2.1-0.6,3.2\n                    c-0.1,1.4-0.6,2.6-0.6,4.2c0,0.1,0,0.2,0,0.3c0,0.5-0.2,0.8-0.6,1c-0.2-0.9-0.1-2-0.6-2.6c-0.1-3.1,0.3-5.6,1-8\n                    c0-0.8,0-1.5,0.3-1.9c0.2-1.2,0.3-2.4,0.6-3.5c-0.2-1,0.6-1,0-1.6c-1.5-0.4-1,1.1-1.9,1.3c-1.1,1.3-1.5,3.1-2.6,4.5\n                    c0.3-2.1,0.5-4.2,1.3-5.8c0.1-0.7,0.4-1.3,0.6-1.9c0.7-1.1,1.1-2.6,1.9-3.5c0.4-1.6,0.9-3.2,2.2-3.8c0.2-0.7,1.1-0.9,1.3-1.6\n                    c0.3-0.1,0.6-0.3,0.6-0.6c0.5-0.9,1.3-1.5,1.3-2.9c0.3,0.1,0.3-0.1,0.3-0.3c0-0.4,0.4-0.4,0.3-1c0.5-0.7,0.7-1.7,1.3-2.2\n                    c0.1-0.3,0.3-0.3,0.3-0.6c1.7,0.2-0.7,2.6,1.3,2.6c0.7-0.1,0.3-1.2,1-1.3c0.1-1.5,0.8-2.4,1.3-3.5c0.1-0.2,0-0.6,0.3-0.6\n                    c0-0.2,0-0.4,0.3-0.3c0-0.5,0.2-0.8,0.6-1c0.4-1,1.1-1.7,1.9-2.2c0.7-0.3,1-1.1,2.2-1c2.8-0.9,6.3,0.1,8,1.3c0.4,0,0.7,0.1,1,0.3\n                    c0.5,0.4,0.8,0.9,1.6,1c0.1-0.4,0.6-0.5,0.6-1c0.6-0.6,1.6-0.7,2.6-1c0.2,0,0.4,0,0.6,0c0.5-0.7,2.4-0.1,3.5-0.3\n                    c1.1-0.3,1.2,0.5,2.2,0.3c1,1-3.2,1.5-4.5,2.2c-0.9,0.7-2.1,1.1-2.6,2.2c-0.9,0.9-1.5,2.1-2.2,3.2c0.3,0.9-0.5,0.8-0.3,1.6\n                    c-0.1,0.6-0.7,0.8-0.6,1.6c0.3,0.4,0.4,0.9,0.3,1.6c0.6,0,1,0.1,1.3,0.3c0.2,0,0.4,0,0.6,0c0.1-0.7,1.6-0.1,2.2-0.3\n                    c1.1-0.4,2.5-0.5,3.2-1.3c1.2,0.2,1.2-0.7,2.2-0.6c-0.1,0.2,0,0.6-0.3,0.6c-0.6,0.4-1.1,0.8-1.6,1.3c-2.3,0.9-3.8,2.6-7,2.6\n                    c-0.1-0.4-0.5-0.3-1-0.3c-0.1,0-0.2,0-0.3,0c-0.1,0.7-0.9,0.6-1,1.3c-0.4,0.3-1.2,0.3-1.6,0.6c0,0.1,0,0.2,0,0.3\n                    c-0.7,0.1,0,1.7-0.6,1.9c-0.4,0-0.7,0.2-1,0.3c-0.6-0.1-1.6,0.3-1.3-0.6c-0.8-0.5-0.3-2.3-1-2.9c0-0.1,0-0.2,0-0.3\n                    c-0.4-0.4-1.2-0.4-1.6,0c-1.1,0.8-0.8,1.7-0.6,3.2c-0.3,0-0.6,0-1,0c-0.1-0.5-1-0.1-1-0.6c-0.5,0-0.5,2.2,0,2.2\n                    c0.2,1.3,0.9,2,2.2,2.2c0.5-0.1,0.6,0.2,0.6,0.6c-0.5,0.7-0.7,1.7-0.6,2.9c0,0.8,0,1.5,0.3,1.9c0.1,0.3,0.3,0.3,0.3,0.6\n                    c0.1,0.7,0.9,0.6,1.3,1c0.8,0.7,2.3,0.7,3.8,0.6c0.4,0.8,1.1,1.5,1.6,2.2c0.3,0.8,1.3,1.1,1.6,1.9c0.9,0.3,1.8,0.5,2.6,1\n                    c0.8,0.4,2.2,0.1,2.9,0.6c1.4-0.3,1.9,0.4,3.2,0.3c1.1,0.1,1.8,0.5,3.2,0.3c0.4,0.6,1.7,0.3,2.2,0.6c0.6-0.1,0.7,0.4,1.3,0.3\n                    c0.3,0.2,0.7,0.3,1.3,0.3c0.6,0,0.7,0.4,1.3,0.3c0.3-0.1,0.3,0.1,0.3,0.3c0.2,0,0.4,0,0.6,0c0.4,0.5,1.4,0.5,1.9,1\n                    c0.1,0,0.2,0,0.3,0c0.5,0.6,1.4,0.8,1.9,1.3c0.8,0.5,1.5,1.1,2.2,1.6c0.5,0.2,0.8,0.5,1,1c0.2,0.1,0.6,0,0.6,0.3\n                    c2.2,2,3.7,4.6,5.1,7.3c2.6,2.5,2.3,6.4,2.6,10.9c0,0.1,0,0.2,0,0.3c0,0.6,0.1,1,0.3,1.3c0,0.6,0,1.3,0,1.9\n                    C164.9,149.6,166,151.3,165,152.2z\"/>\n            </g>\n        </g>\n        <g>\n            <path d=\"M38.9,318.1l-0.3-11.8c0-0.2,0.1-0.4,0.3-0.6c0.2-0.2,0.4-0.3,0.7-0.3c0.3,0,0.5,0.2,0.7,0.6s0.3,1.1,0.3,2.1\n                c0,2.6,0.1,6.6,0.3,11.9s0.3,9.3,0.3,11.9c0,0.3-0.1,0.6-0.3,0.9c-0.2,0.3-0.5,0.4-0.8,0.4c-0.6,0-0.9-0.4-0.9-1.2\n                c0-4.5-0.1-8.7-0.3-12.7c-0.6-0.1-1.2-0.2-1.8-0.2c-0.5,0-1,0.1-1.4,0.3c0,1.3,0.1,3.3,0.3,6.1c0.2,2.7,0.3,4.8,0.3,6.2\n                c0,0.2-0.1,0.5-0.2,0.7c-0.1,0.2-0.3,0.3-0.6,0.3c-0.4,0-0.7-0.2-0.9-0.5s-0.3-1.2-0.4-2.6c-0.1-1.4-0.1-2.9-0.1-4.5\n                s0-2.6-0.1-2.9c-0.4-6.2-0.7-11.6-0.7-16v-0.3c0-0.4,0.2-0.6,0.6-0.6c0.7,0,1.2,0.3,1.3,0.8c-0.1,0.9-0.1,1.8-0.1,2.7l0.2,7.4\n                l0,1.4c0,0.3,0,0.7,0.1,0.9L38.9,318.1z\"/>\n            <path d=\"M53,322.9c0,6.9-1.4,10.4-4.2,10.4c-2.6,0-4.1-3.3-4.4-9.8c0-0.6,0-1.2,0-1.9l0-2.2v-0.7c0-5.1,0.7-8.2,2.2-9.4\n                c0.4-0.3,0.8-0.5,1.2-0.5c0.3,0.1,0.8,0.2,1.3,0.3s0.9,0.2,1.1,0.3c0.4,0.2,0.9,0.7,1.4,1.6c0.5,0.8,0.9,2,1.1,3.4\n                c0.2,1.4,0.4,2.8,0.4,4.2V322.9z M46.3,314.4l0.1,2.1l0,3.5c0,0.3,0,0.6,0,1c0,0.4,0,0.9,0,1.6c0,0.7,0.1,1.3,0.1,1.9\n                c0.1,0.6,0.1,1.3,0.2,2c0.1,0.7,0.2,1.4,0.3,2c0.1,0.6,0.2,1.2,0.4,1.6c0.3,1.1,0.7,1.6,1.3,1.6c0.7,0,1.2-0.7,1.6-2\n                c0.5-1.9,0.8-4.3,0.8-7.2l0.1-3.7c0-2.6-0.1-4.4-0.3-5.3s-0.4-1.6-0.6-2c-0.4-0.9-1-1.4-1.8-1.4c0,0,0,0-0.1,0\n                C47,310.3,46.3,311.6,46.3,314.4z\"/>\n            <path d=\"M59.7,329.3l0.1-1.2c-0.1-0.3-0.3-3-0.6-8.1c-0.3-5.1-0.5-8.3-0.5-9.4c-1.4,0-2.2-0.2-2.6-0.4c-0.3-0.2-0.5-0.4-0.5-0.7\n                c0-0.2,0.1-0.4,0.4-0.6c0.3-0.1,0.5-0.2,0.8-0.2l4.9,0.3l0.6,0c0.8,0,1.1,0.3,1.1,0.9c0,0.3-0.1,0.5-0.4,0.7\n                c-0.2,0.2-0.5,0.3-0.8,0.3l-1.7-0.2l-0.1,0.4c0,2.3,0.2,5.7,0.6,10.2s0.6,8,0.6,10.3c0,0.3-0.1,0.5-0.3,0.8\n                c-0.2,0.2-0.5,0.3-0.8,0.3h-0.8L59.7,329.3z\"/>\n            <path d=\"M73.2,315l-0.3,2.5c0,1.2,0.2,3.5,0.5,6.7c0.3,3.3,0.6,5.1,0.9,5.5c0.5,0.8,1.4,1.2,2.5,1.2c1.1,0,2-0.3,2.6-1\n                c0.4,0,0.8-0.1,1.1-0.2v0.5c0,0.7-0.2,1.3-0.6,1.8c-0.7,0.8-1.8,1.2-3.3,1.2c-0.8,0-1.6-0.3-2.4-0.8c-0.8-0.5-1.4-1.3-1.8-2.1\n                c-0.4-0.9-0.7-3.1-1-6.7c-0.2-3.6-0.4-6.4-0.4-8.3c0-1.9,0.1-3.3,0.2-4.2c-0.1-0.4-0.1-0.8-0.1-1.1c0-1.5,0.6-2.7,1.7-3.5\n                c1.1-0.9,2.5-1.3,4.1-1.3c0.6,0,1.1,0.2,1.7,0.5s0.8,0.7,0.8,1.3c0,0.3-0.1,0.5-0.3,0.6c-0.2,0.1-0.5,0.2-0.8,0.2\n                c-0.4,0-0.6-0.1-0.8-0.4v0.1H77v-0.1c-1.9,0-3,0.8-3.5,2.4c-0.2,0.8-0.4,1.8-0.4,3.1L73.2,315z\"/>\n            <path d=\"M85.5,310.9l-0.1,9c0.4,0.1,1.1,0.2,1.9,0.2h1.4v-0.8c0-1.1-0.1-2.8-0.2-5c-0.2-2.2-0.2-3.9-0.2-5c0-0.3,0.1-0.5,0.3-0.7\n                c0.2-0.2,0.4-0.3,0.5-0.3s0.3,0,0.4,0c0.1,0,0.2,0,0.3,0c0.1,0,0.2,0,0.3,0.1c0.2,0.1,0.3,0.4,0.3,0.8c0,2.5,0.1,6.3,0.3,11.3\n                c0.2,5,0.3,8.8,0.3,11.3c0,0.2-0.1,0.4-0.3,0.5c-0.2,0.1-0.4,0.2-0.7,0.2c-0.3,0-0.5-0.1-0.8-0.2c-0.2-0.1-0.4-0.3-0.4-0.6\n                c-0.1-2.4-0.2-5.3-0.2-8.8v-0.1l0-1l0-0.3v0c-0.2,0-0.5,0.1-0.8,0.1l-2.2-0.3l-0.1,4v0.2l0.3,5.9c0,0.4-0.1,0.7-0.3,0.9\n                c-0.2,0.3-0.4,0.4-0.7,0.4c-0.5,0-0.8-0.4-1-1.3c-0.2-0.9-0.3-2.1-0.3-3.6l0.1-5.5l0-2.1l0.1-2.1l-0.2-8.1c0-0.3,0.1-0.5,0.3-0.7\n                c0.2-0.2,0.4-0.3,0.7-0.3C85.2,308.7,85.5,309.5,85.5,310.9z\"/>\n            <path d=\"M99,332.2l-1.4,0l-1.6,0.1c-0.7,0-1.1-0.2-1.3-0.7c0-0.4,0-0.6,0.1-0.8c0.1-0.2,0.3-0.3,0.6-0.3h1l0.1-0.5l-0.2-7.7l0.2-8\n                c0-1.4-0.1-2.6-0.2-3.8c-0.5,0-1,0-1.4,0s-0.7-0.1-0.9-0.2c-0.2-0.1-0.3-0.4-0.3-0.8c0-0.6,0.7-0.8,2-0.8h0.1\n                c3.1,0,4.6,0.4,4.6,1.2c0,0.1-0.1,0.4-0.2,0.7h-1.9c0.1,0.9,0.1,1.9,0.1,3.1l-0.2,6.9l0.3,7.7v1.1c0,0.2,0,0.5-0.1,1h1.5\n                c1,0,1.5,0.3,1.5,0.9c0,0.3-0.1,0.5-0.3,0.7c-0.2,0.2-0.4,0.3-0.6,0.3L99,332.2z\"/>\n            <path d=\"M110.1,330.9c0.7,0,1.1,0.3,1.1,0.8c0,1-0.7,1.4-2,1.4c-0.6,0-1.1-0.1-1.7-0.2c-0.6-0.2-1-0.3-1.3-0.5\n                c-1.6-1-2.4-3.9-2.4-8.5l0-2.1c0-6.9,0.8-11,2.5-12.2c0.9-0.6,2.1-1,3.6-1c0.3,0,0.5,0.1,0.7,0.3c0.2,0.2,0.3,0.4,0.3,0.7v0.1\n                c-0.2,0.6-0.8,0.8-1.7,0.8l-0.7,0c-0.4,0-0.8,0.2-1.1,0.7s-0.5,1-0.7,1.6c-0.2,0.6-0.3,1.3-0.4,2c-0.2,1.2-0.2,2.3-0.2,3.3v0.2\n                l-0.2,7c0,1.5,0.1,2.5,0.2,3c0.2,0.6,0.3,1,0.5,1.4s0.4,0.6,0.6,0.9c0.5,0.5,1.2,0.8,2.1,0.8C109.6,331.2,109.9,331.1,110.1,330.9\n                z\"/>\n            <path d=\"M116.9,309.9l-0.3,6.6v1.9c0.1-0.1,0.5-1.1,1.3-2.9c2-4.4,3.3-6.6,3.8-6.6c0.4,0,0.7,0.1,1,0.2s0.4,0.4,0.4,0.7\n                c0,0-0.6,1-1.8,3.1s-1.9,3.2-2,3.5l-0.1,2.1c0,1,0.4,3,1.2,5.8c0.8,2.8,1.5,4.7,2.1,5.6c0.1,0.1,0.2,0.3,0.5,0.7\n                c0.2,0.3,0.4,0.6,0.5,0.9c0.1,0.2,0.2,0.5,0.2,0.8c0,0.3-0.1,0.5-0.3,0.7c-0.2,0.2-0.4,0.3-0.7,0.3c-0.6,0-1.2-0.6-1.8-1.8\n                c-0.6-1.2-1.2-2.7-1.6-4.4c-0.8-2.9-1.4-5.5-1.8-7.7c-0.4,0.4-0.7,1-0.9,1.6c-0.2,0.7-0.3,1.2-0.3,1.4v9.9c0,0.6-0.3,0.8-0.8,0.8\n                c-0.4,0-0.7-0.1-0.9-0.3c-0.2-0.2-0.3-0.5-0.3-0.8v-11c0-1.3,0.1-3.2,0.3-5.8c0.2-2.6,0.3-4.5,0.3-5.8c0.2-0.5,0.5-0.7,0.9-0.7\n                C116.5,308.7,116.9,309.1,116.9,309.9z\"/>\n            <path d=\"M129.8,331.3l1.4-0.1c0.9,0,1.4,0.3,1.4,0.9c0,0.4-0.2,0.6-0.5,0.8c-0.3,0.2-0.7,0.2-1.1,0.2h-3.4c-0.3,0-0.6-0.1-0.8-0.3\n                c-0.2-0.2-0.3-0.5-0.4-0.8c0-0.3,0-0.7,0.1-1.2c0.1-0.5,0.1-0.9,0.1-1.2l-0.2-4.6l0.2-10.5l-0.2-3c0-1.7,0.5-2.6,1.5-2.6\n                c0.3,0,0.5,0.1,0.8,0.3c0.1,0,0.3,0,0.7,0.1c0.4,0,0.7,0.1,0.9,0.1c0.3,0,0.6,0.1,0.9,0.2c0.7,0.2,1,0.5,1,1\n                c0,0.5-0.4,0.9-1.1,1.1c-1.1-0.4-2-0.6-2.7-0.7c0,0.5,0.1,1,0.1,1.5l-0.2,5.2c0,0,0,0.2,0.1,0.6l1.3-0.1c1.2,0,1.7,0.3,1.7,1\n                c0,0.4-0.1,0.7-0.3,0.9c-0.2,0.3-0.5,0.4-0.9,0.4s-0.7-0.1-1-0.3h-0.9c0.1,0.9,0.1,1.8,0.1,2.6l-0.2,6.5\n                C128.5,330.6,129,331.3,129.8,331.3z\"/>\n            <path d=\"M137.5,318.4l0.2,9.3v4.1c0,0.3-0.1,0.6-0.2,0.8c-0.2,0.2-0.4,0.3-0.7,0.3c-0.8,0-1.2-0.7-1.2-2.2l-0.1-12.7l0.2-6.7\n                c0-1.6,0.4-2.4,1.3-2.4c0.5,0,0.9,0.4,1.1,1.2c0.3,1.6,0.9,3.8,1.7,6.7s1.4,5.1,1.7,6.6c0.2,0.7,0.5,1.8,0.9,3.3\n                c0.4,1.5,0.6,2.5,0.8,3.3c0.1-5.2,0.1-11.5,0.1-19l-0.1-1c0-0.3,0.1-0.6,0.2-0.8c0.1-0.2,0.3-0.3,0.6-0.3c0.3,0,0.5,0.1,0.7,0.2\n                c0.4,0.3,0.6,0.7,0.6,1.2c0,3.3-0.1,7.5-0.3,12.7c-0.2,5.2-0.5,8.4-0.8,9.7c0,0-0.1,0-0.3,0.1c-0.2,0.1-0.3,0.1-0.3,0.1\n                c-0.7,0.2-1.1,0.1-1.3-0.1c-0.2-0.2-0.3-0.5-0.4-0.8c-0.1-0.4-0.2-0.7-0.3-1s-0.5-1.9-1.1-4.8c-1.7-7.6-2.8-12-3.2-13.2V318.4z\"/>\n            <path d=\"M154.3,307.9c0-1.6,0.5-2.4,1.4-2.4c1.1,0,2.1,0.3,2.9,0.8c1.6,1,2.5,2.8,2.5,5.1c0,1.8-0.7,3.8-2.2,5.8\n                c1,1.4,1.6,2.3,1.9,2.6c0.2,0.3,0.4,0.5,0.6,0.8c0.2,0.3,0.3,0.4,0.3,0.5c0,0.1,0.1,0.2,0.1,0.6s0.1,0.6,0.1,0.8\n                c0,0.6,0.1,1.3,0.2,2c0.1,0.8,0.2,1.2,0.2,1.3s0,0.4-0.1,0.9c-0.1,0.5-0.2,0.9-0.3,1c0,0.2-0.1,0.4-0.2,0.7\n                c-0.1,0.3-0.2,0.5-0.2,0.7s-0.1,0.3-0.2,0.6c-0.1,0.2-0.2,0.4-0.3,0.5c-0.1,0.1-0.2,0.3-0.4,0.5c-0.2,0.2-0.3,0.4-0.5,0.5\n                c-0.2,0.1-0.4,0.3-0.6,0.4c-0.7,0.5-1.4,0.8-2,1c-0.6,0.1-0.9,0.2-1,0.2h-0.2c-0.7,0-1.1,0-1.3-0.1c-0.3-0.2-0.5-0.4-0.5-0.8\n                l0.2-8.9l-0.2-14.7V307.9z M156.8,307.6c-0.3,0-0.5,0.4-0.5,1.3c0,0.9,0,2.2,0.1,4.1c0,1.8,0.1,3.2,0.1,4c0.9-0.2,1.6-1.3,2.2-3.2\n                c0.3-1,0.5-1.6,0.6-1.8v-1.3c0-0.7-0.2-1.4-0.7-2.1C158,307.9,157.4,307.6,156.8,307.6z M157.6,318.8L157.6,318.8l-1.2,0\n                c0.1,3,0.2,7.1,0.2,12.3c1.2-0.2,2.1-0.7,2.7-1.7c0.7-0.9,1-2,1-3.3C160.3,322,159.4,319.6,157.6,318.8z\"/>\n            <path d=\"M167.4,312.4l0.1,8.7c-0.1,0.3-0.2,1-0.2,2l-0.1,5.7c0,1.7,0.4,2.5,1.2,2.5l1.5-0.1c1.3,0,1.9,0.4,1.9,1.1\n                c0,0.3-0.1,0.5-0.3,0.6c-0.2,0.2-0.5,0.3-0.8,0.3c-0.9-0.3-2-0.4-3.2-0.4c-0.4,0.2-0.8,0.3-1.1,0.3s-0.6-0.1-0.8-0.4\n                c-0.2-0.2-0.3-0.5-0.3-0.8l0.4-16.1v-0.3c-0.1-0.8-0.1-1.9-0.1-3.4c0-2.3,0.4-3.4,1.3-3.4c0.2,0,0.5,0.1,0.6,0.3\n                c0.2,0.2,0.3,0.4,0.3,0.6L167.4,312.4z\"/>\n            <path d=\"M182.7,322.9c0,6.9-1.4,10.4-4.2,10.4c-2.6,0-4.1-3.3-4.4-9.8c0-0.6,0-1.2,0-1.9l0-2.2v-0.7c0-5.1,0.7-8.2,2.2-9.4\n                c0.4-0.3,0.8-0.5,1.2-0.5c0.3,0.1,0.8,0.2,1.3,0.3c0.5,0.1,0.9,0.2,1.1,0.3c0.4,0.2,0.9,0.7,1.4,1.6s0.9,2,1.1,3.4\n                c0.2,1.4,0.4,2.8,0.4,4.2V322.9z M176,314.4l0.1,2.1l0,3.5c0,0.3,0,0.6,0,1c0,0.4,0,0.9,0,1.6c0,0.7,0.1,1.3,0.1,1.9\n                c0.1,0.6,0.1,1.3,0.2,2c0.1,0.7,0.2,1.4,0.3,2c0.1,0.6,0.2,1.2,0.4,1.6c0.3,1.1,0.7,1.6,1.3,1.6c0.7,0,1.2-0.7,1.6-2\n                c0.5-1.9,0.8-4.3,0.8-7.2l0.1-3.7c0-2.6-0.1-4.4-0.3-5.3c-0.2-0.9-0.4-1.6-0.6-2c-0.4-0.9-1-1.4-1.8-1.4c0,0,0,0-0.1,0\n                C176.7,310.3,176,311.6,176,314.4z\"/>\n            <path d=\"M191.6,323.5l-0.6,0c-0.3,0-0.6-0.1-0.8-0.2c-0.2-0.1-0.3-0.3-0.3-0.7s0.1-0.6,0.3-0.8c0.2-0.2,0.5-0.3,0.8-0.3v0\n                c2.3,0,3.5,0.4,3.5,1.1l-0.4,2.6l0.2,3.8c0,0.7-0.1,1.3-0.2,1.8c-1.4,1.3-2.6,1.9-3.7,1.9c-0.6,0-1.1-0.2-1.6-0.5\n                c-0.5-0.3-1-0.8-1.4-1.6s-0.9-2.2-1.2-4.3s-0.5-3.6-0.5-4.4s0-1.5,0.1-2c0-0.5,0.1-1.2,0.2-1.8c0.1-0.7,0.1-1.1,0.1-1.3\n                c0-0.2,0-0.5,0.1-0.9c0-0.4,0.1-0.7,0.1-1.1s0.1-0.8,0.2-1.5c0.1-0.6,0.2-1.1,0.3-1.5c0.1-0.4,0.3-0.8,0.5-1.2\n                c0.2-0.5,0.5-0.8,0.8-1.1c0.7-0.6,1.5-0.9,2.5-0.9c0.9,0,1.4,0.3,1.4,0.9c0,0.3-0.1,0.5-0.3,0.7s-0.4,0.3-0.7,0.3l-0.7-0.1\n                c-0.7,0-1.2,0.8-1.6,2.5c-0.4,1.6-0.6,3-0.6,4.3c-0.1,2-0.2,3.3-0.2,3.9c0,0.7,0,1.2,0,1.5s0,0.8,0,1.3s0,1,0.1,1.4\n                s0.1,0.9,0.2,1.4c0.1,0.5,0.2,0.9,0.3,1.3c0.1,0.4,0.2,0.7,0.4,1.1c0.1,0.4,0.3,0.7,0.5,0.9c0.4,0.5,0.9,0.8,1.5,0.8\n                c1,0,1.6-2,1.5-6.1v-1.3C192.2,323.5,192,323.5,191.6,323.5z\"/>\n        </g>\n    </g>\n</svg>',NULL,1540223034,0,'n',0,'','n','n','o',0,'n'),
	(5,1,3,'header','webpage','<header class=\"site_header\">\n    <div class=\"container\">\n        <div class=\"logo\">\n            <a href=\"/\">\n                {embed=\"includes/logo_svg\"}\n            </a>\n        </div>\n    </div>\n</header>',NULL,1540223098,0,'n',0,'','n','n','o',0,'n'),
	(6,1,3,'footer','webpage','<footer class=\"site_footer\">\n    <p class=\"site_footer__copyright\">&copy; Copyright 2018 Hot Chken Blog LLC. All&nbsp;rights&nbsp;reserved. <a\n            href=\"/privacy\">Privacy Policy</a></p>\n</footer>',NULL,1540226844,0,'n',0,'','n','n','o',0,'n'),
	(7,1,3,'head','webpage','<meta charset=\"UTF-8\">\n<meta name=\"viewport\"\n      content=\"width=device-width, user-scalable=no, initial-scale=1.0\">\n<meta http-equiv=\"X-UA-Compatible\" content=\"ie=edge\">\n<link rel=\"stylesheet\" href=\"/assets/css/reset.css\">\n<link rel=\"stylesheet\" href=\"/assets/css/site.css\">\n<script src=\"/assets/js/jquery-3.3.1.min.js\"></script>\n<script src=\"/assets/js/site.js\"></script>\n<title>{embed:title}</title>\n',NULL,1540303996,0,'n',0,'','n','n','o',0,'n'),
	(8,1,2,'_article','webpage','<article class=\"blog_article\">\n\n    <div class=\"blog_article_image\">\n        <a href=\"/blog/{url_title}\"><img src=\"{image}\" alt=\"\"></a>\n    </div>\n\n    <h3 class=\"blog_article__title\"><a href=\"/blog/{url_title}\">{title}</a></h3>\n\n    {if embed:single == \"yes\"}\n    <div class=\"blog_article__body\">\n        {body}\n    </div>\n\n    <div class=\"blog_article__related\">\n\n        <h4>More Hot Chicken</h4>\n\n        <div class=\"blog_article__related__items\">\n\n            {exp:channel:entries\n            channel=\"blog\"\n            limit=\"3\"\n            dynamic=\"no\"\n            }\n\n            <div class=\"blog_article__related__item\">\n\n                <div class=\"blog_article__related__item__image\">\n                    <a href=\"/blog/{url_title}\"><img src=\"{image}\" alt=\"\"></a>\n                </div>\n\n                <h5 class=\"blog_article__related__item__title\"><a href=\"/blog/{url_title}\">{title}</a></h5>\n\n                <a href=\"/blog/{url_title}\" class=\"blog_article__related__item__read_more\">Read</a>\n\n            </div>\n\n            {/exp:channel:entries}\n\n        </div>\n\n    </div>\n    {if:else}\n        <div class=\"blog_article__excerpt\">\n            {exp:trunk:truncate}\n            {body}\n            {/exp:trunk:truncate}\n        </div>\n\n        <a href=\"/blog/{url_title}\" class=\"blog_article__read_more\">Read More</a>\n    {/if}\n</article>',NULL,1540311484,0,'n',0,'','n','n','o',0,'n'),
	(9,1,2,'_related_articles','webpage','<div class=\"blog_article__related\">\n    <h4 class=\"blog_article__related__headline\">More Hot Chicken</h4>\n    <div class=\"blog_article__related__items\">\n        {exp:channel:entries\n            channel=\"blog\"\n            limit=\"3\"\n            dynamic=\"no\"\n            entry_id=\"not {embed:entry_id}\"\n        }\n            <div class=\"blog_article__related__item\">\n                <div class=\"blog_article__related__item__image\">\n                    <a href=\"/blog/{url_title}\"><img src=\"{image}\" alt=\"\"></a>\n                </div>\n\n                <h5 class=\"blog_article__related__item__title\"><a href=\"/blog/{url_title}\">{title}</a></h5>\n            </div>\n        {/exp:channel:entries}\n    </div>\n</div>\n\n',NULL,1540307487,0,'n',0,'','n','n','o',0,'n'),
	(10,1,2,'_article_simple','webpage','{exp:channel:entries\nchannel=\"blog\"\nlimit=\"1\"\ndynamic=\"no\"\nentry_id=\"{embed:entry_id}\"\nparse=\"inward\"\n}\n<article class=\"blog_article\">\n\n    <div class=\"blog_article_image\">\n        <a href=\"/blog/{url_title}\"><img src=\"{image}\" alt=\"\"></a>\n    </div>\n\n    <h3 class=\"blog_article__title\"><a href=\"/blog/{url_title}\">{title}</a></h3>\n\n    <div class=\"blog_article__body\">\n        {body}\n    </div>\n\n    {if embed:single == \"yes\"}\n\n        <div class=\"blog_article__related\">\n\n            <h4 class=\"blog_article__related__headline\">More Hot Chicken</h4>\n\n            {embed=\"blog/_related_articles\"\n            single=\"yes\"\n            entry_id=\"{embed:entry_id}\"\n            }\n\n        </div>\n    {/if}\n\n</article>\n{/exp:channel:entries}',NULL,1540311484,0,'n',0,'','n','n','o',0,'n'),
	(11,1,2,'_partner_content','webpage','<div class=\"blog_article__partner_content\">\n\n    <h4 class=\"blog_article__partner_content__headline\">Partner Content</h4>\n\n    <div class=\"blog_article__partner_content__items\">\n\n        {exp:partner_content:fetch}\n\n        <div class=\"blog_article__partner_content__item\">\n\n            <div class=\"blog_article__partner_content__item__image\">\n                <a href=\"{url}\" target=\"_blank\"><img src=\"{image}\" alt=\"\"></a>\n            </div>\n\n            <h5 class=\"blog_article__partner_content__item__title\"><a href=\"{url}\">{title}</a></h5>\n\n            <h6 class=\"blog_article__partner_content__item__site_name\"><a href=\"{partner_site_url}\" target=\"_blank\">{partner_site_name}</a></h6>\n\n            <div class=\"blog_article__partner_content__excerpt\">\n                {excerpt}\n            </div>\n\n            <a href=\"{url}\" class=\"blog_article__partner_content__read_more\" target=\"_blank\">Read Article</a>\n\n        </div>\n\n        {/exp:partner_content:fetch}\n\n    </div>\n\n</div>',NULL,1540307427,0,'n',0,'','n','n','o',0,'n'),
	(12,1,2,'_comments_form','webpage','{exp:hot_comments:form entry_id=\"{embed:entry_id}\" title=\"{embed:title}\"}\n    {exp:formgrab:form\n    name=\"{form_name}\"\n    title=\"{form_title}\"\n    }\n        <div class=\"form-group\">\n            <input name=\"name\" type=\"text\" class=\"form-control\" id=\"name\" placeholder=\"Your name\" required>\n        </div>\n        <div class=\"form-group\">\n            <input name=\"email\" type=\"email\" class=\"form-control\" id=\"email\" placeholder=\"Your email address\" required>\n        </div>\n        <div class=\"form-group\">\n            <textarea name=\"message\" class=\"form-control\" id=\"message\" rows=\"6\" placeholder=\"Your comment\" required></textarea>\n        </div>\n        <div class=\"submit\">\n            <button type=\"submit\" class=\"btn btn-primary\">Post</button>\n        </div>\n\n    {/exp:formgrab:form}\n{/exp:hot_comments:form}',NULL,1540305717,0,'n',0,'','n','n','o',0,'n'),
	(13,1,2,'_comments','webpage','<div class=\"blog_article__comments\">\n    <h4 class=\"blog_article__comments__headline\">Comments {exp:hot_comments:count entry_id=\"{embed:entry_id}\"}{if !no_results}({comment_count}){/if}{/exp:hot_comments:count}</h4>\n\n    <div class=\"blog_article__comments__form\">\n        {embed=\"blog/_comments_form\"\n            entry_id=\"{embed:entry_id}\"\n            title=\"{embed:title}\"\n        }\n    </div>\n\n    <div class=\"blog_article__comments__list\">\n        {embed=\"blog/_comments_list\"\n            entry_id=\"{embed:entry_id}\"\n        }\n    </div>\n</div>',NULL,1540307327,0,'n',0,'','n','n','o',0,'n'),
	(14,1,2,'_comments_list','webpage','{exp:hot_comments:get entry_id=\"{embed:entry_id}\"}\n\n    {if !no_results}\n        <div class=\"blog_article__comments__list__item\">\n            <div class=\"blog_article__comments__list__item__meta\">\n                <h6 class=\"blog_article__comments__list__item__name\">{name}</h6>\n                <div class=\"blog_article__comments__list__item__date\">{date}</div>\n            </div>\n            <div class=\"blog_article__comments__list__item__message\">{message}</div>\n        </div>\n    {/if}\n\n{/exp:hot_comments:get}',NULL,1540299209,0,'n',0,'','n','n','o',0,'n'),
	(15,1,2,'_article_1','webpage','{exp:channel:entries\n    channel=\"blog\"\n    limit=\"1\"\n    dynamic=\"no\"\n    entry_id=\"{embed:entry_id}\"\n}\n    <article class=\"blog_article\">\n        <div class=\"blog_article_image\">\n            <a href=\"/blog/{url_title}\"><img src=\"{image}\" alt=\"\"></a>\n        </div>\n\n        <h3 class=\"blog_article__title\"><a href=\"/blog/{url_title}\">{title}</a></h3>\n\n        <div class=\"blog_article__body\">\n            {body}\n        </div>\n\n        <div class=\"blog_article_meta\">\n            Posted by {author} on {entry_date format=\"%m/%d/%Y\"}\n        </div>\n\n        {if embed:single == \"yes\"}\n            {embed=\"blog/_related_articles\"\n                entry_id=\"{embed:entry_id}\"\n            }\n        {/if}\n    </article>\n{/exp:channel:entries}',NULL,1540311658,1,'n',0,'','n','n','o',0,'n');

/*!40000 ALTER TABLE `exp_templates` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_throttle
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_throttle`;

CREATE TABLE `exp_throttle` (
  `throttle_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL,
  `locked_out` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'n',
  PRIMARY KEY (`throttle_id`),
  KEY `ip_address` (`ip_address`),
  KEY `last_activity` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table exp_update_log
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_update_log`;

CREATE TABLE `exp_update_log` (
  `log_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` int(10) unsigned DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `method` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `line` int(10) unsigned DEFAULT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_update_log` WRITE;
/*!40000 ALTER TABLE `exp_update_log` DISABLE KEYS */;

INSERT INTO `exp_update_log` (`log_id`, `timestamp`, `message`, `method`, `line`, `file`)
VALUES
	(1,1540210616,'Smartforge::add_key failed. Table \'exp_comments\' does not exist.','Smartforge::add_key',105,'/code/eeconf2018/system/ee/EllisLab/Addons/comment/upd.comment.php');

/*!40000 ALTER TABLE `exp_update_log` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_upload_no_access
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_upload_no_access`;

CREATE TABLE `exp_upload_no_access` (
  `upload_id` int(6) unsigned NOT NULL,
  `member_group` smallint(4) unsigned NOT NULL,
  PRIMARY KEY (`upload_id`,`member_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_upload_no_access` WRITE;
/*!40000 ALTER TABLE `exp_upload_no_access` DISABLE KEYS */;

INSERT INTO `exp_upload_no_access` (`upload_id`, `member_group`)
VALUES
	(6,5);

/*!40000 ALTER TABLE `exp_upload_no_access` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table exp_upload_prefs
# ------------------------------------------------------------

DROP TABLE IF EXISTS `exp_upload_prefs`;

CREATE TABLE `exp_upload_prefs` (
  `id` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `server_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `allowed_types` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'img',
  `default_modal_view` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'list',
  `max_size` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `max_height` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `max_width` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `properties` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pre_format` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `post_format` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_properties` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_pre_format` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_post_format` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cat_group` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `batch_location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `module_id` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `exp_upload_prefs` WRITE;
/*!40000 ALTER TABLE `exp_upload_prefs` DISABLE KEYS */;

INSERT INTO `exp_upload_prefs` (`id`, `site_id`, `name`, `server_path`, `url`, `allowed_types`, `default_modal_view`, `max_size`, `max_height`, `max_width`, `properties`, `pre_format`, `post_format`, `file_properties`, `file_pre_format`, `file_post_format`, `cat_group`, `batch_location`, `module_id`)
VALUES
	(1,1,'Avatars','{base_path}images/avatars/','{base_url}images/avatars/','img','list','50','100','100',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),
	(2,1,'Default Avatars','{base_path}images/avatars/default/','{base_url}images/avatars/default/','img','list','50','100','100',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),
	(3,1,'Member Photos','/','{base_url}images/member_photos/','img','list','50','100','100',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),
	(4,1,'Signature Attachments','{base_path}images/signature_attachments/','{base_url}images/signature_attachments/','img','list','30','80','480',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),
	(5,1,'PM Attachments','{base_path}images/pm_attachments/','{base_url}images/pm_attachments/','img','list','250',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),
	(6,1,'Blog Images','assets/uploads/','/assets/uploads/','img','list','','','',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,0);

/*!40000 ALTER TABLE `exp_upload_prefs` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
